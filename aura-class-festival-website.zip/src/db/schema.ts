import {
  pgTable,
  uuid,
  text,
  timestamp,
  boolean,
  integer,
  date,
} from "drizzle-orm/pg-core";

// ── Admins ──────────────────────────────────────────────
export const admins = pgTable("admins", {
  id: uuid("id").defaultRandom().primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull().default("Festival Admin"),
  role: text("role").notNull().default("admin"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Teams (ALPHA & BETA) ────────────────────────────────
export const teams = pgTable("teams", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull().unique(), // alpha | beta
  name: text("name").notNull(),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  colorPrimary: text("color_primary").notNull().default("#1769E8"),
  colorSecondary: text("color_secondary").notNull().default("#75C3FF"),
  emblem: text("emblem").notNull().default("A"),
  motto: text("motto").notNull().default(""),
  captainName: text("captain_name").notNull().default("To be announced"),
  captainNote: text("captain_note").notNull().default(""),
  viceCaptainName: text("vice_captain_name").notNull().default("To be announced"),
  logoUrl: text("logo_url").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const teamMembers = pgTable("team_members", {
  id: uuid("id").defaultRandom().primaryKey(),
  teamId: uuid("team_id")
    .notNull()
    .references(() => teams.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  role: text("role").notNull().default("Member"),
  note: text("note").notNull().default(""),
  positionOrder: integer("position_order").notNull().default(0),
  isPlaceholder: boolean("is_placeholder").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Event categories ────────────────────────────────────
export const eventCategories = pgTable("event_categories", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  icon: text("icon").notNull().default("sparkles"),
  color: text("color").notNull().default("#1769E8"),
  displayOrder: integer("display_order").notNull().default(0),
});

// ── Events / Programs ───────────────────────────────────
export const events = pgTable("events", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  categoryId: uuid("category_id").references(() => eventCategories.id, {
    onDelete: "set null",
  }),
  description: text("description").notNull().default(""),
  rules: text("rules").notNull().default(""),
  venue: text("venue").notNull().default("Main Stage"),
  eventDate: date("event_date", { mode: "string" }),
  startTime: text("start_time").notNull().default(""),
  endTime: text("end_time").notNull().default(""),
  startAt: timestamp("start_at", { withTimezone: true }),
  endAt: timestamp("end_at", { withTimezone: true }),
  autoSchedule: boolean("auto_schedule").notNull().default(true),
  eventType: text("event_type").notNull().default("individual"), // individual | group
  participatingTeams: text("participating_teams").notNull().default("both"), // alpha | beta | both
  status: text("status").notNull().default("upcoming"), // upcoming | ongoing | completed | postponed
  isFeatured: boolean("is_featured").notNull().default(false),
  registrationInfo: text("registration_info").notNull().default(""),
  maxParticipants: text("max_participants").notNull().default(""),
  imageUrl: text("image_url").notNull().default(""),
  pointsFirst: integer("points_first").notNull().default(10),
  pointsSecond: integer("points_second").notNull().default(7),
  pointsThird: integer("points_third").notNull().default(5),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Candidates / Participants ───────────────────────────
export const participants = pgTable("participants", {
  id: uuid("id").defaultRandom().primaryKey(),
  eventId: uuid("event_id")
    .notNull()
    .references(() => events.id, { onDelete: "cascade" }),
  chestNumber: text("chest_number").notNull().default(""),
  name: text("name").notNull(),
  teamId: uuid("team_id").references(() => teams.id, { onDelete: "set null" }),
  category: text("category").notNull().default("General"),
  score: text("score").notNull().default(""),
  grade: text("grade").notNull().default(""),
  points: integer("points").notNull().default(0),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Results (placed positions & scores per program) ─────
export const results = pgTable("results", {
  id: uuid("id").defaultRandom().primaryKey(),
  eventId: uuid("event_id")
    .notNull()
    .references(() => events.id, { onDelete: "cascade" }),
  position: integer("position").notNull(), // 1 | 2 | 3 | 0 (grade-only)
  chestNumber: text("chest_number").notNull().default(""),
  participantName: text("participant_name").notNull(),
  teamId: uuid("team_id").references(() => teams.id, { onDelete: "set null" }),
  score: text("score").notNull().default(""),
  grade: text("grade").notNull().default(""),
  points: integer("points").notNull().default(0),
  isPublished: boolean("is_published").notNull().default(false),
  note: text("note").notNull().default(""),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Direct Team Bonus / Point Adjustments ───────────────
export const teamPointLogs = pgTable("team_point_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  teamId: uuid("team_id")
    .notNull()
    .references(() => teams.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  points: integer("points").notNull().default(0),
  note: text("note").notNull().default(""),
  isPublished: boolean("is_published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Announcements ───────────────────────────────────────
export const announcements = pgTable("announcements", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  category: text("category").notNull().default("General"),
  priority: text("priority").notNull().default("info"),
  isPublished: boolean("is_published").notNull().default(true),
  publishDate: date("publish_date", { mode: "string" }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Gallery ─────────────────────────────────────────────
export const galleryItems = pgTable("gallery_items", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull().default("festival"),
  isVideo: boolean("is_video").notNull().default(false),
  videoUrl: text("video_url").notNull().default(""),
  displayOrder: integer("display_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Committee ───────────────────────────────────────────
export const committeeMembers = pgTable("committee_members", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  position: text("position").notNull(),
  category: text("category").notNull().default("organizing"),
  bio: text("bio").notNull().default(""),
  photoUrl: text("photo_url").notNull().default(""),
  email: text("email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  displayOrder: integer("display_order").notNull().default(0),
  isPlaceholder: boolean("is_placeholder").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Portal photos (photos shown on every portal page) ───
export const portalPhotos = pgTable("portal_photos", {
  id: uuid("id").defaultRandom().primaryKey(),
  portal: text("portal").notNull().default("home"), // home|about|events|teams|schedule|results|gallery|announcements|committee|contact
  title: text("title").notNull().default(""),
  caption: text("caption").notNull().default(""),
  imageUrl: text("image_url").notNull(),
  alt: text("alt").notNull().default(""),
  displayOrder: integer("display_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Website settings (key-value) ────────────────────────
export const websiteSettings = pgTable("website_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ── Contact messages ────────────────────────────────────
export const contactMessages = pgTable("contact_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull().default(""),
  subject: text("subject").notNull().default(""),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Admin = typeof admins.$inferSelect;
export type Team = typeof teams.$inferSelect;
export type TeamMember = typeof teamMembers.$inferSelect;
export type EventCategory = typeof eventCategories.$inferSelect;
export type FestivalEvent = typeof events.$inferSelect;
export type Participant = typeof participants.$inferSelect;
export type EventResult = typeof results.$inferSelect;
export type TeamPointLog = typeof teamPointLogs.$inferSelect;
export type PortalPhoto = typeof portalPhotos.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;
export type GalleryItem = typeof galleryItems.$inferSelect;
export type CommitteeMember = typeof committeeMembers.$inferSelect;
export type WebsiteSetting = typeof websiteSettings.$inferSelect;
export type ContactMessage = typeof contactMessages.$inferSelect;
