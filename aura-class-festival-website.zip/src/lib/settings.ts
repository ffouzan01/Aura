import { db } from "@/db";
import { websiteSettings } from "@/db/schema";

export const DEFAULT_SETTINGS: Record<string, string> = {
  festival_name: "AURA",
  poster_kicker: "WIDAD FRIENDS UNION",
  poster_org_line: "Worthy Individuals for Da'wa, Arts and Discipline",
  poster_title: "Aura",
  poster_tagline: "Arts Unite Reality & AI",
  poster_month: "NOVEMBER 2026",
  poster_start_day: "10",
  poster_end_day: "16",
  poster_day_range: "Wednesday – Sunday",
  poster_venue: "@ Main Auditorium",
  poster_welcome: "Welcome to the ultimate celebration of art and talent..!",
  poster_url: "",
  festival_tagline: "WHERE TALENT MEETS EXCELLENCE",
  festival_motto:
    "Where unspoken brilliance steps into the blue spotlight and every stage ignites into living art. Two rival houses rise under one electric sky, turning fleeting moments into timeless excellence.",
  festival_intro:
    "Where unspoken brilliance steps into the blue spotlight and every stage ignites into living art. Two rival houses rise under one electric sky, turning fleeting moments into timeless excellence.",
  brand_wordmark: "AURA",
  brand_subtext: "WIDAD FRIENDS",
  hero_badge: "WIDAD FRIENDS UNION PRESENTS",
  festival_date: "2027-03-12T09:00:00+05:30",
  festival_end_date: "2027-03-14T18:00:00+05:30",
  venue: "",
  festival_hours: "",
  venue_address: "",
  contact_email: "hello@aurafest.example",
  contact_phone: "+91 90000 00000",
  instagram_url: "https://instagram.com",
  youtube_url: "https://youtube.com",
  twitter_url: "https://x.com",
  facebook_url: "https://facebook.com",
  whatsapp_url: "https://whatsapp.com",
  organizer_name: "WIDAD FRIENDS UNION",
  results_visible: "true",
  registration_open: "true",
  registration_note:
    "Registrations are coordinated through your house captains. Contact them to enter a program.",
  about_aura:
    "AURA is the flagship class festival organised by WIDAD FRIENDS UNION — a celebration where passion turns into performance and creativity finds its voice. Across literary, artistic, musical, stage and sporting arenas, two houses — ALPHA and BETA — bring out the finest in every student.",
  about_organizer:
    "WIDAD FRIENDS UNION is the student union behind AURA — a dedicated collective of student leaders, coordinators and volunteers committed to crafting a festival that is fair, inspiring and unforgettable.",
  vision:
    "To cultivate a festival culture where every student discovers a stage, excellence is celebrated with integrity, and unity outshines every trophy.",
  mission:
    "To organise an inclusive, transparent and creatively ambitious class festival that nurtures artistry, sportsmanship and leadership.",
};

export async function getSettings(): Promise<Record<string, string>> {
  try {
    const rows = await db.select().from(websiteSettings);
    const map: Record<string, string> = { ...DEFAULT_SETTINGS };
    for (const r of rows) {
      if (
        (r.key === "venue" || r.key === "venue_address") &&
        r.value.toLowerCase().includes("widad campus")
      ) {
        map[r.key] = "";
      } else {
        map[r.key] = r.value;
      }
    }
    return map;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80);
}
