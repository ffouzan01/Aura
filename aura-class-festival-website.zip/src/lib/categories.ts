/** Official AURA program categories — shared by admin forms and the API. */
export const OFFICIAL_CATEGORIES = [
  { slug: "stage", name: "Stage" },
  { slug: "stage-group", name: "Stage Group" },
  { slug: "non-stage", name: "Non Stage" },
  { slug: "general", name: "General" },
  { slug: "sports", name: "Sports" },
] as const;

export type OfficialCategorySlug = (typeof OFFICIAL_CATEGORIES)[number]["slug"];

export const OFFICIAL_CATEGORY_NAMES: string[] = OFFICIAL_CATEGORIES.map(
  (c) => c.name
);

export function isOfficialCategorySlug(v: string): v is OfficialCategorySlug {
  return OFFICIAL_CATEGORIES.some((c) => c.slug === v);
}
