import { db } from "@/db";
import {
  admins,
  eventCategories,
  events,
  teams,
  websiteSettings,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { DEFAULT_SETTINGS } from "./settings";

/**
 * Official AURA program categories. These are structural (not invented festival
 * content) and everything else — events, candidates, committee, gallery,
 * announcements — is created by the administrator.
 */
export const CATEGORIES_SEED = [
  { slug: "stage", name: "Stage", description: "On-stage individual performances.", icon: "music", color: "#EC4899", displayOrder: 1 },
  { slug: "stage-group", name: "Stage Group", description: "Group performances on stage.", icon: "drama", color: "#7C3AED", displayOrder: 2 },
  { slug: "non-stage", name: "Non Stage", description: "Off-stage individual contests.", icon: "palette", color: "#0EA5E9", displayOrder: 3 },
  { slug: "general", name: "General", description: "Open-format programs.", icon: "sparkles", color: "#1769E8", displayOrder: 4 },
  { slug: "sports", name: "Sports", description: "Athletic contests and games.", icon: "trophy", color: "#10B981", displayOrder: 5 },
];

/** Legacy category slugs remapped onto the official AURA categories. */
export const CATEGORY_REMAP: Record<string, string> = {
  literary: "non-stage",
  arts: "non-stage",
  music: "stage",
  "dance-drama": "stage",
  "sports-games": "sports",
  knowledge: "general",
};

/**
 * Minimal bootstrap: admin account, site settings, the two official houses and
 * the official category list. No events, winners, gallery items, committee
 * members or announcements are invented — the administrator adds them all.
 */
export async function seedDatabase(): Promise<{ seeded: string[] }> {
  const seeded: string[] = [];

  const existingAdmins = await db.select().from(admins).limit(1);
  if (existingAdmins.length === 0) {
    const hash = await bcrypt.hash("aurafest", 10);
    await db.insert(admins).values({
      username: "admin",
      passwordHash: hash,
      name: "AURA Festival Admin",
      role: "admin",
    });
    seeded.push("admin");
  }

  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await db
      .insert(websiteSettings)
      .values({ key, value })
      .onConflictDoNothing({ target: websiteSettings.key });
  }
  seeded.push("settings");

  const existingTeams = await db.select().from(teams);
  if (existingTeams.length === 0) {
    await db.insert(teams).values([
      {
        slug: "alpha",
        name: "ALPHA",
        tagline: "House of ALPHA",
        description: "",
        colorPrimary: "#1769E8",
        colorSecondary: "#75C3FF",
        emblem: "Α",
        motto: "",
        captainName: "To be announced",
        viceCaptainName: "To be announced",
      },
      {
        slug: "beta",
        name: "BETA",
        tagline: "House of BETA",
        description: "",
        colorPrimary: "#0B3FA0",
        colorSecondary: "#38BDF8",
        emblem: "Β",
        motto: "",
        captainName: "To be announced",
        viceCaptainName: "To be announced",
      },
    ]);
    seeded.push("teams");
  }

  await syncCategories();
  return { seeded };
}

/** Ensures the official category rows exist and legacy ones are remapped. */
export async function syncCategories(): Promise<void> {
  const existing = await db.select().from(eventCategories);
  const bySlug = new Map(existing.map((c) => [c.slug, c]));

  for (const cat of CATEGORIES_SEED) {
    if (!bySlug.has(cat.slug)) {
      const [created] = await db
        .insert(eventCategories)
        .values(cat)
        .onConflictDoNothing({ target: eventCategories.slug })
        .returning();
      if (created) bySlug.set(cat.slug, created);
    }
  }

  const all = await db.select().from(eventCategories);
  const byId = new Map(all.map((c) => [c.id, c]));
  const eventRows = await db.select().from(events);

  for (const ev of eventRows) {
    const currentSlug = ev.categoryId ? byId.get(ev.categoryId)?.slug : null;
    if (currentSlug && CATEGORY_REMAP[currentSlug]) {
      await db
        .update(events)
        .set({ categoryId: bySlug.get(CATEGORY_REMAP[currentSlug])?.id ?? null })
        .where(eq(events.id, ev.id));
    }
  }
}

export async function ensureSeeded() {
  try {
    const rows = await db
      .select()
      .from(websiteSettings)
      .where(eq(websiteSettings.key, "festival_name"))
      .limit(1);
    if (rows.length === 0) await seedDatabase();

    const cats = await db.select().from(eventCategories);
    const official = new Set(CATEGORIES_SEED.map((c) => c.slug));
    if (cats.length < CATEGORIES_SEED.length || cats.some((c) => !official.has(c.slug))) {
      await syncCategories();
    }
  } catch {
    /* tables may not exist yet */
  }
}
