import { db } from "@/db";
import {
  announcements,
  committeeMembers,
  eventCategories,
  events,
  galleryItems,
  participants,
  portalPhotos,
  results,
  teamMembers,
  teamPointLogs,
  teams,
} from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { ensureSeeded } from "./seed";
import { timeSortMinutes } from "./schedule";

export async function getEventsFull() {
  await ensureSeeded();
  const [eventRows, catRows] = await Promise.all([
    db.select().from(events).orderBy(asc(events.eventDate), asc(events.title)),
    db.select().from(eventCategories),
  ]);
  const catById = new Map(catRows.map((c) => [c.id, c]));
  const mapped = eventRows.map((e) => ({
    ...e,
    startAtIso: e.startAt ? e.startAt.toISOString() : null,
    endAtIso: e.endAt ? e.endAt.toISOString() : null,
    category: e.categoryId ? catById.get(e.categoryId) ?? null : null,
  }));

  mapped.sort((a, b) => {
    const da = a.eventDate ?? "9999-99-99";
    const db2 = b.eventDate ?? "9999-99-99";
    if (da !== db2) return da.localeCompare(db2);
    return timeSortMinutes(a.startTime) - timeSortMinutes(b.startTime);
  });

  return mapped;
}

export async function getEventBySlug(slug: string) {
  await ensureSeeded();
  const rows = await db.select().from(events).where(eq(events.slug, slug)).limit(1);
  const event = rows[0];
  if (!event) return null;
  const [catRows, resultRows, candidateRows, teamRows] = await Promise.all([
    event.categoryId
      ? db.select().from(eventCategories).where(eq(eventCategories.id, event.categoryId)).limit(1)
      : Promise.resolve([]),
    db.select().from(results).where(eq(results.eventId, event.id)),
    db.select().from(participants).where(eq(participants.eventId, event.id)),
    db.select().from(teams),
  ]);
  const teamById = new Map(teamRows.map((t) => [t.id, t]));
  return {
    ...event,
    startAtIso: event.startAt ? event.startAt.toISOString() : null,
    endAtIso: event.endAt ? event.endAt.toISOString() : null,
    category: catRows[0] ?? null,
    candidates: candidateRows.map((c) => ({
      ...c,
      team: c.teamId ? teamById.get(c.teamId) ?? null : null,
    })),
    results: resultRows
      .sort((a, b) => (a.position || 99) - (b.position || 99))
      .map((r) => ({ ...r, team: r.teamId ? teamById.get(r.teamId) ?? null : null })),
  };
}

export async function getTeamsFull() {
  await ensureSeeded();
  const [teamRows, memberRows, candidateRows, eventRows, publishedResults, publishedLogs] =
    await Promise.all([
      db.select().from(teams),
      db.select().from(teamMembers).orderBy(asc(teamMembers.positionOrder)),
      db.select().from(participants).orderBy(asc(participants.chestNumber), asc(participants.name)),
      db.select().from(events),
      db.select().from(results).where(eq(results.isPublished, true)),
      db.select().from(teamPointLogs).where(eq(teamPointLogs.isPublished, true)),
    ]);

  const eventById = new Map(eventRows.map((e) => [e.id, e]));

  return teamRows.map((t) => {
    const mine = publishedResults.filter((r) => r.teamId === t.id);
    const logs = publishedLogs.filter((l) => l.teamId === t.id);
    const resultPts = mine.reduce((s, r) => s + (r.points ?? 0), 0);
    const bonusPts = logs.reduce((s, l) => s + (l.points ?? 0), 0);
    return {
      ...t,
      members: memberRows.filter((m) => m.teamId === t.id),
      candidates: candidateRows
        .filter((c) => c.teamId === t.id)
        .map((c) => ({
          id: c.id,
          chestNumber: c.chestNumber,
          name: c.name,
          category: c.category,
          score: c.score,
          grade: c.grade,
          points: c.points,
          eventTitle: eventById.get(c.eventId)?.title ?? "Program",
          eventSlug: eventById.get(c.eventId)?.slug ?? "",
        })),
      points: resultPts + bonusPts,
      first: mine.filter((r) => r.position === 1).length,
      second: mine.filter((r) => r.position === 2).length,
      third: mine.filter((r) => r.position === 3).length,
      wins: mine.length,
    };
  });
}

export async function getPublishedResults() {
  await ensureSeeded();
  const [resultRows, eventRows, catRows, teamRows] = await Promise.all([
    db.select().from(results).where(eq(results.isPublished, true)),
    db.select().from(events),
    db.select().from(eventCategories),
    db.select().from(teams),
  ]);
  const eventById = new Map(eventRows.map((e) => [e.id, e]));
  const catById = new Map(catRows.map((c) => [c.id, c]));
  const teamById = new Map(teamRows.map((t) => [t.id, t]));
  return resultRows.map((r) => {
    const ev = eventById.get(r.eventId);
    return {
      ...r,
      event: ev ?? null,
      category: ev?.categoryId ? catById.get(ev.categoryId) ?? null : null,
      team: r.teamId ? teamById.get(r.teamId) ?? null : null,
    };
  });
}

export async function getPublishedPointLogs() {
  await ensureSeeded();
  const [logs, teamRows] = await Promise.all([
    db.select().from(teamPointLogs).where(eq(teamPointLogs.isPublished, true)),
    db.select().from(teams),
  ]);
  const teamById = new Map(teamRows.map((t) => [t.id, t]));
  return logs.map((l) => ({
    ...l,
    team: teamById.get(l.teamId) ?? null,
  }));
}

export async function getAnnouncementsPublic() {
  await ensureSeeded();
  return db
    .select()
    .from(announcements)
    .where(eq(announcements.isPublished, true))
    .orderBy(desc(announcements.publishDate), desc(announcements.createdAt));
}

export async function getGalleryPublic() {
  await ensureSeeded();
  return db.select().from(galleryItems).orderBy(asc(galleryItems.displayOrder));
}

export async function getCommitteePublic() {
  await ensureSeeded();
  return db.select().from(committeeMembers).orderBy(asc(committeeMembers.displayOrder));
}

export async function getCategories() {
  await ensureSeeded();
  return db.select().from(eventCategories).orderBy(asc(eventCategories.displayOrder));
}

export async function getStandings() {
  const teamFull = await getTeamsFull();
  return [...teamFull].sort((a, b) => b.points - a.points || b.first - a.first);
}

export { and };

/** Photos attached to a specific portal page (admin-managed). */
export async function getPortalPhotos(portal: string, limit = 8) {
  try {
    await ensureSeeded();
    const rows = await db
      .select()
      .from(portalPhotos)
      .where(and(eq(portalPhotos.portal, portal), eq(portalPhotos.isActive, true)))
      .orderBy(asc(portalPhotos.displayOrder), asc(portalPhotos.createdAt));
    return rows.slice(0, limit);
  } catch {
    return [];
  }
}
