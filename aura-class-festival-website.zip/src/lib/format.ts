export function formatEventDate(d: string | null) {
  if (!d) return "Date TBA";
  try {
    return new Date(d + "T00:00:00").toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
    });
  } catch {
    return "Date TBA";
  }
}

export function teamLabel(t: string) {
  if (t === "alpha") return "ALPHA only";
  if (t === "beta") return "BETA only";
  return "ALPHA vs BETA";
}

export function fullDateLabel(d: string | null) {
  if (!d) return "Date to be announced";
  try {
    return new Date(d + "T00:00:00").toLocaleDateString("en-IN", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch {
    return "Date to be announced";
  }
}
