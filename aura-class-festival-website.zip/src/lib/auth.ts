import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

const COOKIE_NAME = "aura_admin_token";

function getSecret(): Uint8Array {
  const secret =
    process.env.ADMIN_JWT_SECRET || "aura-widad-friends-dev-secret-change-me";
  return new TextEncoder().encode(secret);
}

export async function createAdminToken(payload: {
  id: string;
  username: string;
  name: string;
}): Promise<string> {
  return await new SignJWT({ ...payload, role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(getSecret());
}

export async function verifyAdminToken(
  token: string
): Promise<{ id: string; username: string; name: string } | null> {
  try {
    const { payload } = await jwtVerify(token, getSecret());
    if (payload.role !== "admin") return null;
    return {
      id: String(payload.id),
      username: String(payload.username),
      name: String(payload.name ?? "Admin"),
    };
  } catch {
    return null;
  }
}

export async function getSession(): Promise<{
  id: string;
  username: string;
  name: string;
} | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyAdminToken(token);
}

export async function setSessionCookie(token: string) {
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

export { COOKIE_NAME };
