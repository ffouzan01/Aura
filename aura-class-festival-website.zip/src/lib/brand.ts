// Typographic brand system — no image logo is used anywhere in the interface.
export const DEFAULT_LOGO = "";
export const DEFAULT_MARK = "";

export const BRAND_DEFAULTS = {
  logo: DEFAULT_LOGO,
  mark: DEFAULT_MARK,
  logoAlt: "",
  brandName: "AURA",
  brandSub: "WIDAD FRIENDS",
};
