import { getSettings } from "./settings";
import { PORTAL_CONTENT_DEFAULTS } from "./portalContentRegistry";

export { PORTAL_CONTENT_GROUPS, PORTAL_CONTENT_DEFAULTS } from "./portalContentRegistry";
export type { PortalField, PortalGroup } from "./portalContentRegistry";

export async function getPortalContent(): Promise<Record<string, string>> {
  const settings = await getSettings();
  const out: Record<string, string> = { ...PORTAL_CONTENT_DEFAULTS };
  for (const key of Object.keys(PORTAL_CONTENT_DEFAULTS)) {
    const value = settings[key];
    if (typeof value === "string" && value.trim().length > 0) out[key] = value;
  }
  return out;
}

/** Convenience: hero copy for one portal. */
export async function getHeroCopy(portal: string) {
  const c = await getPortalContent();
  return {
    eyebrow: c[`page_${portal}_eyebrow`] ?? "",
    title: c[`page_${portal}_title`] ?? "",
    subtitle: c[`page_${portal}_subtitle`] ?? "",
  };
}

/** Poster artwork content, fully administrator-editable. */
export async function getPosterContent() {
  const s = await getSettings();
  return {
    kicker: s.poster_kicker || "WIDAD FRIENDS UNION",
    orgLine: s.poster_org_line || "Worthy Individuals for Da'wa, Arts and Discipline",
    title: s.poster_title || "Aura",
    tagline: s.poster_tagline || "Arts Unite Reality & AI",
    monthLabel: s.poster_month || "NOVEMBER 2026",
    startDay: s.poster_start_day || "10",
    endDay: s.poster_end_day || "16",
    dayRange: s.poster_day_range || "Wednesday – Sunday",
    venue: s.poster_venue || "@ Main Auditorium",
    welcome:
      s.poster_welcome || "Welcome to the ultimate celebration of art and talent..!",
    imageUrl: s.poster_url || "",
  };
}
