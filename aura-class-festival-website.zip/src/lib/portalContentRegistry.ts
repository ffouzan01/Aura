/**
 * Editable copy for every portal page. All values live in `website_settings`
 * so the administrator can rewrite any portal's wording from /admin →
 * Portal Details. Defaults below are neutral scaffolding, not festival facts.
 */

type FieldType = "text" | "textarea" | "image";

export type PortalField = {
  key: string;
  label: string;
  type: FieldType;
  default: string;
};

export type PortalGroup = {
  portal: string;
  title: string;
  description: string;
  fields: PortalField[];
};

const hero = (portal: string, label: string, eyebrow: string, title: string, subtitle: string): PortalGroup => ({
  portal,
  title: label,
  description: `Hero wording shown at the top of the ${label} portal.`,
  fields: [
    { key: `page_${portal}_eyebrow`, label: "Eyebrow / small label", type: "text", default: eyebrow },
    { key: `page_${portal}_title`, label: "Page title", type: "text", default: title },
    { key: `page_${portal}_subtitle`, label: "Subtitle", type: "textarea", default: subtitle },
  ],
});

export const PORTAL_CONTENT_GROUPS: PortalGroup[] = [
  {
    portal: "home",
    title: "Home portal",
    description: "Hero pill, about block and footer wording.",
    fields: [
      { key: "hero_badge", label: "Hero badge (above the title)", type: "text", default: "WIDAD FRIENDS UNION PRESENTS" },
      { key: "page_home_about_eyebrow", label: "About block eyebrow", type: "text", default: "ABOUT AURA" },
      { key: "page_home_about_title", label: "About block title", type: "text", default: "Crafted for talent. Built for excellence." },
      { key: "page_home_about_body", label: "About block paragraph", type: "textarea", default: "" },
      { key: "page_home_about_link", label: "About block button label", type: "text", default: "READ FULL ABOUT PAGE" },
    ],
  },
  hero("about", "About AURA", "ABOUT THE FESTIVAL", "The story behind AURA", "An official class festival — where talent meets excellence."),
  hero("events", "Events & Programs", "PROGRAMS & COMPETITIONS", "Event directory", "Every competition, stage and arena — with real-time automated program status."),
  hero("teams", "Teams & Candidates", "THE TWO HOUSES", "ALPHA vs BETA", "Two identities. One championship. Explore captains, squads and the live head-to-head race."),
  hero("schedule", "Auto Schedule", "AUTOMATED TIMETABLE", "Festival schedule", "Real-time automated program schedule — live status updates automatically."),
  hero("results", "Scores & Leaderboard", "SCORES & CHAMPIONSHIP", "Scores & leaderboard", "Live house points and program-wise scores, updated when results are published."),
  hero("gallery", "Gallery", "MEMORIES", "Festival gallery", "Stages, crowds, colours and celebrations."),
  hero("announcements", "Announcements", "OFFICIAL NOTICES", "Announcements", "Every official update from the organising committee."),
  hero("committee", "Committee", "THE PEOPLE BEHIND AURA", "Festival committee", "The Fest Coordinator, Team Leaders and Team Members who make the festival possible."),
  hero("contact", "Contact", "GET IN TOUCH", "Contact the union", "Questions about programs, registration or the festival? Send a message."),
  {
    portal: "poster",
    title: "Festival poster",
    description:
      "The official poster artwork shown across the site. Edit the wording below, or upload your own poster image to replace the built-in design.",
    fields: [
      { key: "poster_kicker", label: "Top line (union name)", type: "text", default: "WIDAD FRIENDS UNION" },
      { key: "poster_org_line", label: "Organisation line", type: "text", default: "Worthy Individuals for Da'wa, Arts and Discipline" },
      { key: "poster_title", label: "Poster wordmark", type: "text", default: "Aura" },
      { key: "poster_tagline", label: "Script tagline", type: "text", default: "Arts Unite Reality & AI" },
      { key: "poster_month", label: "Month / year label", type: "text", default: "NOVEMBER 2026" },
      { key: "poster_start_day", label: "Start day", type: "text", default: "10" },
      { key: "poster_end_day", label: "End day", type: "text", default: "16" },
      { key: "poster_day_range", label: "Day range", type: "text", default: "Wednesday – Sunday" },
      { key: "poster_venue", label: "Venue line", type: "text", default: "@ Main Auditorium" },
      { key: "poster_welcome", label: "Welcome line", type: "textarea", default: "Welcome to the ultimate celebration of art and talent..!" },
      { key: "poster_url", label: "Your poster image (upload or paste a URL — leave blank to use the built-in poster)", type: "image", default: "" },
    ],
  },
  {
    portal: "footer",
    title: "Footer & shared labels",
    description: "Wording reused across the footer and shared sections.",
    fields: [
      { key: "footer_description", label: "Footer description", type: "textarea", default: "Officially organised by WIDAD FRIENDS UNION." },
      { key: "footer_rights", label: "Copyright line", type: "text", default: "All rights reserved." },
      { key: "portal_photos_heading", label: "Portal photos default heading", type: "text", default: "Photo story" },
    ],
  },
];

export const PORTAL_CONTENT_DEFAULTS: Record<string, string> =
  Object.fromEntries(
    PORTAL_CONTENT_GROUPS.flatMap((g) => g.fields.map((f) => [f.key, f.default]))
  );
