export type SchedulableProgram = {
  eventDate?: string | null;
  startTime?: string | null;
  endTime?: string | null;
  startAt?: string | Date | null;
  endAt?: string | Date | null;
  autoSchedule?: boolean | null;
  status?: string | null;
};

export type ProgramStatusCode = "upcoming" | "ongoing" | "over" | "postponed";

export type ResolvedProgramStatus = {
  code: ProgramStatusCode;
  label: string;
  isOver: boolean;
  isLive: boolean;
  startMs: number | null;
  endMs: number | null;
};

/** Parse "14:30", "2:30 PM", "02:30 pm", "9 AM" into { hours24, minutes } */
export function parseTimeString(
  raw: string | null | undefined
): { h: number; m: number } | null {
  if (!raw) return null;
  const s = raw.trim();
  if (!s) return null;

  const ampmMatch = s.match(/^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)$/i);
  if (ampmMatch) {
    let h = parseInt(ampmMatch[1], 10);
    const m = ampmMatch[2] ? parseInt(ampmMatch[2], 10) : 0;
    const mer = ampmMatch[3].toUpperCase();
    if (h < 1 || h > 12 || m < 0 || m > 59) return null;
    if (mer === "AM" && h === 12) h = 0;
    if (mer === "PM" && h !== 12) h += 12;
    return { h, m };
  }

  const h24Match = s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
  if (h24Match) {
    const h = parseInt(h24Match[1], 10);
    const m = parseInt(h24Match[2], 10);
    if (h < 0 || h > 23 || m < 0 || m > 59) return null;
    return { h, m };
  }

  return null;
}

/** Convert any time string into "HH:MM" for <input type="time"> */
export function toTimeInputValue(raw: string | null | undefined): string {
  const parsed = parseTimeString(raw);
  if (!parsed) return "";
  return `${String(parsed.h).padStart(2, "0")}:${String(parsed.m).padStart(2, "0")}`;
}

/** Format any time string ("14:30" or "02:30 PM") cleanly as "02:30 PM" */
export function formatDisplayTime(raw: string | null | undefined): string {
  if (!raw) return "";
  const parsed = parseTimeString(raw);
  if (!parsed) return raw;
  const mer = parsed.h >= 12 ? "PM" : "AM";
  const h12 = parsed.h % 12 === 0 ? 12 : parsed.h % 12;
  return `${String(h12).padStart(2, "0")}:${String(parsed.m).padStart(2, "0")} ${mer}`;
}

/** Build epoch ms from YYYY-MM-DD + time string in local runtime clock */
export function combineDateAndTimeMs(
  dateStr: string | null | undefined,
  timeStr: string | null | undefined
): number | null {
  if (!dateStr) return null;
  const dm = dateStr.trim().match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!dm) return null;
  const parsed = parseTimeString(timeStr);
  if (!parsed) return null;
  const year = parseInt(dm[1], 10);
  const month = parseInt(dm[2], 10) - 1;
  const day = parseInt(dm[3], 10);
  const dt = new Date(year, month, day, parsed.h, parsed.m, 0, 0);
  const ms = dt.getTime();
  return Number.isNaN(ms) ? null : ms;
}

function toEpochMs(val: string | Date | null | undefined): number | null {
  if (!val) return null;
  const ms = val instanceof Date ? val.getTime() : new Date(val).getTime();
  return Number.isNaN(ms) ? null : ms;
}

/**
 * Automatically resolves whether a program is Upcoming, Live Now, Postponed,
 * or "Program is Over" once its scheduled end time has elapsed.
 */
export function resolveProgramStatus(
  program: SchedulableProgram,
  nowMs: number = Date.now()
): ResolvedProgramStatus {
  const manual = (program.status ?? "upcoming").toLowerCase();

  const explicitStart = toEpochMs(program.startAt);
  const explicitEnd = toEpochMs(program.endAt);

  const fallbackStart = combineDateAndTimeMs(program.eventDate, program.startTime);
  const fallbackEnd =
    combineDateAndTimeMs(program.eventDate, program.endTime) ??
    (fallbackStart !== null
      ? fallbackStart + 90 * 60 * 1000
      : program.eventDate
      ? combineDateAndTimeMs(program.eventDate, "23:59")
      : null);

  const startMs = explicitStart ?? fallbackStart;
  let endMs = explicitEnd ?? fallbackEnd;
  if (startMs !== null && endMs !== null && endMs < startMs) {
    // Handle cross-midnight end time
    endMs += 24 * 60 * 60 * 1000;
  }

  if (manual === "postponed") {
    return {
      code: "postponed",
      label: "Postponed",
      isOver: false,
      isLive: false,
      startMs,
      endMs,
    };
  }

  if (manual === "completed" || manual === "over") {
    return {
      code: "over",
      label: "Program is Over",
      isOver: true,
      isLive: false,
      startMs,
      endMs,
    };
  }

  const useAuto = program.autoSchedule !== false;
  if (useAuto) {
    if (endMs !== null && nowMs >= endMs) {
      return {
        code: "over",
        label: "Program is Over",
        isOver: true,
        isLive: false,
        startMs,
        endMs,
      };
    }
    if (startMs !== null && nowMs >= startMs && (endMs === null || nowMs < endMs)) {
      return {
        code: "ongoing",
        label: "Live Now",
        isOver: false,
        isLive: true,
        startMs,
        endMs,
      };
    }
  } else if (manual === "ongoing" || manual === "live") {
    return {
      code: "ongoing",
      label: "Live Now",
      isOver: false,
      isLive: true,
      startMs,
      endMs,
    };
  }

  return {
    code: "upcoming",
    label: "Upcoming",
    isOver: false,
    isLive: false,
    startMs,
    endMs,
  };
}

/** Sort key in minutes from midnight for chronological day ordering */
export function timeSortMinutes(raw: string | null | undefined): number {
  const p = parseTimeString(raw);
  if (!p) return 9999;
  return p.h * 60 + p.m;
}
