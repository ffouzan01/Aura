import type { Metadata } from "next";
import Link from "next/link";
import { Trophy, ArrowRight } from "lucide-react";
import { PageHero, Reveal, PortalHeroTitle} from "@/components/ui";
import TeamCompare from "@/components/TeamCompare";
import { getTeamsFull } from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Teams — ALPHA vs BETA",
  description:
    "Meet the two official houses of AURA: ALPHA and BETA. Captains, squads, mottos and live head-to-head standings.",
};

export const dynamic = "force-dynamic";

export default async function TeamsPage() {
  const teams = await getTeamsFull();

  const heroCopy = await getHeroCopy("teams");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <TeamCompare teams={teams} />
        <Reveal className="mt-8 text-center">
          <Link
            href="/results"
            className="group inline-flex items-center gap-2 rounded-2xl bg-midnight px-8 py-4 text-sm font-extrabold tracking-widest text-white transition hover:bg-deepnavy"
          >
            <Trophy size={16} className="text-amber-300" />
            FULL LEADERBOARD & RESULTS
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          </Link>
        </Reveal>
      </div>
      <PortalPhotos portal="teams" title="Houses in action" eyebrow="TEAM PHOTOS" />
    </main>
  );
}
