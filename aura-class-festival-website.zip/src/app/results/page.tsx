import type { Metadata } from "next";
import { PageHero, PortalHeroTitle} from "@/components/ui";
import Leaderboard from "@/components/Leaderboard";
import ResultsExplorer from "@/components/ResultsExplorer";
import {
  getCategories,
  getEventsFull,
  getPublishedPointLogs,
  getPublishedResults,
  getTeamsFull,
} from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Scores, Points & Leaderboard",
  description:
    "Live ALPHA vs BETA championship standings and program-wise scores and points from every AURA competition.",
};

export const dynamic = "force-dynamic";

export default async function ResultsPage() {
  const [teams, results, pointLogs, events, categories] = await Promise.all([
    getTeamsFull(),
    getPublishedResults(),
    getPublishedPointLogs(),
    getEventsFull(),
    getCategories(),
  ]);

  const standings = [...teams]
    .sort((a, b) => b.points - a.points || b.first - a.first)
    .map((t) => ({
      team: {
        id: t.id,
        slug: t.slug,
        name: t.name,
        tagline: t.tagline,
        emblem: t.emblem,
        colorPrimary: t.colorPrimary,
        colorSecondary: t.colorSecondary,
      },
      points: t.points,
      first: t.first,
      second: t.second,
      third: t.third,
      wins: t.wins,
      eventWise: [
        ...results
          .filter((r) => r.team?.id === t.id)
          .map((r) => ({
            eventTitle: r.event?.title ?? "Program",
            eventSlug: r.event?.slug ?? "",
            position: r.position,
            points: r.points,
            score: r.score,
            grade: r.grade,
            participantName: r.chestNumber
              ? `${r.participantName} (#${r.chestNumber})`
              : r.participantName,
          })),
        ...pointLogs
          .filter((l) => l.teamId === t.id)
          .map((l) => ({
            eventTitle: l.title,
            eventSlug: "",
            position: 0,
            points: l.points,
            score: "",
            grade: "",
            participantName: l.note || "House Points",
          })),
      ],
    }));

  const declaredSlugs = new Set(
    results.filter((r) => r.event).map((r) => r.event!.slug)
  );
  const pending = events
    .filter((e) => !declaredSlugs.has(e.slug))
    .map((e) => ({ slug: e.slug, title: e.title, venue: e.venue }));

  const heroCopy = await getHeroCopy("results");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <Leaderboard initial={standings} />
        <ResultsExplorer
          results={results.map((r) => ({
            id: r.id,
            position: r.position,
            chestNumber: r.chestNumber,
            participantName: r.participantName,
            score: r.score,
            grade: r.grade,
            points: r.points,
            note: r.note,
            event: r.event
              ? {
                  slug: r.event.slug,
                  title: r.event.title,
                  eventType: r.event.eventType,
                  venue: r.event.venue,
                }
              : null,
            category: r.category
              ? { name: r.category.name, color: r.category.color }
              : null,
            team: r.team
              ? { name: r.team.name, colorPrimary: r.team.colorPrimary }
              : null,
          }))}
          pendingEvents={pending}
          categories={categories.map((c) => c.name)}
        />
      </div>
      <PortalPhotos portal="results" title="Winning moments" eyebrow="RESULT PHOTOS" />
    </main>
  );
}
