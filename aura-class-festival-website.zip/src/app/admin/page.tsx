import type { Metadata } from "next";
import AdminDashboard from "@/components/AdminDashboard";

export const metadata: Metadata = {
  title: "Admin Portal",
  description: "Secure admin console for managing AURA festival events, teams, results and content.",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

export default function AdminPage() {
  return (
    <main>
      <AdminDashboard />
    </main>
  );
}
