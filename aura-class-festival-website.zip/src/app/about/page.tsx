import type { Metadata } from "next";
import Link from "next/link";
import {
  Sparkle,
  Sparkles,
  Eye,
  Target,
  Flag,
  Star,
  ArrowRight,
  Users,
  Trophy,
  CalendarDays,
  HeartHandshake,
} from "lucide-react";
import { PageHero, Reveal, SectionHeading, AnimatedNumber, PortalHeroTitle} from "@/components/ui";
import { getSettings } from "@/lib/settings";
import { getCategories, getEventsFull } from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy, getPosterContent } from "@/lib/portalContent";
import AuraPoster from "@/components/AuraPoster";

export const metadata: Metadata = {
  title: "About AURA",
  description:
    "What is AURA? Learn about the festival, WIDAD FRIENDS UNION, our vision, mission and objectives.",
};

export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const [settings, events, categories] = await Promise.all([
    getSettings(),
    getEventsFull(),
    getCategories(),
  ]);

  const objectives = [
    {
      icon: Star,
      title: "Discover talent",
      text: "Give every student a stage — from first-time performers to seasoned champions.",
    },
    {
      icon: Users,
      title: "Build community",
      text: "Unite classrooms into two houses that compete fiercely and celebrate together.",
    },
    {
      icon: Trophy,
      title: "Reward excellence",
      text: "Transparent judging, fair points and a championship race everyone can follow.",
    },
    {
      icon: HeartHandshake,
      title: "Nurture leadership",
      text: "Student-led organising, volunteering and mentorship at every level of the fest.",
    },
  ];

  const highlights = [
    { value: events.length, suffix: "+", label: "Competitions" },
    { value: categories.length, suffix: "", label: "Categories" },
    { value: 2, suffix: "", label: "Houses" },
    { value: 3, suffix: "", label: "Festival days" },
  ];

  const heroCopy = await getHeroCopy("about");
  const poster = await getPosterContent();
  return (
    <main className="bg-white">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />

      {/* What is AURA */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <Reveal>
            <p className="inline-flex items-center gap-2 rounded-full border border-royal/15 bg-royal/5 px-4 py-1.5 text-[11px] font-extrabold tracking-[0.22em] text-royal">
              <Sparkles size={12} /> WHAT IS AURA?
            </p>
            <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-midnight sm:text-4xl">
              A festival with its own <span className="text-gradient-blue">gravitas.</span>
            </h2>
            <p className="mt-5 text-[15px] leading-relaxed text-slate-600 sm:text-base">
              {settings.about_aura}
            </p>
            <p className="mt-4 text-[15px] leading-relaxed text-slate-600">
              Across three days, classrooms transform into auditoriums, studios and
              arenas. Literary battles sharpen minds in the morning, art and music
              fill the afternoons, and the evenings belong to the stage — all
              building towards one unforgettable championship verdict.
            </p>
            <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {highlights.map((h) => (
                <div
                  key={h.label}
                  className="rounded-2xl border border-royal/12 bg-mist p-4 text-center"
                >
                  <p className="text-2xl font-extrabold text-midnight sm:text-3xl">
                    <AnimatedNumber value={h.value} />
                    {h.suffix}
                  </p>
                  <p className="mt-1 text-[10px] font-extrabold tracking-[0.18em] text-greytext">
                    {h.label.toUpperCase()}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>
          <Reveal delay={0.12}>
            <AuraPoster {...poster} />
          </Reveal>
        </div>
      </section>

      {/* Organizer */}
      <section className="bg-midnight">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 sm:py-20 lg:grid-cols-[1fr_1.2fr]">
          <Reveal>
            <div className="relative overflow-hidden rounded-[28px] border border-cream/15 poster-paper poster-grain poster-crease px-7 py-10 text-center sm:px-9">
              <Sparkle
                aria-hidden
                className="pointer-events-none absolute -right-2 -top-2 h-20 w-20 text-cream/10"
                fill="currentColor"
              />
              <p className="font-script text-3xl leading-tight text-cream sm:text-4xl">
                {poster.tagline}
              </p>
              <div className="mx-auto mt-5 h-px w-24 bg-cream/25" />
              <p className="mx-auto mt-5 max-w-xs text-[12.5px] font-semibold leading-relaxed text-cream/75">
                {poster.welcome}
              </p>
              <div className="mt-6 flex items-center justify-center gap-2.5">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-cyan text-xl font-extrabold text-deepnavy">
                  {poster.startDay}
                </span>
                <span className="font-script text-xl text-cream/80">to</span>
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-sun text-xl font-extrabold text-deepnavy">
                  {poster.endDay}
                </span>
              </div>
              <p className="mt-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-cream/70">
                {poster.monthLabel} · {poster.dayRange}
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-1.5 text-[11px] font-extrabold tracking-[0.22em] text-sky">
              <Flag size={12} /> THE ORGANISERS
            </p>
            <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
              WIDAD FRIENDS UNION
            </h2>
            <p className="mt-5 text-[15px] leading-relaxed text-slate-300">
              {settings.about_organizer}
            </p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <Link
                href="/committee"
                className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white px-7 py-3.5 text-sm font-extrabold tracking-widest text-midnight transition hover:bg-sky"
              >
                MEET THE COMMITTEE
                <ArrowRight size={15} />
              </Link>
              <Link
                href="/contact"
                className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/25 px-7 py-3.5 text-sm font-extrabold tracking-widest text-white transition hover:bg-white/10"
              >
                CONTACT US
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Vision / Mission */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-20">
        <SectionHeading
          eyebrow="PURPOSE"
          title={
            <>
              Vision, mission <span className="text-gradient-blue">& objectives</span>
            </>
          }
          subtitle="The principles that shape every event, every rule and every celebration at AURA."
        />
        <div className="mt-10 grid gap-5 md:grid-cols-2">
          <Reveal>
            <div className="card-hover h-full rounded-3xl border border-slate-200/80 bg-gradient-to-br from-mist to-white p-7 sm:p-8">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-royal to-electric text-white shadow-lg">
                <Eye size={20} />
              </div>
              <h3 className="mt-5 text-xl font-extrabold text-midnight">Our vision</h3>
              <p className="mt-3 leading-relaxed text-slate-600">{settings.vision}</p>
            </div>
          </Reveal>
          <Reveal delay={0.08}>
            <div className="card-hover h-full rounded-3xl bg-midnight p-7 text-white sm:p-8">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white/10 text-sky">
                <Target size={20} />
              </div>
              <h3 className="mt-5 text-xl font-extrabold">Our mission</h3>
              <p className="mt-3 leading-relaxed text-slate-300">{settings.mission}</p>
            </div>
          </Reveal>
        </div>
        <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {objectives.map((o, i) => (
            <Reveal key={o.title} delay={i * 0.07}>
              <div className="card-hover h-full rounded-3xl border border-slate-200/80 bg-white p-6">
                <o.icon size={22} className="text-royal" />
                <h4 className="mt-3 text-[16px] font-extrabold text-midnight">{o.title}</h4>
                <p className="mt-2 text-sm leading-relaxed text-greytext">{o.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Festival days CTA */}
      <section className="bg-mist">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-16">
          <Reveal>
            <div className="flex flex-col items-center justify-between gap-6 rounded-[28px] bg-gradient-to-r from-deepnavy via-royal to-electric px-6 py-10 text-center sm:px-12 lg:flex-row lg:text-left">
              <div>
                <p className="flex items-center justify-center gap-2 text-[11px] font-extrabold tracking-[0.28em] text-sky lg:justify-start">
                  <CalendarDays size={14} /> SAVE THE DATES
                </p>
                <h3 className="mt-3 text-2xl font-extrabold text-white sm:text-3xl">
                  Three days. Two houses. One champion.
                </h3>
                {settings.venue && (
                  <p className="mt-2 text-sm font-semibold text-blue-100">{settings.venue}</p>
                )}
              </div>
              <Link
                href="/schedule"
                className="group inline-flex shrink-0 items-center gap-2 rounded-2xl bg-white px-8 py-4 text-sm font-extrabold tracking-widest text-royal shadow-xl transition hover:bg-ice"
              >
                VIEW SCHEDULE
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
      <PortalPhotos portal="about" title="Life at AURA" eyebrow="ABOUT AURA IN PICTURES" />
    </main>
  );
}
