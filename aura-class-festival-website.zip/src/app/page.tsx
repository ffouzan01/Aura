import Link from "next/link";
import { ArrowRight, Eye, Target } from "lucide-react";
import Hero from "@/components/Hero";
import { Reveal } from "@/components/ui";
import PortalPhotos from "@/components/PortalPhotos";
import { getSettings, DEFAULT_SETTINGS } from "@/lib/settings";
import { getPortalContent } from "@/lib/portalContent";
import { getPosterContent } from "@/lib/portalContent";
import AuraPoster from "@/components/AuraPoster";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [settings, copy, poster] = await Promise.all([
    getSettings(),
    getPortalContent(),
    getPosterContent(),
  ]);

  const motto =
    settings.festival_motto &&
    !settings.festival_motto.toLowerCase().includes("celebration of talent, creativity")
      ? settings.festival_motto
      : DEFAULT_SETTINGS.festival_motto;

  return (
    <main className="bg-white">
      <Hero
        tagline={settings.festival_tagline}
        motto={motto}
        title={poster.title}
        scriptLine={poster.tagline}
        badge={settings.hero_badge}
      />

      {/* Editorial About AURA — the only section accompanying the main Home Hero */}
      <section id="about" className="relative overflow-hidden bg-mist">
        <div className="bg-dot-grid pointer-events-none absolute inset-y-0 right-0 w-1/3 opacity-45" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 py-20 sm:px-6 sm:py-28 lg:grid-cols-[1.1fr_0.9fr]">
          <Reveal>
            <p className="inline-flex items-center gap-2 rounded-full border border-royal/15 bg-white px-4 py-1.5 text-[11px] font-extrabold tracking-[0.22em] text-royal">
              <span className="h-1.5 w-1.5 rounded-full bg-royal" />
              {copy.page_home_about_eyebrow}
            </p>
            <h2 className="font-display mt-4 text-3xl font-black leading-[1.08] tracking-tight text-midnight sm:text-4xl lg:text-[42px]">
              {copy.page_home_about_title}
            </h2>
            <p className="mt-5 text-[15.5px] leading-relaxed text-greytext">
              {copy.page_home_about_body || settings.about_aura}
            </p>

            <div className="mt-7 grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-royal/12 bg-white p-5 shadow-sm">
                <p className="flex items-center gap-2 text-[11.5px] font-extrabold tracking-widest text-royal">
                  <Eye size={14} /> VISION
                </p>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">
                  {settings.vision}
                </p>
              </div>
              <div className="rounded-2xl border border-royal/12 bg-white p-5 shadow-sm">
                <p className="flex items-center gap-2 text-[11.5px] font-extrabold tracking-widest text-royal">
                  <Target size={14} /> MISSION
                </p>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">
                  {settings.mission}
                </p>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                href="/about"
                className="group inline-flex items-center gap-2 rounded-2xl bg-midnight px-7 py-3.5 text-xs font-extrabold tracking-[0.2em] text-white transition hover:bg-deepnavy"
              >
                {copy.page_home_about_link}
                <ArrowRight
                  size={15}
                  className="transition-transform group-hover:translate-x-1"
                />
              </Link>
            </div>
          </Reveal>

          <Reveal delay={0.12}>
            <AuraPoster {...poster} compact />
          </Reveal>
        </div>
      </section>
      <PortalPhotos portal="home" title="AURA through the lens" eyebrow="FESTIVAL PHOTOS" limit={8} />
    </main>
  );
}
