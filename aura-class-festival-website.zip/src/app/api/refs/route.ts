import { NextResponse } from "next/server";
import { db } from "@/db";
import { eventCategories, events, teams } from "@/db/schema";
import { asc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * Public reference data used to populate admin dropdowns (Houses & Programs)
 * and any other client that needs the current festival structure.
 */
export async function GET() {
  try {
    await ensureSeeded();
    const [teamRows, eventRows, catRows] = await Promise.all([
      db.select().from(teams).orderBy(asc(teams.name)),
      db.select().from(events).orderBy(asc(events.eventDate), asc(events.title)),
      db.select().from(eventCategories),
    ]);
    const catById = new Map(catRows.map((c) => [c.id, c]));

    return NextResponse.json({
      houses: teamRows.map((t) => ({
        id: t.id,
        name: t.name,
        slug: t.slug,
        colorPrimary: t.colorPrimary,
        colorSecondary: t.colorSecondary,
        emblem: t.emblem,
      })),
      programs: eventRows.map((e) => ({
        id: e.id,
        title: e.title,
        slug: e.slug,
        eventDate: e.eventDate,
        category: e.categoryId ? catById.get(e.categoryId)?.name ?? "" : "",
        status: e.status,
      })),
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Failed to load references" },
      { status: 500 }
    );
  }
}
