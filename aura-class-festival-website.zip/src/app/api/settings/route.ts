import { NextResponse } from "next/server";
import { getSettings } from "@/lib/settings";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const settings = await getSettings();
  return NextResponse.json({ settings });
}
