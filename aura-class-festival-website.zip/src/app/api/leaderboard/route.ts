import { NextResponse } from "next/server";
import { db } from "@/db";
import { events, results, teamPointLogs, teams } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const [teamRows, publishedResults, publishedLogs, eventRows] = await Promise.all([
    db.select().from(teams),
    db.select().from(results).where(eq(results.isPublished, true)),
    db.select().from(teamPointLogs).where(eq(teamPointLogs.isPublished, true)),
    db.select().from(events),
  ]);

  const eventById = new Map(eventRows.map((e) => [e.id, e]));
  const standings = teamRows.map((t) => {
    const teamResults = publishedResults.filter((r) => r.teamId === t.id);
    const teamLogs = publishedLogs.filter((l) => l.teamId === t.id);
    const resultPoints = teamResults.reduce((s, r) => s + (r.points ?? 0), 0);
    const bonusPoints = teamLogs.reduce((s, l) => s + (l.points ?? 0), 0);
    const points = resultPoints + bonusPoints;
    const first = teamResults.filter((r) => r.position === 1).length;
    const second = teamResults.filter((r) => r.position === 2).length;
    const third = teamResults.filter((r) => r.position === 3).length;

    const eventWise = [
      ...teamResults.map((r) => ({
        eventTitle: eventById.get(r.eventId)?.title ?? "Program",
        eventSlug: eventById.get(r.eventId)?.slug ?? "",
        position: r.position,
        points: r.points,
        score: r.score,
        grade: r.grade,
        participantName: r.chestNumber
          ? `${r.participantName} (${r.chestNumber})`
          : r.participantName,
      })),
      ...teamLogs.map((l) => ({
        eventTitle: l.title,
        eventSlug: "",
        position: 0,
        points: l.points,
        score: "",
        grade: "",
        participantName: l.note || "House Points",
      })),
    ];

    return {
      team: t,
      points,
      first,
      second,
      third,
      wins: teamResults.length,
      eventWise,
    };
  });

  standings.sort((a, b) => b.points - a.points || b.first - a.first);

  const totalPublishedEvents = new Set(publishedResults.map((r) => r.eventId)).size;

  return NextResponse.json({
    standings,
    totalPublishedEvents,
    updatedAt: new Date().toISOString(),
  });
}
