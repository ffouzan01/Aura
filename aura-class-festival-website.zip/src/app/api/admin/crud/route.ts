import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  announcements,
  committeeMembers,
  contactMessages,
  eventCategories,
  events,
  galleryItems,
  participants,
  portalPhotos,
  results,
  teamMembers,
  teamPointLogs,
  teams,
  websiteSettings,
} from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { slugify } from "@/lib/settings";
import { OFFICIAL_CATEGORIES } from "@/lib/categories";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

const TABLES: Record<string, any> = {
  events,
  categories: eventCategories,
  teams,
  members: teamMembers,
  results,
  pointlogs: teamPointLogs,
  participants,
  announcements,
  gallery: galleryItems,
  portalphotos: portalPhotos,
  committee: committeeMembers,
  messages: contactMessages,
};

function clean(obj: Record<string, unknown>) {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined) continue;
    if (k === "id" || k === "createdAt" || k === "updatedAt" || k === "publishedAt") continue;
    if (v === "" && (k === "categoryId" || k === "teamId" || k === "eventId" || k === "eventDate" || k === "publishDate")) {
      out[k] = null;
      continue;
    }
    if (k === "startAt" || k === "endAt") {
      if (!v) {
        out[k] = null;
      } else {
        const dt = new Date(String(v));
        out[k] = Number.isNaN(dt.getTime()) ? null : dt;
      }
      continue;
    }
    out[k] = v;
  }
  return out;
}


/**
 * Resolves a `categorySlug` from the admin form into a real category record,
 * creating the official category row when it is missing.
 */
async function resolveCategorySlug(body: Record<string, unknown>) {
  const slug = body.categorySlug;
  delete body.categorySlug;
  if (typeof slug !== "string" || !slug) return;
  const official = OFFICIAL_CATEGORIES.find((c) => c.slug === slug);
  if (!official) return;

  const existing = await db
    .select()
    .from(eventCategories)
    .where(eq(eventCategories.slug, official.slug))
    .limit(1);

  if (existing[0]) {
    body.categoryId = existing[0].id;
    return;
  }

  const [created] = await db
    .insert(eventCategories)
    .values({
      slug: official.slug,
      name: official.name,
      displayOrder:
        OFFICIAL_CATEGORIES.findIndex((c) => c.slug === official.slug) + 1,
    })
    .onConflictDoNothing({ target: eventCategories.slug })
    .returning();
  if (created) body.categoryId = created.id;
}

async function requireAdmin() {
  return await getSession();
}

export async function GET(req: Request) {
  if (!(await requireAdmin()))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const resource = searchParams.get("resource") ?? "";

  try {
    await ensureSeeded();
    switch (resource) {
      case "settings": {
        const rows = await db.select().from(websiteSettings);
        return NextResponse.json({ data: rows });
      }
      case "events":
        return NextResponse.json({
          data: await db.select().from(events).orderBy(asc(events.eventDate), asc(events.startTime), asc(events.title)),
        });
      case "categories":
        return NextResponse.json({
          data: await db.select().from(eventCategories).orderBy(asc(eventCategories.displayOrder)),
        });
      case "teams":
        return NextResponse.json({ data: await db.select().from(teams) });
      case "members":
        return NextResponse.json({
          data: await db.select().from(teamMembers).orderBy(asc(teamMembers.positionOrder)),
        });
      case "results":
        return NextResponse.json({
          data: await db.select().from(results).orderBy(desc(results.createdAt)),
        });
      case "pointlogs":
        return NextResponse.json({
          data: await db.select().from(teamPointLogs).orderBy(desc(teamPointLogs.createdAt)),
        });
      case "participants":
        return NextResponse.json({
          data: await db.select().from(participants).orderBy(desc(participants.createdAt)),
        });
      case "announcements":
        return NextResponse.json({
          data: await db.select().from(announcements).orderBy(desc(announcements.createdAt)),
        });
      case "gallery":
        return NextResponse.json({
          data: await db.select().from(galleryItems).orderBy(asc(galleryItems.displayOrder)),
        });
      case "portalphotos":
        return NextResponse.json({
          data: await db
            .select()
            .from(portalPhotos)
            .orderBy(asc(portalPhotos.portal), asc(portalPhotos.displayOrder)),
        });
      case "committee":
        return NextResponse.json({
          data: await db.select().from(committeeMembers).orderBy(asc(committeeMembers.displayOrder)),
        });
      case "messages":
        return NextResponse.json({
          data: await db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)),
        });
      default:
        return NextResponse.json({ error: "Unknown resource" }, { status: 400 });
    }
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Failed to load" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  if (!(await requireAdmin()))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const resource = searchParams.get("resource") ?? "";
  const body = clean(await req.json());

  try {
    if (resource === "events") await resolveCategorySlug(body);

    if (
      (resource === "events" || resource === "categories") &&
      !body.slug &&
      (body.title || body.name)
    ) {
      body.slug = slugify(String(body.title ?? body.name)) + "-" + Date.now().toString(36);
    }

    if (resource === "results" && body.isPublished) {
      body.publishedAt = new Date();
    }

    const table = TABLES[resource];
    if (!table) return NextResponse.json({ error: "Unknown resource" }, { status: 400 });
    const rows = (await db.insert(table).values(body).returning()) as unknown[];
    return NextResponse.json({ data: rows[0] }, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Create failed" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  if (!(await requireAdmin()))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const resource = searchParams.get("resource") ?? "";

  try {
    if (resource === "settings") {
      const body = await req.json();
      const entries: [string, string][] = Array.isArray(body)
        ? body.map((item: { key: string; value: string } | [string, string]) =>
            Array.isArray(item) ? item : [String(item.key), String(item.value ?? "")]
          )
        : [[String(body.key), String(body.value ?? "")]];
      for (const [key, value] of entries) {
        await db
          .insert(websiteSettings)
          .values({ key, value })
          .onConflictDoUpdate({
            target: websiteSettings.key,
            set: { value, updatedAt: new Date() },
          });
      }
      return NextResponse.json({ ok: true });
    }

    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    const body = clean(await req.json());
    if (resource === "events") await resolveCategorySlug(body);
    if (resource === "results" && body.isPublished) {
      body.publishedAt = new Date();
    }
    if (resource === "events") {
      body.updatedAt = new Date();
    }

    const table = TABLES[resource];
    if (!table) return NextResponse.json({ error: "Unknown resource" }, { status: 400 });
    const rows = (await db
      .update(table)
      .set(body)
      .where(eq(table.id, id))
      .returning()) as unknown[];
    return NextResponse.json({ data: rows[0] ?? null });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Update failed" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  if (!(await requireAdmin()))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const resource = searchParams.get("resource") ?? "";
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

  try {
    const table = TABLES[resource];
    if (!table || resource === "settings")
      return NextResponse.json({ error: "Unknown resource" }, { status: 400 });
    await db.delete(table).where(eq(table.id, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Delete failed" },
      { status: 500 }
    );
  }
}
