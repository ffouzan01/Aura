import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  announcements,
  committeeMembers,
  contactMessages,
  events,
  participants,
  results,
  teamPointLogs,
  teams,
} from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { resolveProgramStatus } from "@/lib/schedule";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [
    teamRows,
    eventRows,
    participantRows,
    committeeRows,
    publishedResults,
    publishedLogs,
    recentAnn,
    unread,
  ] = await Promise.all([
    db.select().from(teams),
    db.select().from(events),
    db.select().from(participants),
    db.select().from(committeeMembers),
    db.select().from(results).where(eq(results.isPublished, true)),
    db.select().from(teamPointLogs).where(eq(teamPointLogs.isPublished, true)),
    db.select().from(announcements).orderBy(desc(announcements.createdAt)).limit(5),
    db.select().from(contactMessages).where(eq(contactMessages.isRead, false)),
  ]);

  const now = Date.now();
  const statuses = eventRows.map((e) => resolveProgramStatus(e, now));

  const standings = teamRows.map((t) => {
    const rPts = publishedResults
      .filter((r) => r.teamId === t.id)
      .reduce((s, r) => s + (r.points ?? 0), 0);
    const bPts = publishedLogs
      .filter((l) => l.teamId === t.id)
      .reduce((s, l) => s + (l.points ?? 0), 0);
    return {
      id: t.id,
      name: t.name,
      slug: t.slug,
      points: rPts + bPts,
    };
  });

  return NextResponse.json({
    totals: {
      events: eventRows.length,
      participants: participantRows.length,
      committee: committeeRows.length,
      publishedResults: new Set(publishedResults.map((r) => r.eventId)).size,
      upcoming: statuses.filter((s) => s.code === "upcoming").length,
      ongoing: statuses.filter((s) => s.code === "ongoing").length,
      over: statuses.filter((s) => s.code === "over").length,
      unreadMessages: unread.length,
    },
    standings,
    recentAnnouncements: recentAnn,
  });
}
