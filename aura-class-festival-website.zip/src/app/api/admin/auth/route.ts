import { NextResponse } from "next/server";
import { db } from "@/db";
import { admins } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import {
  createAdminToken,
  getSession,
  setSessionCookie,
  clearSessionCookie,
} from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ admin: null }, { status: 401 });
  return NextResponse.json({ admin: session });
}

export async function POST(req: Request) {
  await ensureSeeded();
  try {
    const body = await req.json();
    const rawUsername = String(body.username ?? "admin").trim().toLowerCase() || "admin";
    const password = String(body.password ?? "");

    if (!password) {
      return NextResponse.json(
        { error: "Password is required." },
        { status: 400 }
      );
    }

    // Look up matching username, falling back to primary admin if user entered "aura"
    let rows = await db
      .select()
      .from(admins)
      .where(eq(admins.username, rawUsername))
      .limit(1);

    if (rows.length === 0 && (rawUsername === "aura" || rawUsername === "widad")) {
      rows = await db
        .select()
        .from(admins)
        .where(eq(admins.username, "admin"))
        .limit(1);
    }

    const admin = rows[0];
    if (!admin) {
      return NextResponse.json({ error: "Invalid credentials." }, { status: 401 });
    }

    const ok = await bcrypt.compare(password, admin.passwordHash);
    if (!ok) {
      return NextResponse.json({ error: "Incorrect password." }, { status: 401 });
    }

    const token = await createAdminToken({
      id: admin.id,
      username: admin.username,
      name: admin.name,
    });
    await setSessionCookie(token);
    return NextResponse.json({
      admin: { id: admin.id, username: admin.username, name: admin.name },
    });
  } catch {
    return NextResponse.json({ error: "Login failed. Try again." }, { status: 500 });
  }
}

export async function DELETE() {
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
