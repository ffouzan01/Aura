import type { Metadata } from "next";
import { PageHero, PortalHeroTitle} from "@/components/ui";
import ScheduleView from "@/components/ScheduleView";
import { getEventsFull } from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Automated Time Schedule",
  description:
    "The official AURA automated timetable — live program status that marks programs as over automatically once their scheduled time finishes.",
};

export const dynamic = "force-dynamic";

export default async function SchedulePage() {
  const events = await getEventsFull();
  const heroCopy = await getHeroCopy("schedule");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
        <ScheduleView
          events={events.map((e) => ({
            id: e.id,
            slug: e.slug,
            title: e.title,
            venue: e.venue,
            eventDate: e.eventDate,
            startTime: e.startTime,
            endTime: e.endTime,
            startAtIso: e.startAtIso,
            endAtIso: e.endAtIso,
            autoSchedule: e.autoSchedule,
            eventType: e.eventType,
            participatingTeams: e.participatingTeams,
            status: e.status,
            categoryName: e.category?.name ?? "General",
            categoryColor: e.category?.color ?? "#1769E8",
          }))}
        />
      </div>
      <PortalPhotos portal="schedule" title="Festival days" eyebrow="SCHEDULE PHOTOS" />
    </main>
  );
}
