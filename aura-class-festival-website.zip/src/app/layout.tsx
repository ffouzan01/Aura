import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Plus_Jakarta_Sans, Baloo_2, Caveat } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FestivalHubButton from "@/components/FestivalHubButton";
import { getSettings } from "@/lib/settings";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-jakarta",
  display: "swap",
});

/* Poster wordmark face — rounded, chunky, friendly */
const baloo = Baloo_2({
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  variable: "--font-baloo",
  display: "swap",
});

/* Poster script line — "Arts Unite Reality & AI" */
const caveat = Caveat({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  variable: "--font-caveat",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "AURA — Where Talent Meets Excellence | Widad Friends Union",
    template: "%s · AURA Festival",
  },
  description:
    "AURA is the official class festival organised by WIDAD FRIENDS UNION. Explore events, automated schedule, teams ALPHA vs BETA, candidates, committee and live scores.",
  keywords: [
    "AURA",
    "WIDAD FRIENDS",
    "class festival",
    "ALPHA",
    "BETA",
    "leaderboard",
    "events",
  ],
  openGraph: {
    title: "AURA — Where Talent Meets Excellence",
    description:
      "The official class festival by WIDAD FRIENDS UNION. ALPHA vs BETA. Events, automated schedule, candidates & live scores.",
    type: "website",
    siteName: "AURA Festival",
  },
  twitter: {
    card: "summary_large_image",
    title: "AURA — Where Talent Meets Excellence",
    description:
      "Official class festival by WIDAD FRIENDS UNION. Explore events, teams, schedule & scores.",
  },
  metadataBase: new URL("https://aura-festival.example"),
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const settings = await getSettings();
  return (
    <html lang="en" className={`${jakarta.variable} ${baloo.variable} ${caveat.variable}`}>
      <body className="min-h-screen bg-white text-slate-900 antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-royal focus:px-4 focus:py-2 focus:text-white"
        >
          Skip to content
        </a>
        <Navbar />
        <div id="main-content">{children}</div>
        <FestivalHubButton />
        <Footer initial={settings} />
      </body>
    </html>
  );
}
