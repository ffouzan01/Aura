import type { Metadata } from "next";
import { Megaphone, Pin, CalendarDays } from "lucide-react";
import { PageHero, Reveal, EmptyState, PortalHeroTitle} from "@/components/ui";
import { getAnnouncementsPublic } from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Announcements",
  description: "Official AURA updates — event notices, schedule changes, registration news and instructions.",
};

export const dynamic = "force-dynamic";

const PRIORITY = {
  urgent: { label: "URGENT", cls: "bg-red-500 text-white" },
  important: { label: "IMPORTANT", cls: "bg-royal text-white" },
  info: { label: "UPDATE", cls: "bg-sky/20 text-deepnavy" },
} as const;

export default async function AnnouncementsPage() {
  const items = await getAnnouncementsPublic();
  const pinned = items.filter((a) => a.priority === "urgent");
  const rest = items.filter((a) => a.priority !== "urgent");

  const card = (a: (typeof items)[number], i: number) => {
    const p = PRIORITY[a.priority as keyof typeof PRIORITY] ?? PRIORITY.info;
    return (
      <Reveal key={a.id} delay={Math.min(i * 0.05, 0.3)}>
        <article
          className={`rounded-3xl border p-6 sm:p-7 ${
            a.priority === "urgent"
              ? "border-red-200 bg-gradient-to-br from-red-50 to-white"
              : "border-slate-200/80 bg-white"
          }`}
        >
          <div className="flex flex-wrap items-center gap-2">
            <span className={`rounded-full px-3 py-1 text-[10px] font-extrabold tracking-widest ${p.cls}`}>
              {a.priority === "urgent" ? <span className="inline-flex items-center gap-1"><Pin size={10} /> {p.label}</span> : p.label}
            </span>
            <span className="rounded-full bg-mist px-3 py-1 text-[10px] font-extrabold tracking-widest text-slate-500">
              {a.category.toUpperCase()}
            </span>
          </div>
          <h2 className="mt-3 text-xl font-extrabold leading-snug text-midnight">{a.title}</h2>
          <p className="mt-2 text-[14.5px] leading-relaxed text-slate-600">{a.description}</p>
          <p className="mt-4 flex items-center gap-1.5 text-xs font-extrabold tracking-widest text-slate-400">
            <CalendarDays size={13} />
            {a.publishDate
              ? new Date(a.publishDate + "T00:00:00").toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })
              : new Date(a.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
          </p>
        </article>
      </Reveal>
    );
  };

  const heroCopy = await getHeroCopy("announcements");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 sm:py-14">
        {items.length === 0 ? (
          <EmptyState
            title="No announcements yet"
            message="Official updates will be published here. Check back soon."
          />
        ) : (
          <div className="space-y-4">
            {pinned.length > 0 && (
              <div className="mb-2 flex items-center gap-2 text-[12px] font-extrabold tracking-[0.24em] text-red-500">
                <Megaphone size={14} /> PINNED · NEEDS ATTENTION
              </div>
            )}
            {pinned.map(card)}
            {pinned.length > 0 && rest.length > 0 && (
              <div className="flex items-center gap-4 pt-4">
                <div className="h-px flex-1 bg-slate-200" />
                <span className="text-[11px] font-extrabold tracking-[0.24em] text-slate-400">
                  ALL UPDATES
                </span>
                <div className="h-px flex-1 bg-slate-200" />
              </div>
            )}
            {rest.map(card)}
          </div>
        )}
      </div>
      <PortalPhotos portal="announcements" title="Around the festival" eyebrow="NOTICE PHOTOS" />
    </main>
  );
}
