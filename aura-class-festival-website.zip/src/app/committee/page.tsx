import type { Metadata } from "next";
import { Mail, Phone, Crown, Users, ClipboardList, HeartHandshake } from "lucide-react";
import { PageHero, Reveal, EmptyState, PortalHeroTitle} from "@/components/ui";
import { getCommitteePublic } from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Committee",
  description: "Meet the Fest Coordinator, Team Leaders and Team Members behind the AURA festival.",
};

export const dynamic = "force-dynamic";

const GROUPS = [
  { key: "leadership", label: "Fest Coordinator", icon: Crown, legacy: ["coordinator"] },
  { key: "event", label: "Team Leaders", icon: ClipboardList, legacy: [] as string[] },
  { key: "organizing", label: "Team Members", icon: HeartHandshake, legacy: [] as string[] },
];

export default async function CommitteePage() {
  const members = await getCommitteePublic();

  const heroCopy = await getHeroCopy("committee");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-7xl space-y-12 px-4 py-10 sm:px-6 sm:py-14">
        {members.length === 0 && (
          <EmptyState
            title="Committee to be announced"
            message="Official appointments will be published here by WIDAD FRIENDS UNION."
          />
        )}
        {GROUPS.map((g) => {
          const list = members.filter(
            (m) => m.category === g.key || g.legacy.includes(m.category)
          );
          if (list.length === 0) return null;
          return (
            <section key={g.key}>
              <Reveal>
                <div className="flex items-center gap-3">
                  <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-royal to-electric text-white shadow-md">
                    <g.icon size={19} />
                  </span>
                  <h2 className="text-xl font-extrabold tracking-tight text-midnight sm:text-2xl">
                    {g.label}
                  </h2>
                  <div className="h-px flex-1 bg-gradient-to-r from-royal/25 to-transparent" />
                </div>
              </Reveal>
              <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {list.map((m, i) => (
                  <Reveal key={m.id} delay={Math.min(i * 0.06, 0.3)}>
                    <article className="card-hover h-full rounded-3xl border border-slate-200/80 bg-white p-6 text-center">
                      <div className="relative mx-auto h-20 w-20">
                        {m.photoUrl ? (
                          <img
                            src={m.photoUrl}
                            alt={m.name}
                            loading="lazy"
                            className="h-20 w-20 rounded-3xl object-cover"
                          />
                        ) : (
                          <span className="grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-royal to-deepnavy text-2xl font-extrabold text-white">
                            {m.name.charAt(0)}
                          </span>
                        )}
                        {m.isPlaceholder && (
                          <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-amber-100 px-2.5 py-0.5 text-[9px] font-extrabold tracking-widest text-amber-700">
                            TBA
                          </span>
                        )}
                      </div>
                      <h3 className="mt-4 text-[15px] font-extrabold leading-snug text-midnight">
                        {m.name}
                      </h3>
                      <p className="mt-1 text-[12px] font-extrabold tracking-wide text-royal">
                        {m.position}
                      </p>
                      {m.bio && (
                        <p className="mt-2 line-clamp-3 text-[13px] leading-relaxed text-greytext">
                          {m.bio}
                        </p>
                      )}
                      {(m.email || m.phone) && (
                        <div className="mt-3 flex justify-center gap-2">
                          {m.email && (
                            <a
                              href={`mailto:${m.email}`}
                              aria-label={`Email ${m.name}`}
                              className="grid h-9 w-9 place-items-center rounded-xl bg-mist text-royal transition hover:bg-royal hover:text-white"
                            >
                              <Mail size={15} />
                            </a>
                          )}
                          {m.phone && (
                            <a
                              href={`tel:${m.phone}`}
                              aria-label={`Call ${m.name}`}
                              className="grid h-9 w-9 place-items-center rounded-xl bg-mist text-royal transition hover:bg-royal hover:text-white"
                            >
                              <Phone size={15} />
                            </a>
                          )}
                        </div>
                      )}
                    </article>
                  </Reveal>
                ))}
              </div>
            </section>
          );
        })}
      </div>
      <PortalPhotos portal="committee" title="The team behind AURA" eyebrow="COMMITTEE PHOTOS" />
    </main>
  );
}
