import type { Metadata } from "next";
import { PageHero, PortalHeroTitle} from "@/components/ui";
import EventsExplorer from "@/components/EventsExplorer";
import { getCategories, getEventsFull } from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Events & Programs",
  description:
    "Browse every AURA program — literary, arts, music, dance, sports and knowledge competitions for ALPHA and BETA.",
};

export const dynamic = "force-dynamic";

export default async function EventsPage() {
  const [events, categories] = await Promise.all([getEventsFull(), getCategories()]);

  const heroCopy = await getHeroCopy("events");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <EventsExplorer
          events={events.map((e) => ({
            id: e.id,
            slug: e.slug,
            title: e.title,
            description: e.description,
            venue: e.venue,
            eventDate: e.eventDate,
            startTime: e.startTime,
            endTime: e.endTime,
            startAtIso: e.startAtIso,
            endAtIso: e.endAtIso,
            autoSchedule: e.autoSchedule,
            eventType: e.eventType,
            participatingTeams: e.participatingTeams,
            status: e.status,
            isFeatured: e.isFeatured,
            imageUrl: e.imageUrl,
            category: e.category ? { name: e.category.name, color: e.category.color } : null,
          }))}
          categories={categories}
        />
      </div>
      <PortalPhotos portal="events" title="Programs in focus" eyebrow="EVENT PHOTOS" />
    </main>
  );
}
