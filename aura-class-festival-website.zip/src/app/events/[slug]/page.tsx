import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import {
  ArrowLeft,
  CalendarDays,
  MapPin,
  Users,
  ScrollText,
  ClipboardList,
  Trophy,
  Clock,
  Hourglass,
  UserCheck,
} from "lucide-react";
import { ProgramStatusBadge, Reveal } from "@/components/ui";
import { teamLabel } from "@/lib/format";
import { formatDisplayTime } from "@/lib/schedule";
import { getEventBySlug, getEventsFull } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const event = await getEventBySlug(slug);
  if (!event) return { title: "Program not found" };
  return {
    title: event.title,
    description:
      event.description?.slice(0, 155) || `Details for ${event.title} at AURA festival.`,
  };
}

const MEDALS = ["🥇", "🥈", "🥉"];

export default async function EventDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const event = await getEventBySlug(slug);
  if (!event) notFound();

  const all = await getEventsFull();
  const related = all
    .filter((e) => e.id !== event.id && e.categoryId === event.categoryId)
    .slice(0, 3);
  const fallback =
    related.length > 0 ? related : all.filter((e) => e.id !== event.id).slice(0, 3);

  const rules = event.rules
    ? event.rules
        .split("\n")
        .map((r) => r.trim())
        .filter(Boolean)
    : [];
  const published = event.results.filter((r) => r.isPublished);

  const dateLabel = event.eventDate
    ? new Date(event.eventDate + "T00:00:00").toLocaleDateString("en-IN", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
      })
    : "Date to be announced";

  const startDisp = formatDisplayTime(event.startTime);
  const endDisp = formatDisplayTime(event.endTime);

  return (
    <main className="bg-mist/60">
      {/* banner */}
      <section className="relative overflow-hidden bg-midnight">
        {event.imageUrl && (
          <div
            className="absolute inset-0 bg-cover bg-center opacity-25"
            style={{ backgroundImage: `url(${event.imageUrl})` }}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-midnight/65 via-midnight/75 to-midnight" />
        <div className="relative mx-auto max-w-7xl px-4 pb-12 pt-28 sm:px-6 sm:pt-32">
          <Link
            href="/events"
            className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-[12px] font-extrabold tracking-widest text-white backdrop-blur transition hover:bg-white/20"
          >
            <ArrowLeft size={14} /> ALL PROGRAMS
          </Link>
          <div className="mt-6 flex flex-wrap items-center gap-2.5">
            {event.category && (
              <span
                className="rounded-full px-4 py-1.5 text-[11px] font-extrabold tracking-widest text-white"
                style={{ background: event.category.color }}
              >
                {event.category.name.toUpperCase()}
              </span>
            )}
            <ProgramStatusBadge
              program={{
                eventDate: event.eventDate,
                startTime: event.startTime,
                endTime: event.endTime,
                startAt: event.startAtIso,
                endAt: event.endAtIso,
                autoSchedule: event.autoSchedule,
                status: event.status,
              }}
            />
            {event.isFeatured && (
              <span className="rounded-full bg-gradient-to-r from-amber-400 to-orange-400 px-4 py-1.5 text-[11px] font-extrabold tracking-widest text-midnight">
                ★ FEATURED
              </span>
            )}
          </div>
          <h1 className="font-display mt-4 max-w-4xl text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-6xl">
            {event.title}
          </h1>
          <div className="mt-6 flex flex-wrap gap-2.5 text-[13px] font-bold text-white">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.07] px-4 py-2 backdrop-blur">
              <CalendarDays size={14} className="text-sky" /> {dateLabel}
            </span>
            {(startDisp || endDisp) && (
              <span className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.07] px-4 py-2 backdrop-blur">
                <Clock size={14} className="text-sky" />
                {startDisp}
                {endDisp ? ` – ${endDisp}` : ""}
              </span>
            )}
            <span className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.07] px-4 py-2 backdrop-blur">
              <MapPin size={14} className="text-sky" /> {event.venue || "Venue TBA"}
            </span>
          </div>
        </div>
        <div className="relative h-[3px] w-full bg-gradient-to-r from-royal via-electric to-sky" />
      </section>

      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 sm:px-6 lg:grid-cols-[1.6fr_1fr]">
        {/* main column */}
        <div className="space-y-6">
          <Reveal>
            <div className="rounded-3xl border border-slate-200/80 bg-white p-6 sm:p-8">
              <h2 className="flex items-center gap-2 text-lg font-extrabold text-midnight">
                <ScrollText size={18} className="text-royal" /> About this program
              </h2>
              <p className="mt-3 text-[15px] leading-relaxed text-slate-600">
                {event.description || "Full details will be announced shortly."}
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                <span className="rounded-full bg-ice px-4 py-1.5 text-xs font-extrabold text-royal">
                  {event.eventType === "group" ? "GROUP PROGRAM" : "INDIVIDUAL PROGRAM"}
                </span>
                <span className="rounded-full bg-ice px-4 py-1.5 text-xs font-extrabold text-royal">
                  {teamLabel(event.participatingTeams).toUpperCase()}
                </span>
                {event.maxParticipants && (
                  <span className="rounded-full bg-ice px-4 py-1.5 text-xs font-extrabold text-royal">
                    {event.maxParticipants.toUpperCase()}
                  </span>
                )}
              </div>
            </div>
          </Reveal>

          <Reveal>
            <div className="rounded-3xl border border-slate-200/80 bg-white p-6 sm:p-8">
              <h2 className="flex items-center gap-2 text-lg font-extrabold text-midnight">
                <ClipboardList size={18} className="text-royal" /> Rules & regulations
              </h2>
              {rules.length > 0 ? (
                <ol className="mt-4 space-y-3">
                  {rules.map((r, i) => (
                    <li
                      key={i}
                      className="flex gap-3 text-[14.5px] leading-relaxed text-slate-600"
                    >
                      <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-royal to-electric text-xs font-extrabold text-white">
                        {i + 1}
                      </span>
                      {r}
                    </li>
                  ))}
                </ol>
              ) : (
                <p className="mt-3 text-sm font-semibold text-greytext">
                  Rules will be published by the organising committee.
                </p>
              )}
            </div>
          </Reveal>

          {/* Registered Candidates */}
          <Reveal>
            <div className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white">
              <div className="flex items-center justify-between border-b border-slate-100 p-6 sm:px-8">
                <div className="flex items-center gap-2">
                  <UserCheck size={18} className="text-royal" />
                  <h2 className="text-lg font-extrabold text-midnight">
                    Candidates ({event.candidates.length})
                  </h2>
                </div>
              </div>
              {event.candidates.length > 0 ? (
                <ul className="divide-y divide-slate-100">
                  {event.candidates.map((c) => (
                    <li
                      key={c.id}
                      className="flex flex-wrap items-center justify-between gap-3 px-6 py-4 sm:px-8"
                    >
                      <div className="flex items-center gap-3">
                        {c.chestNumber && (
                          <span className="rounded-xl bg-midnight px-3 py-1 text-xs font-extrabold tracking-wider text-sky">
                            #{c.chestNumber}
                          </span>
                        )}
                        <div>
                          <p className="text-sm font-extrabold text-midnight">{c.name}</p>
                          <p className="text-xs font-semibold text-greytext">
                            Registered candidate
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {c.team && (
                          <span
                            className="rounded-full px-3 py-1 text-[11px] font-extrabold tracking-widest text-white"
                            style={{ background: c.team.colorPrimary }}
                          >
                            {c.team.name}
                          </span>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="p-6 text-sm font-semibold text-greytext sm:px-8">
                  Official candidate entries will appear here once registered by the committee.
                </p>
              )}
            </div>
          </Reveal>

          {/* Scores & Results */}
          <Reveal>
            <div className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white">
              <div className="flex items-center gap-2 border-b border-slate-100 p-6 sm:px-8">
                <Trophy size={18} className="text-amber-500" />
                <h2 className="text-lg font-extrabold text-midnight">
                  Published Scores & Points
                </h2>
              </div>
              {published.length > 0 ? (
                <ul>
                  {published.map((r) => (
                    <li
                      key={r.id}
                      className="flex flex-wrap items-center gap-4 border-b border-slate-100 p-5 last:border-0 sm:px-8"
                    >
                      <span className="text-2xl">
                        {r.position >= 1 && r.position <= 3
                          ? MEDALS[r.position - 1]
                          : "🏅"}
                      </span>
                      <div className="flex-1">
                        <p className="text-[15px] font-extrabold text-midnight">
                          {r.participantName}
                          {r.chestNumber && (
                            <span className="ml-2 rounded-lg bg-mist px-2 py-0.5 text-xs font-bold text-royal">
                              #{r.chestNumber}
                            </span>
                          )}
                        </p>
                        <p className="mt-0.5 text-xs font-bold text-greytext">
                          {r.position >= 1 ? `Position ${r.position} · ` : ""}
                          {r.score ? `Score: ${r.score} · ` : ""}
                          {r.grade ? `Grade ${r.grade} · ` : ""}
                          <span className="text-royal">{r.points} pts</span>
                          {r.team ? ` · House ${r.team.name}` : ""}
                        </p>
                      </div>
                      {r.team && (
                        <span
                          className="rounded-full px-3 py-1 text-[11px] font-extrabold tracking-widest text-white"
                          style={{ background: r.team.colorPrimary }}
                        >
                          {r.team.name}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="flex items-center gap-3 p-6 sm:px-8">
                  <Hourglass size={18} className="shrink-0 text-royal" />
                  <p className="text-sm font-semibold text-greytext">
                    Scores pending — official results and points will be published here once
                    judged.
                  </p>
                </div>
              )}
            </div>
          </Reveal>
        </div>

        {/* sidebar */}
        <div className="space-y-6">
          <Reveal delay={0.1}>
            <div className="rounded-3xl bg-midnight p-6 text-white sm:p-7">
              <h3 className="text-[12px] font-extrabold tracking-[0.24em] text-sky">
                PROGRAM DETAILS
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-300">
                {event.registrationInfo ||
                  "Candidate entries are coordinated through your house captains."}
              </p>
              <div className="mt-5 space-y-2.5 border-t border-white/10 pt-5 text-[13px] font-bold">
                <p className="flex items-center gap-2">
                  <Users size={14} className="text-sky" />
                  {event.eventType === "group"
                    ? "Group competition"
                    : "Individual competition"}
                </p>
                <p className="flex items-center gap-2">
                  <Trophy size={14} className="text-sky" />
                  {event.pointsFirst}/{event.pointsSecond}/{event.pointsThird} pts for
                  1st/2nd/3rd
                </p>
              </div>
              <Link
                href="/schedule"
                className="mt-6 block rounded-2xl bg-gradient-to-r from-royal to-electric px-4 py-3 text-center text-[13px] font-extrabold tracking-widest transition hover:brightness-110"
              >
                VIEW AUTO SCHEDULE
              </Link>
            </div>
          </Reveal>

          <Reveal delay={0.15}>
            <div className="rounded-3xl border border-slate-200/80 bg-white p-6">
              <h3 className="text-[12px] font-extrabold tracking-[0.24em] text-royal">
                MORE PROGRAMS
              </h3>
              <div className="mt-4 space-y-3">
                {fallback.map((e) => (
                  <Link
                    key={e.id}
                    href={`/events/${e.slug}`}
                    className="group flex items-center gap-3 rounded-2xl border border-slate-100 p-3 transition hover:border-royal/30 hover:bg-mist"
                  >
                    <div className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-xl bg-gradient-to-br from-royal to-deepnavy text-sm font-extrabold text-white">
                      {e.imageUrl ? (
                        <img
                          src={e.imageUrl}
                          alt=""
                          loading="lazy"
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        e.title.charAt(0)
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-extrabold text-midnight group-hover:text-royal">
                        {e.title}
                      </p>
                      <p className="text-xs font-semibold text-greytext">
                        {e.eventDate
                          ? new Date(e.eventDate + "T00:00:00").toLocaleDateString(
                              "en-IN",
                              {
                                day: "numeric",
                                month: "short",
                              }
                            )
                          : "Date TBA"}{" "}
                        · {e.venue}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </main>
  );
}
