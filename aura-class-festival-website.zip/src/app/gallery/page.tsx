import type { Metadata } from "next";
import { PageHero, PortalHeroTitle} from "@/components/ui";
import GalleryGrid from "@/components/GalleryGrid";
import { getGalleryPublic } from "@/lib/data";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Gallery",
  description:
    "Festival photographs, stage performances, team moments and highlights from AURA.",
};

export const dynamic = "force-dynamic";

export default async function GalleryPage() {
  const items = await getGalleryPublic();
  const heroCopy = await getHeroCopy("gallery");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <GalleryGrid items={items} />
      </div>
      <PortalPhotos portal="gallery" title="Photo highlights" eyebrow="GALLERY PHOTOS" />
    </main>
  );
}
