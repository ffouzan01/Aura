import type { Metadata } from "next";
import { Mail, Phone, MapPin, Clock, Send } from "lucide-react";
import { PageHero, Reveal, PortalHeroTitle} from "@/components/ui";
import ContactForm from "@/components/ContactForm";
import {
  InstagramIcon,
  YoutubeIcon,
  XIcon,
  FacebookIcon,
} from "@/components/icons";
import { getSettings } from "@/lib/settings";
import PortalPhotos from "@/components/PortalPhotos";
import { getHeroCopy } from "@/lib/portalContent";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with WIDAD FRIENDS UNION — email, phone, venue and social links.",
};

export const dynamic = "force-dynamic";

export default async function ContactPage() {
  const s = await getSettings();

  const cards = [
    { icon: Mail, label: "EMAIL", value: s.contact_email, href: `mailto:${s.contact_email}` },
    { icon: Phone, label: "PHONE", value: s.contact_phone, href: `tel:${s.contact_phone}` },
    { icon: MapPin, label: "VENUE", value: s.venue || "To be announced", href: undefined },
    { icon: Clock, label: "FESTIVAL HOURS", value: s.festival_hours || "To be announced", href: undefined },
  ];

  const socials = [
    { icon: InstagramIcon, label: "Instagram", href: s.instagram_url },
    { icon: YoutubeIcon, label: "YouTube", href: s.youtube_url },
    { icon: XIcon, label: "X (Twitter)", href: s.twitter_url },
    { icon: FacebookIcon, label: "Facebook", href: s.facebook_url },
  ];

  const heroCopy = await getHeroCopy("contact");
  return (
    <main className="bg-mist/60">
      <PageHero
        eyebrow={heroCopy.eyebrow}
        title={<PortalHeroTitle text={heroCopy.title} />}
        subtitle={heroCopy.subtitle}
      />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c, i) => (
            <Reveal key={c.label} delay={i * 0.06}>
              <div className="card-hover h-full rounded-3xl border border-slate-200/80 bg-white p-6">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-royal to-electric text-white shadow-md">
                  <c.icon size={18} />
                </span>
                <p className="mt-4 text-[11px] font-extrabold tracking-[0.24em] text-slate-400">
                  {c.label}
                </p>
                {c.href ? (
                  <a href={c.href} className="mt-1.5 block break-words text-[15px] font-extrabold text-midnight hover:text-royal">
                    {c.value}
                  </a>
                ) : (
                  <p className="mt-1.5 text-[15px] font-extrabold leading-snug text-midnight">{c.value}</p>
                )}
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          <Reveal>
            <div className="rounded-[28px] border border-slate-200/80 bg-white p-6 sm:p-8">
              <h2 className="flex items-center gap-2 text-xl font-extrabold text-midnight">
                <Send size={19} className="text-royal" /> Send a message
              </h2>
              <p className="mb-6 mt-1.5 text-sm font-semibold text-greytext">
                We usually respond within 1–2 working days.
              </p>
              <ContactForm />
            </div>
          </Reveal>
          <div className="space-y-6">
            <Reveal delay={0.08}>
              <div className="rounded-[28px] bg-midnight p-6 text-white sm:p-7">
                <h3 className="text-[12px] font-extrabold tracking-[0.24em] text-sky">
                  FOLLOW AURA
                </h3>
                <div className="mt-4 space-y-2.5">
                  {socials.map(({ icon: Icon, label, href }) => (
                    <a
                      key={label}
                      href={href || "#"}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm font-extrabold transition hover:border-sky/50 hover:bg-white/10"
                    >
                      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-royal to-electric">
                        <Icon size={16} />
                      </span>
                      {label}
                    </a>
                  ))}
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.12}>
              <div className="overflow-hidden rounded-[28px] border border-slate-200/80 bg-white">
                <div className="bg-dot-grid flex h-44 flex-col items-center justify-center bg-mist p-6 text-center">
                  <MapPin size={26} className="text-royal" />
                  <p className="mt-2 text-sm font-extrabold text-midnight">
                    {s.venue || "Official Venue — TBA"}
                  </p>
                  {s.venue_address && (
                    <p className="mt-1 text-xs font-semibold text-greytext">{s.venue_address}</p>
                  )}
                </div>
                <div className="p-5 text-center">
                  <p className="text-[13px] font-semibold leading-relaxed text-greytext">
                    Detailed venue maps and entry-gate information will be published closer to the
                    festival.
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
      <PortalPhotos portal="contact" title="Find us at the festival" eyebrow="CONTACT PHOTOS" />
    </main>
  );
}
