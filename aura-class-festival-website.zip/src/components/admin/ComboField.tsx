"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, Loader2, Plus, X } from "lucide-react";

export type ComboOption = { value: string; label: string };

/**
 * A searchable, writable dropdown.
 * - Type to filter existing options.
 * - When `onCreate` is supplied, the typed text can be saved as a brand-new
 *   record (used for Houses, Programs and Categories added from the admin).
 */
export default function ComboField({
  value,
  options,
  placeholder = "— Select —",
  onChange,
  onCreate,
  allowClear = true,
  createLabel = "Add",
  loading = false,
  onRetry,
  emptyActionLabel,
  onEmptyAction,
}: {
  value: string | null | undefined;
  options: ComboOption[];
  placeholder?: string;
  onChange: (value: string | null, label: string) => void;
  onCreate?: (label: string) => Promise<ComboOption | null>;
  allowClear?: boolean;
  createLabel?: string;
  loading?: boolean;
  onRetry?: () => void;
  emptyActionLabel?: string;
  onEmptyAction?: () => void;
}) {
  const selected = options.find((o) => o.value === value) ?? null;
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const boxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!boxRef.current?.contains(e.target as Node)) {
        setOpen(false);
        setQuery("");
      }
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter((o) => o.label.toLowerCase().includes(q));
  }, [options, query]);

  const typed = query.trim();
  const exact = options.some((o) => o.label.toLowerCase() === typed.toLowerCase());
  const canCreate = !!onCreate && typed.length > 0 && !exact;

  const choose = (opt: ComboOption) => {
    onChange(opt.value, opt.label);
    setOpen(false);
    setQuery("");
    setError("");
  };

  const create = async () => {
    if (!onCreate || !typed) return;
    setCreating(true);
    setError("");
    try {
      const created = await onCreate(typed);
      if (created) {
        onChange(created.value, created.label);
        setOpen(false);
        setQuery("");
      } else {
        setError("Could not save — please try again.");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save.");
    } finally {
      setCreating(false);
    }
  };

  return (
    <div ref={boxRef} className="relative">
      <div
        className={`flex items-center gap-2 rounded-2xl border bg-white px-3.5 py-2.5 transition ${
          open ? "border-royal ring-4 ring-royal/10" : "border-slate-200"
        }`}
      >
        <input
          ref={inputRef}
          value={open ? query : selected?.label ?? ""}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => {
            setOpen(true);
            setQuery("");
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (canCreate) void create();
              else if (filtered[0]) choose(filtered[0]);
            }
            if (e.key === "Escape") {
              setOpen(false);
              setQuery("");
            }
          }}
          placeholder={
            open
              ? `Type to search${onCreate ? " or add new" : ""}…`
              : placeholder
          }
          className="w-full bg-transparent text-sm font-semibold text-midnight outline-none placeholder:font-medium placeholder:text-slate-400"
          aria-label={placeholder}
          role="combobox"
          aria-expanded={open}
          aria-autocomplete="list"
        />
        {selected && allowClear && !open && (
          <button
            type="button"
            onClick={() => onChange(null, "")}
            className="text-slate-300 transition hover:text-red-500"
            aria-label="Clear selection"
          >
            <X size={14} />
          </button>
        )}
        <ChevronDown
          size={15}
          className={`shrink-0 text-slate-400 transition ${open ? "rotate-180" : ""}`}
        />
      </div>

      {open && (
        <div className="absolute z-[95] mt-1.5 max-h-60 w-full overflow-y-auto rounded-2xl border border-slate-200 bg-white p-1.5 shadow-2xl">
          {loading && (
            <p className="flex items-center gap-2 px-3 py-3 text-[13px] font-semibold text-slate-500">
              <Loader2 size={14} className="animate-spin" /> Loading options…
            </p>
          )}
          {canCreate && (
            <button
              type="button"
              onClick={create}
              disabled={creating}
              className="mb-1 flex w-full items-center gap-2 rounded-xl bg-royal px-3 py-2.5 text-left text-[13px] font-extrabold text-white transition hover:bg-deepnavy disabled:opacity-60"
            >
              {creating ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Plus size={14} />
              )}
              {createLabel} “{typed}”
            </button>
          )}
          {!loading && filtered.length === 0 && !canCreate && (
            <div className="px-3 py-3">
              <p className="text-[13px] font-semibold text-slate-400">
                {options.length === 0
                  ? onCreate
                    ? "No records yet — type a name to create the first one."
                    : "Nothing to select yet."
                  : "No match. Keep typing to create a new entry."}
              </p>
              {onEmptyAction && emptyActionLabel && (
                <button
                  type="button"
                  onClick={() => {
                    setOpen(false);
                    onEmptyAction();
                  }}
                  className="mt-2 mr-3 text-[12px] font-extrabold text-royal hover:underline"
                >
                  {emptyActionLabel} →
                </button>
              )}
              {onRetry && (
                <button
                  type="button"
                  onClick={onRetry}
                  className="mt-2 text-[12px] font-extrabold text-royal hover:underline"
                >
                  Reload options
                </button>
              )}
            </div>
          )}
          {filtered.map((o) => (
            <button
              key={o.value}
              type="button"
              onClick={() => choose(o)}
              className={`flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left text-[13px] font-bold transition ${
                o.value === value
                  ? "bg-royal/10 text-royal"
                  : "text-slate-700 hover:bg-mist"
              }`}
            >
              <span className="truncate">{o.label}</span>
              {o.value === value && <Check size={14} />}
            </button>
          ))}
        </div>
      )}

      {error && (
        <p role="alert" className="mt-1 text-[11.5px] font-bold text-red-500">
          {error}
        </p>
      )}
    </div>
  );
}
