"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutGrid,
  X,
  CalendarClock,
  Sparkles,
  Trophy,
  Users,
  HeartHandshake,
  Megaphone,
  Image as ImageIcon,
  Mail,
  ShieldCheck,
  ArrowUpRight,
} from "lucide-react";

const HUB_GROUPS = [
  {
    heading: "Programs & Schedule",
    items: [
      {
        href: "/events",
        label: "Events & Programs",
        sub: "All competitions, rules & entries",
        icon: Sparkles,
        accent: "from-royal to-electric",
      },
      {
        href: "/schedule",
        label: "Auto Time Schedule",
        sub: "Live timetable & completed status",
        icon: CalendarClock,
        accent: "from-electric to-sky",
      },
    ],
  },
  {
    heading: "Scores, Points & Houses",
    items: [
      {
        href: "/results",
        label: "Scores & Leaderboard",
        sub: "Program scores & ALPHA vs BETA points",
        icon: Trophy,
        accent: "from-amber-400 to-orange-500",
      },
      {
        href: "/teams",
        label: "Teams & Candidates",
        sub: "ALPHA, BETA & candidate list",
        icon: Users,
        accent: "from-royal to-deepnavy",
      },
    ],
  },
  {
    heading: "Committee & Updates",
    items: [
      {
        href: "/committee",
        label: "Committee",
        sub: "Union leadership & coordinators",
        icon: HeartHandshake,
        accent: "from-sky to-royal",
      },
      {
        href: "/announcements",
        label: "Announcements",
        sub: "Official notices & updates",
        icon: Megaphone,
        accent: "from-royal to-electric",
      },
      {
        href: "/gallery",
        label: "Gallery",
        sub: "Stage photos & highlights",
        icon: ImageIcon,
        accent: "from-electric to-royal",
      },
      {
        href: "/contact",
        label: "Contact",
        sub: "Reach WIDAD FRIENDS UNION",
        icon: Mail,
        accent: "from-deepnavy to-royal",
      },
    ],
  },
];

export default function FestivalHubButton() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onOpen = () => setOpen(true);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("open-festival-hub", onOpen);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("open-festival-hub", onOpen);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  // Hide floating dock inside /admin workspace to keep admin UI unobstructed
  if (pathname.startsWith("/admin")) return null;

  return (
    <>
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-[65] bg-midnight/60 backdrop-blur-sm"
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="AURA Festival Directory"
              initial={{ opacity: 0, y: 28, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 24, scale: 0.95 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="fixed bottom-20 right-4 left-4 z-[70] mx-auto max-h-[80vh] max-w-md overflow-y-auto rounded-[28px] border border-white/20 bg-[#08172E]/92 p-5 text-white shadow-[0_28px_80px_-12px_rgba(7,20,38,0.85)] backdrop-blur-2xl sm:left-auto sm:right-6 sm:w-[410px] sm:p-6"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <p className="text-[10px] font-extrabold tracking-[0.28em] text-sky">
                    FESTIVAL DIRECTORY
                  </p>
                  <h2 className="mt-0.5 text-lg font-extrabold tracking-tight text-white">
                    Explore AURA Portals
                  </h2>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  aria-label="Close directory"
                  className="grid h-9 w-9 place-items-center rounded-xl border border-white/15 bg-white/10 text-slate-200 transition hover:bg-white/20 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="mt-4 space-y-5">
                {HUB_GROUPS.map((group) => (
                  <div key={group.heading}>
                    <p className="px-1 text-[10px] font-extrabold uppercase tracking-[0.24em] text-slate-400">
                      {group.heading}
                    </p>
                    <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                      {group.items.map((item) => {
                        const active =
                          pathname === item.href || pathname.startsWith(item.href + "/");
                        return (
                          <Link
                            key={item.href}
                            href={item.href}
                            className={`group relative flex items-start gap-3 rounded-2xl border p-3 transition ${
                              active
                                ? "border-sky/60 bg-royal/30"
                                : "border-white/10 bg-white/[0.05] hover:border-sky/40 hover:bg-white/[0.1]"
                            }`}
                          >
                            <span
                              className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br ${item.accent} text-white shadow-md`}
                            >
                              <item.icon size={16} />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="flex items-center justify-between gap-1 text-[13px] font-extrabold text-white">
                                <span className="truncate">{item.label}</span>
                                <ArrowUpRight
                                  size={13}
                                  className="shrink-0 text-sky opacity-70 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:opacity-100"
                                />
                              </span>
                              <span className="mt-0.5 block line-clamp-1 text-[11px] font-medium text-slate-300">
                                {item.sub}
                              </span>
                            </span>
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                ))}

                <div className="border-t border-white/10 pt-3">
                  <Link
                    href="/admin"
                    className="flex items-center justify-between rounded-2xl border border-white/15 bg-gradient-to-r from-royal/35 to-electric/25 px-4 py-3 text-xs font-extrabold tracking-widest text-white transition hover:border-sky/50 hover:from-royal/50 hover:to-electric/40"
                  >
                    <span className="inline-flex items-center gap-2">
                      <ShieldCheck size={15} className="text-sky" />
                      ADMIN CONTROL PANEL
                    </span>
                    <ArrowUpRight size={14} className="text-sky" />
                  </Link>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Floating Right-Bottom Glassy Button */}
      <motion.button
        type="button"
        onClick={() => setOpen((v) => !v)}
        initial={{ opacity: 0, scale: 0.85, y: 24 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.45, ease: [0.16, 1, 0.3, 1] }}
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.97 }}
        aria-expanded={open}
        aria-label="Open Events and Festival Directory"
        className="fixed bottom-5 right-5 z-[68] inline-flex items-center gap-2.5 rounded-full border border-white/25 bg-[#0b2b49]/85 py-3 pl-3.5 pr-5 text-white shadow-[0_16px_40px_-8px_rgba(23,105,232,0.75),inset_0_1px_0_rgba(255,255,255,0.28)] backdrop-blur-2xl transition hover:border-sky/60 sm:bottom-6 sm:right-6"
      >
        <span className="grid h-8 w-8 place-items-center rounded-full bg-cyan text-deepnavy shadow-inner">
          {open ? <X size={15} /> : <LayoutGrid size={15} />}
        </span>
        <span className="text-left leading-tight">
          <span className="block text-[9px] font-extrabold tracking-[0.22em] text-cream/70">
            FESTIVAL HUB
          </span>
          <span className="block text-xs font-extrabold tracking-wider text-white">
            {open ? "Close Menu" : "Events & More"}
          </span>
        </span>
      </motion.button>
    </>
  );
}
