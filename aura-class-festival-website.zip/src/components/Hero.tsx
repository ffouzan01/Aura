"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Sparkle, Sparkles, LayoutGrid, ChevronDown } from "lucide-react";

export default function Hero({
  tagline,
  motto,
  badge = "WIDAD FRIENDS UNION PRESENTS",
  title = "Aura",
  scriptLine = "Arts Unite Reality & AI",
}: {
  tagline: string;
  motto: string;
  badge?: string;
  title?: string;
  scriptLine?: string;
}) {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
  const fade = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  const openPortals = () => {
    window.dispatchEvent(new CustomEvent("open-festival-hub"));
  };

  return (
    <section
      ref={ref}
      className="relative flex min-h-[100svh] items-center justify-center overflow-hidden bg-midnight"
      aria-label="AURA festival hero"
    >
      {/* Official AURA poster backdrop — inked navy paper */}
      <motion.div
        style={reduce ? undefined : { y: bgY }}
        className="absolute inset-0 poster-paper poster-grain poster-crease"
      >
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 62% 48% at 50% 38%, rgba(53,190,234,0.20) 0%, transparent 62%), radial-gradient(ellipse 55% 45% at 50% 100%, rgba(6,24,44,0.85) 0%, transparent 70%)",
          }}
        />
      </motion.div>

      {/* Subtle symmetrical architectural light rings behind centered AURA */}
      {!reduce && (
        <div
          className="pointer-events-none absolute inset-0 flex items-center justify-center"
          aria-hidden
        >
          <div className="h-[540px] w-[540px] rounded-full border border-sky/[0.08] sm:h-[680px] sm:w-[680px]" />
          <div className="absolute h-[380px] w-[380px] rounded-full border border-electric/[0.11] sm:h-[480px] sm:w-[480px]" />
          <div
            className="animate-float-slow absolute h-[280px] w-[460px] rounded-full opacity-45 blur-[110px]"
            style={{
              background:
                "radial-gradient(circle, rgba(49,139,255,0.62) 0%, rgba(23,105,232,0.22) 55%, transparent 75%)",
            }}
          />
        </div>
      )}

      {/* Centered Hero Content */}
      <motion.div
        style={reduce ? undefined : { opacity: fade }}
        className="relative z-10 mx-auto flex w-full max-w-5xl flex-col items-center px-4 pb-20 pt-28 text-center sm:px-6 sm:pt-32"
      >
        {/* Organizer pill */}
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
          className="inline-flex items-center gap-2.5 rounded-full border border-cream/25 bg-cream/[0.08] py-2 pl-3 pr-4 backdrop-blur-xl"
        >
          <span className="grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-[#E8D3A0] to-[#C39C56] text-midnight">
            <Sparkles size={12} strokeWidth={2.5} />
          </span>
          <span className="text-[11px] font-extrabold tracking-[0.26em] text-white sm:text-xs">
            {badge}
          </span>
        </motion.div>

        {/* Poster wordmark — cream bubble lettering, centred baseline */}
        <div className="relative mt-8 flex w-full flex-col items-center">
          <motion.span
            aria-hidden
            initial={reduce ? false : { opacity: 0, scale: 0.3, rotate: -40 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 0.8, delay: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="absolute left-1/2 top-0 z-10 -translate-x-1/2 -translate-y-[58%] text-cream"
          >
            <Sparkle className="h-7 w-7 sm:h-10 sm:w-10" fill="currentColor" strokeWidth={0.5} />
          </motion.span>

          <h1
            aria-label={title || "Aura"}
            className="aura-poster-title flex w-full items-baseline justify-center text-center text-[clamp(4.4rem,17vw,11rem)]"
          >
            {(title || "Aura").split("").map((letter, idx) => (
              <span
                key={idx}
                className="aura-letter"
                style={
                  reduce
                    ? undefined
                    : { animationDelay: `${0.3 + idx * 0.08}s` }
                }
              >
                {letter}
              </span>
            ))}
          </h1>
        </div>

        {/* Poster script tagline */}
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.8 }}
          className="aura-script mt-1 max-w-full text-center text-[27px] leading-tight sm:text-[40px]"
        >
          {scriptLine}
        </motion.p>

        {/* Symmetric Festival Tagline */}
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.78, ease: [0.22, 1, 0.36, 1] }}
          className="mt-5 flex items-center justify-center gap-3 sm:gap-4"
        >
          <span className="h-px w-8 bg-gradient-to-r from-transparent to-cream/70 sm:w-14" />
          <p className="text-[11px] font-extrabold tracking-[0.34em] text-cream/85 sm:text-sm">
            {tagline || "WHERE TALENT MEETS EXCELLENCE"}
          </p>
          <span className="h-px w-8 bg-gradient-to-l from-transparent to-cream/70 sm:w-14" />
        </motion.div>

        {/* Creative 2-Sentence Motto */}
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.75, delay: 0.92, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mt-6 max-w-2xl text-[15.5px] font-medium leading-relaxed text-slate-200/95 sm:text-[18px]"
        >
          {motto}
        </motion.p>

        {/* Clean Centered Actions */}
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 1.08, ease: [0.22, 1, 0.36, 1] }}
          className="mt-9 flex flex-col items-center justify-center gap-3.5 sm:flex-row"
        >
          <button
            type="button"
            onClick={openPortals}
            className="group inline-flex items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r from-royal via-electric to-royal bg-[length:200%_100%] bg-left px-8 py-4 text-xs font-extrabold tracking-[0.22em] text-white shadow-[0_16px_44px_-10px_rgba(49,139,255,0.85)] transition-all duration-500 hover:bg-right sm:text-[13px]"
          >
            <LayoutGrid size={16} />
            EXPLORE EVENTS & PORTALS
          </button>
          <a
            href="#about"
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/[0.06] px-8 py-4 text-xs font-extrabold tracking-[0.22em] text-white backdrop-blur-xl transition hover:border-sky/50 hover:bg-white/12 sm:text-[13px]"
          >
            ABOUT AURA
          </a>
        </motion.div>
      </motion.div>

      {/* Subtle centered scroll indicator */}
      <motion.a
        href="#about"
        initial={reduce ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.35, duration: 0.7 }}
        aria-label="Scroll to About AURA"
        className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-1.5 text-slate-400 transition hover:text-white sm:flex"
      >
        <span className="text-[9.5px] font-extrabold tracking-[0.32em]">
          ABOUT
        </span>
        <ChevronDown size={15} className="text-sky" />
      </motion.a>

      <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-sky/60 to-transparent" />
    </section>
  );
}
