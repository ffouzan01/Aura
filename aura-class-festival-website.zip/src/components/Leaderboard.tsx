"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Trophy, RefreshCw, Crown } from "lucide-react";
import { AnimatedNumber, Reveal } from "./ui";

export type Standing = {
  team: {
    id: string;
    slug: string;
    name: string;
    tagline: string;
    emblem: string;
    colorPrimary: string;
    colorSecondary: string;
  };
  points: number;
  first: number;
  second: number;
  third: number;
  wins: number;
  eventWise: {
    eventTitle: string;
    eventSlug: string;
    position: number;
    points: number;
    score?: string;
    grade?: string;
    participantName: string;
  }[];
};

const MEDAL = ["🥇", "🥈", "🥉"];

export default function Leaderboard({ initial }: { initial: Standing[] }) {
  const [standings, setStandings] = useState<Standing[]>(initial);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [spinning, setSpinning] = useState(false);

  const refresh = async () => {
    try {
      setSpinning(true);
      const res = await fetch("/api/leaderboard", { cache: "no-store" });
      const data = await res.json();
      if (data.standings) {
        setStandings(data.standings);
        setUpdatedAt(data.updatedAt);
      }
    } catch {
      /* keep stale data */
    } finally {
      setTimeout(() => setSpinning(false), 600);
    }
  };

  useEffect(() => {
    const t = setInterval(refresh, 20000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const total = standings.reduce((s, t) => s + t.points, 0);
  const max = Math.max(1, ...standings.map((t) => t.points));

  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <p className="flex items-center gap-2 text-[12px] font-extrabold tracking-[0.22em] text-slate-500">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
          </span>
          LIVE SCORES & STANDINGS
          {updatedAt && (
            <span className="font-semibold normal-case tracking-normal text-slate-400">
              · updated{" "}
              {new Date(updatedAt).toLocaleTimeString("en-IN", {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          )}
        </p>
        <button
          onClick={refresh}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-[12px] font-extrabold tracking-widest text-slate-600 transition hover:border-royal hover:text-royal"
          aria-label="Refresh standings"
        >
          <RefreshCw size={13} className={spinning ? "animate-spin" : ""} />
          REFRESH
        </button>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        {standings.map((s, i) => (
          <Reveal key={s.team.id} delay={i * 0.08}>
            <div
              className={`relative overflow-hidden rounded-[28px] border-2 p-6 sm:p-7 ${
                i === 0 && s.points > 0
                  ? "border-amber-300/70 bg-gradient-to-br from-amber-50 via-white to-white"
                  : "border-slate-200/80 bg-white"
              }`}
            >
              {i === 0 && s.points > 0 && (
                <div className="absolute right-0 top-0 flex items-center gap-1.5 rounded-bl-2xl bg-gradient-to-r from-amber-400 to-orange-400 px-4 py-1.5 text-[11px] font-extrabold tracking-widest text-midnight">
                  <Crown size={13} /> LEADING HOUSE
                </div>
              )}
              <div className="flex items-center gap-4">
                <span
                  className="grid h-16 w-16 place-items-center rounded-2xl text-3xl font-extrabold text-white shadow-lg"
                  style={{
                    background: `linear-gradient(135deg, ${s.team.colorPrimary}, ${s.team.colorSecondary})`,
                  }}
                >
                  {s.team.emblem}
                </span>
                <div>
                  <p className="font-display text-2xl font-black tracking-[0.08em] text-midnight">
                    {s.team.name}
                  </p>
                  <p className="text-xs font-bold text-greytext">{s.team.tagline}</p>
                </div>
              </div>

              <div className="mt-5 flex items-end justify-between">
                <p className="text-6xl font-extrabold tracking-tight text-midnight">
                  <AnimatedNumber value={s.points} />
                </p>
                <p className="pb-2 text-[11px] font-extrabold tracking-[0.24em] text-slate-400">
                  TOTAL POINTS
                </p>
              </div>
              <div className="mt-2 h-3 overflow-hidden rounded-full bg-slate-100">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${Math.round((s.points / max) * 100)}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
                  className="h-full rounded-full"
                  style={{
                    background: `linear-gradient(90deg, ${s.team.colorPrimary}, ${s.team.colorSecondary})`,
                  }}
                />
              </div>
              <div className="mt-4 grid grid-cols-4 gap-2 text-center">
                {[
                  { icon: "🥇", v: s.first, l: "FIRST PRIZE" },
                  { icon: "🥈", v: s.second, l: "SECOND PRIZE" },
                  { icon: "🥉", v: s.third, l: "THIRD PRIZE" },
                  { icon: "🏆", v: s.wins, l: "PLACED" },
                ].map((m) => (
                  <div key={m.l} className="rounded-2xl bg-mist px-1.5 py-3">
                    <p className="text-base">{m.icon}</p>
                    <p className="mt-0.5 text-lg font-extrabold text-midnight">{m.v}</p>
                    <p className="text-[8.5px] font-extrabold leading-tight tracking-wider text-greytext">
                      {m.l}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      {/* share bar */}
      <Reveal>
        <div className="mt-4 rounded-3xl border border-slate-200/80 bg-white p-5 sm:p-6">
          <div className="flex items-center gap-2 text-[12px] font-extrabold tracking-[0.22em] text-slate-500">
            <Trophy size={14} className="text-royal" /> CHAMPIONSHIP SHARE
          </div>
          <div className="mt-3 flex h-5 overflow-hidden rounded-full bg-slate-100">
            {standings.map((s) => (
              <div
                key={s.team.id}
                className="flex h-full items-center justify-center text-[10px] font-extrabold text-white transition-all duration-700"
                style={{
                  width: `${total > 0 ? (s.points / total) * 100 : 50}%`,
                  background: `linear-gradient(90deg, ${s.team.colorPrimary}, ${s.team.colorSecondary})`,
                  minWidth: total > 0 && s.points > 0 ? "64px" : undefined,
                }}
              >
                {total > 0 ? `${Math.round((s.points / total) * 100)}%` : ""}
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between text-xs font-extrabold">
            {standings.map((s) => (
              <span key={s.team.id} style={{ color: s.team.colorPrimary }}>
                {s.team.name} · {s.points} pts
              </span>
            ))}
          </div>
        </div>
      </Reveal>

      {/* event-wise points */}
      <div className="mt-8 grid gap-4 lg:grid-cols-2">
        {standings.map((s) => (
          <Reveal key={s.team.id + "-wise"}>
            <div className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white">
              <div
                className="flex items-center justify-between px-6 py-4 text-white"
                style={{
                  background: `linear-gradient(120deg, ${s.team.colorPrimary}, ${s.team.colorSecondary})`,
                }}
              >
                <p className="text-sm font-extrabold tracking-[0.18em]">
                  {s.team.name} · SCORES & POINTS
                </p>
                <p className="text-sm font-extrabold">{s.points} PTS</p>
              </div>
              {s.eventWise.length > 0 ? (
                <ul className="max-h-80 overflow-y-auto">
                  {s.eventWise.map((e, i) => (
                    <li
                      key={i}
                      className="flex items-center gap-3 border-b border-slate-100 px-6 py-3 last:border-0"
                    >
                      <span className="w-7 text-center text-lg">
                        {e.position >= 1 && e.position <= 3
                          ? MEDAL[e.position - 1]
                          : "✦"}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-extrabold text-midnight">
                          {e.eventTitle}
                        </p>
                        <p className="truncate text-xs font-semibold text-greytext">
                          {e.participantName}
                          {e.score ? ` · Score: ${e.score}` : ""}
                          {e.grade ? ` · Grade ${e.grade}` : ""}
                        </p>
                      </div>
                      <span className="rounded-full bg-mist px-3 py-1 text-xs font-extrabold text-royal">
                        {e.points >= 0 ? `+${e.points}` : e.points}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="px-6 py-6 text-sm font-semibold text-greytext">
                  No published scores yet — points appear here automatically once entered.
                </p>
              )}
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
