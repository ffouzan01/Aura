"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search, Hourglass } from "lucide-react";
import { EmptyState, Reveal } from "./ui";

export type ResultRow = {
  id: string;
  position: number;
  chestNumber?: string;
  participantName: string;
  score?: string;
  grade?: string;
  points: number;
  note: string;
  event: { slug: string; title: string; eventType: string; venue: string } | null;
  category: { name: string; color: string } | null;
  team: { name: string; colorPrimary: string } | null;
};

const MEDAL = ["🥇", "🥈", "🥉"];

export default function ResultsExplorer({
  results,
  pendingEvents,
  categories,
}: {
  results: ResultRow[];
  pendingEvents: { slug: string; title: string; venue: string }[];
  categories: string[];
}) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [team, setTeam] = useState("all");
  const [type, setType] = useState("all");

  const grouped = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const map = new Map<
      string,
      {
        title: string;
        slug: string;
        venue: string;
        type: string;
        category: string;
        rows: ResultRow[];
      }
    >();
    for (const r of results) {
      if (!r.event) continue;
      const key = r.event.slug;
      if (!map.has(key))
        map.set(key, {
          title: r.event.title,
          slug: r.event.slug,
          venue: r.event.venue,
          type: r.event.eventType,
          category: r.category?.name ?? "General",
          rows: [],
        });
      map.get(key)!.rows.push(r);
    }
    let list = [...map.values()].map((g) => ({
      ...g,
      rows: g.rows.sort((a, b) => (a.position || 99) - (b.position || 99)),
    }));
    if (cat !== "all") list = list.filter((g) => g.category === cat);
    if (team !== "all")
      list = list.filter((g) =>
        g.rows.some((r) => r.team?.name.toLowerCase() === team)
      );
    if (type !== "all") list = list.filter((g) => g.type === type);
    if (needle)
      list = list.filter((g) =>
        `${g.title} ${g.rows
          .map((r) => `${r.participantName} ${r.chestNumber ?? ""}`)
          .join(" ")}`
          .toLowerCase()
          .includes(needle)
      );
    return list;
  }, [results, q, cat, team, type]);

  const pendingFiltered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return pendingEvents;
    return pendingEvents.filter((e) => e.title.toLowerCase().includes(needle));
  }, [pendingEvents, q]);

  const selectCls =
    "rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] font-bold text-slate-700 outline-none focus:border-royal";

  return (
    <div className="mt-12">
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-black tracking-tight text-midnight sm:text-3xl">
              Program-wise <span className="text-gradient-blue">scores & points</span>
            </h2>
            <p className="mt-1.5 text-sm font-semibold text-greytext">
              {grouped.length} program{grouped.length !== 1 ? "s" : ""} declared ·{" "}
              {pendingFiltered.length} pending
            </p>
          </div>
        </div>
      </Reveal>

      <div className="mt-5 flex flex-col gap-3 lg:flex-row">
        <div className="relative flex-1">
          <Search
            size={17}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search program, candidate name or chest number…"
            className="w-full rounded-2xl border border-slate-200 bg-white py-3.5 pl-11 pr-4 text-sm font-semibold outline-none placeholder:text-slate-400 focus:border-royal focus:ring-4 focus:ring-royal/10"
            aria-label="Search results"
          />
        </div>
        <div className="flex flex-wrap gap-2.5">
          <select
            value={cat}
            onChange={(e) => setCat(e.target.value)}
            className={selectCls}
            aria-label="Category filter"
          >
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <select
            value={team}
            onChange={(e) => setTeam(e.target.value)}
            className={selectCls}
            aria-label="Team filter"
          >
            <option value="all">Both houses</option>
            <option value="alpha">ALPHA</option>
            <option value="beta">BETA</option>
          </select>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className={selectCls}
            aria-label="Type filter"
          >
            <option value="all">Individual + Group</option>
            <option value="individual">Individual</option>
            <option value="group">Group</option>
          </select>
        </div>
      </div>

      {grouped.length > 0 ? (
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {grouped.map((g) => (
            <Reveal key={g.slug}>
              <div className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white">
                <div className="border-b border-slate-100 bg-mist/70 px-6 py-4">
                  <p className="text-[11px] font-extrabold tracking-[0.2em] text-royal">
                    {g.category.toUpperCase()} · {g.type.toUpperCase()}
                  </p>
                  <Link
                    href={`/events/${g.slug}`}
                    className="mt-1 block text-[17px] font-extrabold text-midnight hover:text-royal"
                  >
                    {g.title}
                  </Link>
                </div>
                <ul>
                  {g.rows.map((r) => (
                    <li
                      key={r.id}
                      className="flex items-center gap-3 border-b border-slate-100 px-6 py-3.5 last:border-0"
                    >
                      <span
                        className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl text-base font-extrabold ${
                          r.position === 1
                            ? "bg-gradient-to-br from-amber-300 to-orange-400 text-midnight"
                            : r.position === 2
                            ? "bg-gradient-to-br from-slate-200 to-slate-300 text-slate-700"
                            : r.position === 3
                            ? "bg-gradient-to-br from-orange-300 to-amber-600 text-white"
                            : "bg-mist text-royal"
                        }`}
                      >
                        {r.position >= 1 && r.position <= 3
                          ? MEDAL[r.position - 1]
                          : "✦"}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-extrabold text-midnight">
                          {r.participantName}
                          {r.chestNumber && (
                            <span className="ml-2 rounded-md bg-mist px-2 py-0.5 text-[11px] font-bold text-royal">
                              #{r.chestNumber}
                            </span>
                          )}
                        </p>
                        <p className="text-xs font-semibold text-greytext">
                          {r.score ? `Score: ${r.score} · ` : ""}
                          {r.grade ? `Grade ${r.grade} · ` : ""}
                          <span className="font-bold text-royal">{r.points} pts</span>
                          {r.note ? ` · ${r.note}` : ""}
                        </p>
                      </div>
                      {r.team && (
                        <span
                          className="shrink-0 rounded-full px-3 py-1 text-[10px] font-extrabold tracking-widest text-white"
                          style={{ background: r.team.colorPrimary }}
                        >
                          {r.team.name}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      ) : (
        <div className="mt-6">
          <EmptyState
            title="No scores declared yet"
            message="Program scores and points published from the Admin Console appear here automatically."
          />
        </div>
      )}

      {pendingFiltered.length > 0 && (
        <div className="mt-10">
          <h3 className="flex items-center gap-2 text-lg font-extrabold text-midnight">
            <Hourglass size={17} className="text-royal" />
            Awaiting scores ({pendingFiltered.length})
          </h3>
          <div className="mt-4 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {pendingFiltered.map((e) => (
              <Link
                key={e.slug}
                href={`/events/${e.slug}`}
                className="flex items-center justify-between gap-3 rounded-2xl border border-dashed border-royal/25 bg-white px-5 py-3.5 transition hover:border-royal hover:bg-mist"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-extrabold text-midnight">
                    {e.title}
                  </p>
                  <p className="truncate text-xs font-semibold text-greytext">
                    {e.venue}
                  </p>
                </div>
                <span className="shrink-0 rounded-full bg-amber-100 px-3 py-1 text-[10px] font-extrabold tracking-widest text-amber-700">
                  PENDING
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
