import { Sparkle } from "lucide-react";

export type PosterContent = {
  kicker: string;
  orgLine: string;
  title: string;
  tagline: string;
  monthLabel: string;
  startDay: string;
  endDay: string;
  dayRange: string;
  venue: string;
  welcome: string;
  imageUrl?: string;
  compact?: boolean;
  href?: string;
};

/**
 * The official AURA poster, rebuilt as crisp, responsive artwork so it can be
 * used on any portal instead of stock photography. An administrator can swap in
 * their own poster image via `imageUrl` (Settings → Poster).
 */
export default function AuraPoster({
  kicker = "WIDAD FRIENDS UNION",
  orgLine = "Worthy Individuals for Da'wa, Arts and Discipline",
  title = "Aura",
  tagline = "Arts Unite Reality & AI",
  monthLabel = "NOVEMBER 2026",
  startDay = "10",
  endDay = "16",
  dayRange = "Wednesday – Sunday",
  venue = "@ Main Auditorium",
  welcome = "Welcome to the ultimate celebration of art and talent..!",
  imageUrl,
  compact = false,
  href,
}: PosterContent) {
  const wrapper = (
    <div
      className={`relative isolate overflow-hidden rounded-[28px] border border-cream/15 poster-paper poster-grain poster-crease ${
        compact ? "px-5 py-8" : "px-6 py-10 sm:px-10 sm:py-14"
      }`}
    >
      {/* watermark stars */}
      <Sparkle
        aria-hidden
        className="pointer-events-none absolute left-4 top-1/3 h-16 w-16 text-cream/[0.07]"
        fill="currentColor"
      />
      <Sparkle
        aria-hidden
        className="pointer-events-none absolute bottom-10 right-6 h-24 w-24 text-cream/[0.05]"
        fill="currentColor"
      />

      {imageUrl ? (
        <img
          src={imageUrl}
          alt="AURA festival poster"
          className="mx-auto w-full max-w-md rounded-2xl shadow-2xl"
          loading="lazy"
        />
      ) : (
        <div className="relative mx-auto flex max-w-md flex-col items-center text-center">
          {/* emblem */}
          <span className="grid h-12 w-12 place-items-center rounded-xl bg-cream shadow-lg">
            <span className="font-display text-2xl font-extrabold leading-none text-deepnavy">
              A
            </span>
          </span>

          <p className="mt-4 text-[10.5px] font-bold uppercase tracking-[0.3em] text-cream/90">
            {kicker}
          </p>
          <p className="mx-auto mt-1.5 max-w-[19rem] text-[11.5px] leading-relaxed text-cream/60">
            {orgLine}
          </p>

          <span className="mt-4 h-px w-40 bg-cream/25" />

          {/* wordmark */}
          <div className="relative mt-5">
            <Sparkle
              aria-hidden
              className="absolute -right-3 -top-4 h-6 w-6 text-cream"
              fill="currentColor"
            />
            <h2
              className={`aura-wordmark leading-[0.95] ${
                compact ? "text-[58px]" : "text-[70px] sm:text-[86px]"
              }`}
            >
              {title}
            </h2>
          </div>

          <p
            className={`font-script mt-1 text-cream/90 ${
              compact ? "text-2xl" : "text-[26px] sm:text-3xl"
            }`}
          >
            {tagline}
          </p>

          {/* dates */}
          <p className="mt-6 text-[12px] font-bold uppercase tracking-[0.26em] text-cream/85">
            {monthLabel}
          </p>
          <div className="mt-2.5 flex items-center justify-center gap-2.5">
            <span className="grid h-14 w-14 place-items-center rounded-xl bg-cyan text-2xl font-extrabold text-deepnavy shadow-[0_10px_24px_-8px_rgba(53,190,234,0.8)]">
              {startDay}
            </span>
            <span className="font-script px-1 text-2xl text-cream/80">to</span>
            <span className="grid h-14 w-14 place-items-center rounded-xl bg-sun text-2xl font-extrabold text-deepnavy shadow-[0_10px_24px_-8px_rgba(245,210,74,0.8)]">
              {endDay}
            </span>
          </div>
          <p className="mt-3 text-[13px] font-semibold text-cyan">{dayRange}</p>
          <p className="text-[13px] font-semibold text-cream/85">{venue}</p>

          <p className="font-script mt-6 max-w-[17rem] text-xl leading-snug text-cream/90">
            {welcome}
          </p>

          <div className="mt-6 flex items-center gap-2 text-[9px] font-extrabold uppercase tracking-[0.24em] text-cream/60">
            <span className="grid h-6 w-6 place-items-center rounded-md bg-cream/15 text-cream">
              A
            </span>
            Officially organised by WIDAD FRIENDS
          </div>
        </div>
      )}
    </div>
  );

  return href ? (
    <a href={href} className="block transition hover:brightness-105">
      {wrapper}
    </a>
  ) : (
    wrapper
  );
}
