"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Play, Expand } from "lucide-react";
import { EmptyState } from "./ui";

export type GalleryEntry = {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  isVideo: boolean;
  videoUrl: string;
};

const CATS = [
  { v: "all", label: "All" },
  { v: "festival", label: "Festival" },
  { v: "competition", label: "Competitions" },
  { v: "teams", label: "Teams" },
  { v: "stage", label: "Stage" },
  { v: "moments", label: "Moments" },
];

export default function GalleryGrid({ items }: { items: GalleryEntry[] }) {
  const [cat, setCat] = useState("all");
  const [lightbox, setLightbox] = useState<number | null>(null);

  const filtered = useMemo(
    () => (cat === "all" ? items : items.filter((i) => i.category === cat)),
    [items, cat]
  );

  const close = useCallback(() => setLightbox(null), []);
  const step = useCallback(
    (dir: 1 | -1) =>
      setLightbox((cur) =>
        cur === null ? cur : (cur + dir + filtered.length) % filtered.length
      ),
    [filtered.length]
  );

  useEffect(() => {
    if (lightbox === null) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [lightbox, close, step]);

  const current = lightbox !== null ? filtered[lightbox] : null;

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {CATS.map((c) => (
          <button
            key={c.v}
            onClick={() => {
              setCat(c.v);
              setLightbox(null);
            }}
            aria-pressed={cat === c.v}
            className={`rounded-full px-5 py-2.5 text-[13px] font-extrabold transition ${
              cat === c.v
                ? "bg-midnight text-white shadow-lg"
                : "border border-slate-200 bg-white text-slate-600 hover:border-royal hover:text-royal"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            title="No photos yet"
            message="Festival photographs will appear here once published by the media team."
          />
        </div>
      ) : (
        <div className="mt-6 columns-2 gap-3 sm:gap-4 lg:columns-3 [&>*]:mb-3 sm:[&>*]:mb-4">
          {filtered.map((g, i) => (
            <motion.button
              key={g.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.45, delay: (i % 6) * 0.05 }}
              onClick={() => setLightbox(i)}
              className="group relative block w-full overflow-hidden rounded-3xl text-left shadow-sm transition hover:shadow-xl"
            >
              <img
                src={g.imageUrl}
                alt={g.title}
                loading="lazy"
                className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-midnight/85 via-midnight/10 to-transparent opacity-0 transition duration-300 group-hover:opacity-100" />
              <div className="absolute inset-x-0 bottom-0 translate-y-3 p-4 opacity-0 transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                <p className="text-sm font-extrabold text-white">{g.title}</p>
                <p className="mt-0.5 text-[11px] font-bold tracking-widest text-sky">
                  {g.category.toUpperCase()} · TAP TO EXPAND
                </p>
              </div>
              {g.isVideo && (
                <span className="absolute left-1/2 top-1/2 grid h-14 w-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-midnight shadow-xl">
                  <Play size={20} className="ml-0.5" />
                </span>
              )}
              <span className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-xl bg-midnight/60 text-white opacity-0 backdrop-blur transition group-hover:opacity-100">
                <Expand size={15} />
              </span>
            </motion.button>
          ))}
        </div>
      )}

      {/* lightbox */}
      <AnimatePresence>
        {current && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-midnight/95 p-4 backdrop-blur-sm"
            onClick={close}
            role="dialog"
            aria-modal="true"
            aria-label={current.title}
          >
            <button
              onClick={close}
              className="absolute right-4 top-4 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25"
              aria-label="Close viewer"
            >
              <X size={20} />
            </button>
            {filtered.length > 1 && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    step(-1);
                  }}
                  className="absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25 sm:left-6"
                  aria-label="Previous image"
                >
                  <ChevronLeft size={20} />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    step(1);
                  }}
                  className="absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25 sm:right-6"
                  aria-label="Next image"
                >
                  <ChevronRight size={20} />
                </button>
              </>
            )}
            <motion.figure
              key={current.id}
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="max-h-[88vh] w-full max-w-4xl overflow-hidden rounded-3xl bg-deepnavy shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              {current.isVideo && current.videoUrl ? (
                <video src={current.videoUrl} controls className="max-h-[70vh] w-full bg-black" />
              ) : (
                <img
                  src={current.imageUrl}
                  alt={current.title}
                  className="max-h-[70vh] w-full object-contain bg-black"
                />
              )}
              <figcaption className="flex items-center justify-between gap-4 p-5">
                <div>
                  <p className="text-base font-extrabold text-white">{current.title}</p>
                  {current.description && (
                    <p className="mt-1 text-sm text-slate-300">{current.description}</p>
                  )}
                </div>
                <p className="shrink-0 text-xs font-extrabold tracking-widest text-sky">
                  {(lightbox ?? 0) + 1} / {filtered.length}
                </p>
              </figcaption>
            </motion.figure>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
