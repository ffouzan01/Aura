"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Mail, Phone, MapPin, Heart } from "lucide-react";
import { AuraMark } from "./Navbar";
import {
  InstagramIcon,
  YoutubeIcon,
  XIcon,
  FacebookIcon,
} from "./icons";

type Settings = Record<string, string>;

export default function Footer({ initial }: { initial?: Settings }) {
  const [s, setS] = useState<Settings>(initial ?? {});

  useEffect(() => {
    if (initial && Object.keys(initial).length > 0) return;
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => d.settings && setS(d.settings))
      .catch(() => {});
  }, [initial]);

  const socials = [
    { icon: InstagramIcon, href: s.instagram_url, label: "Instagram" },
    { icon: YoutubeIcon, href: s.youtube_url, label: "YouTube" },
    { icon: XIcon, href: s.twitter_url, label: "Twitter / X" },
    { icon: FacebookIcon, href: s.facebook_url, label: "Facebook" },
  ];

  const cleanVenue =
    s.venue && !s.venue.toLowerCase().includes("widad campus") ? s.venue : "";

  return (
    <footer className="relative overflow-hidden bg-midnight text-white">
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[420px] w-[720px] -translate-x-1/2 rounded-full opacity-25 blur-[120px]"
        style={{ background: "linear-gradient(90deg,#1b6bb8,#35beea)" }}
      />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cream/50 to-transparent" />

      <div className="relative mx-auto max-w-7xl px-4 pb-10 pt-14 sm:px-6">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-4">
              <AuraMark size={44} />
              <div className="leading-none">
                <p className="aura-wordmark text-3xl leading-none">
                  {s.brand_wordmark || "AURA"}
                </p>
                <p className="mt-1.5 text-[10px] font-bold tracking-[0.3em] text-sky">
                  {s.brand_subtext || "WIDAD FRIENDS"}
                </p>
              </div>
            </div>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-slate-300">
              {s.footer_description ||
                "Officially organised by WIDAD FRIENDS UNION."}
            </p>
            <div className="mt-5 flex gap-2.5">
              {socials.map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href || "#"}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label}
                  className="grid h-10 w-10 place-items-center rounded-xl border border-white/15 bg-white/5 text-slate-200 transition hover:border-sky/60 hover:bg-royal hover:text-white"
                >
                  <Icon size={17} />
                </a>
              ))}
            </div>
          </div>

          {/* Portals */}
          <nav aria-label="Footer portals">
            <p className="text-xs font-extrabold tracking-[0.24em] text-sky">
              PORTALS
            </p>
            <ul className="mt-4 space-y-2.5 text-sm font-semibold text-slate-300">
              {[
                ["/about", "About AURA"],
                ["/events", "Events & Programs"],
                ["/schedule", "Auto Schedule"],
                ["/results", "Scores & Leaderboard"],
                ["/teams", "Teams & Candidates"],
              ].map(([href, label]) => (
                <li key={href}>
                  <Link href={href} className="transition hover:text-white">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Union */}
          <nav aria-label="Footer union">
            <p className="text-xs font-extrabold tracking-[0.24em] text-sky">
              UNION
            </p>
            <ul className="mt-4 space-y-2.5 text-sm font-semibold text-slate-300">
              {[
                ["/committee", "Committee"],
                ["/announcements", "Announcements"],
                ["/gallery", "Gallery"],
                ["/contact", "Contact"],
                ["/admin", "Admin Console"],
              ].map(([href, label]) => (
                <li key={href}>
                  <Link href={href} className="transition hover:text-white">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <p className="text-xs font-extrabold tracking-[0.24em] text-sky">
              CONTACT
            </p>
            <ul className="mt-4 space-y-3 text-sm font-semibold text-slate-300">
              <li className="flex items-start gap-2.5">
                <Mail size={16} className="mt-0.5 shrink-0 text-sky" />
                <span className="break-all">
                  {s.contact_email || "hello@aurafest.example"}
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <Phone size={16} className="mt-0.5 shrink-0 text-sky" />
                {s.contact_phone || "+91 90000 00000"}
              </li>
              {cleanVenue && (
                <li className="flex items-start gap-2.5">
                  <MapPin size={16} className="mt-0.5 shrink-0 text-sky" />
                  {cleanVenue}
                </li>
              )}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-xs font-semibold text-slate-400 sm:flex-row">
          <p>
            © {new Date().getFullYear()} AURA · {s.footer_rights || "All rights reserved."}
          </p>
          <p className="flex items-center gap-1.5">
            Crafted with <Heart size={12} className="fill-royal text-royal" /> for
            AURA
          </p>
        </div>
      </div>
    </footer>
  );
}
