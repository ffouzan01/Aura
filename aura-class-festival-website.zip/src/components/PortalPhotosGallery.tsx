"use client";

import { useCallback, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Expand, Camera } from "lucide-react";
import { Reveal } from "./ui";

export type PortalPhotoItem = {
  id: string;
  title: string;
  caption: string;
  imageUrl: string;
  alt: string;
};

export default function PortalPhotosGallery({
  portal,
  eyebrow,
  title,
  photos,
}: {
  portal: string;
  eyebrow: string;
  title: string;
  photos: PortalPhotoItem[];
}) {
  const [index, setIndex] = useState<number | null>(null);

  const close = useCallback(() => setIndex(null), []);
  const step = useCallback(
    (dir: 1 | -1) =>
      setIndex((cur) =>
        cur === null ? cur : (cur + dir + photos.length) % photos.length
      ),
    [photos.length]
  );

  useEffect(() => {
    if (index === null) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [index, close, step]);

  const current = index !== null ? photos[index] : null;

  return (
    <section
      className="bg-white"
      aria-label={`${portal} portal photos`}
      data-portal={portal}
    >
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-20">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="inline-flex items-center gap-2 rounded-full border border-royal/15 bg-royal/5 px-4 py-1.5 text-[11px] font-extrabold tracking-[0.22em] text-royal">
              <Camera size={12} /> {eyebrow}
            </p>
            <h2 className="font-display mt-4 text-3xl font-black tracking-tight text-midnight sm:text-4xl">
              {title}
            </h2>
          </div>
        </Reveal>

        <div
          className={`mt-8 grid gap-3 sm:gap-4 ${
            photos.length === 1
              ? "mx-auto max-w-3xl grid-cols-1"
              : photos.length === 2
              ? "grid-cols-1 sm:grid-cols-2"
              : photos.length === 3
              ? "grid-cols-2 sm:grid-cols-3"
              : "grid-cols-2 lg:grid-cols-4"
          }`}
        >
          {photos.map((p, i) => (
            <motion.button
              key={p.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.45, delay: (i % 4) * 0.06 }}
              onClick={() => setIndex(i)}
              className={`group relative overflow-hidden rounded-3xl bg-mist text-left shadow-sm ring-1 ring-slate-200/70 transition hover:shadow-xl ${
                photos.length === 1 ? "aspect-[16/9]" : "aspect-[4/3]"
              }`}
              aria-label={`Open photo: ${p.title || "portal photo"}`}
            >
              <img
                src={p.imageUrl}
                alt={p.alt || p.title || "AURA festival photo"}
                loading="lazy"
                decoding="async"
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-midnight/85 via-midnight/10 to-transparent opacity-0 transition duration-300 group-hover:opacity-100" />
              <span className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-xl bg-midnight/60 text-white opacity-0 backdrop-blur transition group-hover:opacity-100">
                <Expand size={15} />
              </span>
              {(p.title || p.caption) && (
                <span className="absolute inset-x-0 bottom-0 translate-y-2 p-4 opacity-0 transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                  {p.title && (
                    <span className="block text-[13px] font-extrabold text-white">
                      {p.title}
                    </span>
                  )}
                  {p.caption && (
                    <span className="mt-0.5 block line-clamp-2 text-[11px] font-semibold text-slate-200">
                      {p.caption}
                    </span>
                  )}
                </span>
              )}
            </motion.button>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {current && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-midnight/95 p-4 backdrop-blur-sm"
            onClick={close}
            role="dialog"
            aria-modal="true"
            aria-label={current.title || "Photo viewer"}
          >
            <button
              onClick={close}
              className="absolute right-4 top-4 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25"
              aria-label="Close photo viewer"
            >
              <X size={20} />
            </button>
            {photos.length > 1 && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    step(-1);
                  }}
                  className="absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25 sm:left-6"
                  aria-label="Previous photo"
                >
                  <ChevronLeft size={20} />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    step(1);
                  }}
                  className="absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25 sm:right-6"
                  aria-label="Next photo"
                >
                  <ChevronRight size={20} />
                </button>
              </>
            )}
            <motion.figure
              key={current.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="max-h-[88vh] w-full max-w-4xl overflow-hidden rounded-3xl bg-deepnavy shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={current.imageUrl}
                alt={current.alt || current.title || "AURA festival photo"}
                className="max-h-[72vh] w-full bg-black object-contain"
              />
              <figcaption className="flex items-center justify-between gap-4 p-5">
                <div>
                  {current.title && (
                    <p className="text-base font-extrabold text-white">
                      {current.title}
                    </p>
                  )}
                  {current.caption && (
                    <p className="mt-1 text-sm text-slate-300">
                      {current.caption}
                    </p>
                  )}
                </div>
                <p className="shrink-0 text-xs font-extrabold tracking-widest text-sky">
                  {(index ?? 0) + 1} / {photos.length}
                </p>
              </figcaption>
            </motion.figure>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
