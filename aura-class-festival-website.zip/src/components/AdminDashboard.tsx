"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  LayoutDashboard,
  CalendarClock,
  CalendarDays,
  Tags,
  Users,
  Trophy,
  Award,
  UserCheck,
  UserPlus,
  Megaphone,
  Image as ImageIcon,
  Camera,
  FileText,
  HeartHandshake,
  Inbox,
  Settings as SettingsIcon,
  LogOut,
  Plus,
  Pencil,
  Trash2,
  X,
  Loader2,
  ShieldCheck,
  LayoutGrid,
  Eye,
  EyeOff,
  Menu,
  Search,
  Save,
  CheckCircle2,
} from "lucide-react";
import { StatusBadge } from "./ui";
import { OFFICIAL_CATEGORIES } from "@/lib/categories";
import ComboField from "./admin/ComboField";
import { PORTAL_CONTENT_GROUPS } from "@/lib/portalContentRegistry";
import {
  formatDisplayTime,
  resolveProgramStatus,
  toTimeInputValue,
} from "@/lib/schedule";

/* ── types ─────────────────────────────────────────────── */
type Tab =
  | "overview"
  | "controls"
  | "schedule"
  | "results"
  | "pointlogs"
  | "participants"
  | "committee"
  | "events"
  | "categories"
  | "teams"
  | "members"
  | "announcements"
  | "gallery"
  | "portalphotos"
  | "portaldetails"
  | "messages"
  | "settings";

type Field =
  | { name: string; label: string; type: "text" | "date" | "time" | "number" | "image" }
  | { name: string; label: string; type: "textarea"; rows?: number }
  | { name: string; label: string; type: "select"; options: { v: string; l: string }[] }
  | { name: string; label: string; type: "check" }
  | {
      name: string;
      label: string;
      type: "ref";
      ref: "categories" | "teams" | "events" | "participants";
    }
  | { name: string; label: string; type: "category" };

const TABS: { key: Tab; label: string; icon: any }[] = [
  { key: "overview", label: "Overview", icon: LayoutDashboard },
  { key: "controls", label: "All Controls", icon: LayoutGrid },
  { key: "schedule", label: "Auto Schedule", icon: CalendarClock },
  { key: "results", label: "Scores & Points", icon: Trophy },
  { key: "pointlogs", label: "House Bonus Pts", icon: Award },
  { key: "participants", label: "Candidates", icon: UserCheck },
  { key: "committee", label: "Committee", icon: HeartHandshake },
  { key: "events", label: "Programs", icon: CalendarDays },
  { key: "categories", label: "Categories", icon: Tags },
  { key: "teams", label: "Houses (ALPHA/BETA)", icon: Users },
  { key: "members", label: "House Squads", icon: UserPlus },
  { key: "announcements", label: "Announcements", icon: Megaphone },
  { key: "gallery", label: "Gallery", icon: ImageIcon },
  { key: "portalphotos", label: "Portal Photos", icon: Camera },
  { key: "portaldetails", label: "Portal Details", icon: FileText },
  { key: "messages", label: "Messages", icon: Inbox },
  { key: "settings", label: "Site & Branding", icon: SettingsIcon },
];

const TEAM_COLORS = [
  "#1769E8",
  "#0B3FA0",
  "#7C3AED",
  "#0EA5E9",
  "#10B981",
  "#F59E0B",
  "#EC4899",
];

function fieldsFor(tab: Tab): Field[] {
  switch (tab) {
    case "events":
      return [
        { name: "title", label: "Program title", type: "text" },
        { name: "categoryId", label: "Category", type: "category" },
        { name: "description", label: "Description", type: "textarea", rows: 3 },
        { name: "rules", label: "Rules (one per line)", type: "textarea", rows: 4 },
        { name: "venue", label: "Stage / Venue", type: "text" },
        { name: "eventDate", label: "Scheduled Date", type: "date" },
        { name: "startTime", label: "Start Time", type: "time" },
        { name: "endTime", label: "End Time", type: "time" },
        {
          name: "autoSchedule",
          label: "Automated Time Status (auto-marks 'Program is Over' when time ends)",
          type: "check",
        },
        {
          name: "status",
          label: "Manual Override Status (used if Postponed or Auto disabled)",
          type: "select",
          options: [
            { v: "upcoming", l: "Upcoming" },
            { v: "ongoing", l: "Live Now" },
            { v: "completed", l: "Program is Over" },
            { v: "postponed", l: "Postponed" },
          ],
        },
        {
          name: "eventType",
          label: "Program Type",
          type: "select",
          options: [
            { v: "individual", l: "Individual" },
            { v: "group", l: "Group" },
          ],
        },
        {
          name: "participatingTeams",
          label: "Houses",
          type: "select",
          options: [
            { v: "both", l: "Both (ALPHA vs BETA)" },
            { v: "alpha", l: "ALPHA only" },
            { v: "beta", l: "BETA only" },
          ],
        },
        { name: "isFeatured", label: "Featured program", type: "check" },
        { name: "registrationInfo", label: "Entry instructions", type: "textarea", rows: 2 },
        { name: "maxParticipants", label: "Entry limit (e.g. 2 per house)", type: "text" },
        { name: "imageUrl", label: "Cover Image URL", type: "image" },
        { name: "pointsFirst", label: "Points · 1st Place", type: "number" },
        { name: "pointsSecond", label: "Points · 2nd Place", type: "number" },
        { name: "pointsThird", label: "Points · 3rd Place", type: "number" },
      ];
    case "results":
      return [
        { name: "eventId", label: "Program", type: "ref", ref: "events" },
        {
          name: "__candidatePick",
          label: "Quick-fill from Registered Candidate (optional)",
          type: "ref",
          ref: "participants",
        },
        {
          name: "position",
          label: "Position",
          type: "select",
          options: [
            { v: "1", l: "🥇 1st Place" },
            { v: "2", l: "🥈 2nd Place" },
            { v: "3", l: "🥉 3rd Place" },
            { v: "0", l: "✦ Grade / Score Entry" },
          ],
        },
        { name: "chestNumber", label: "Chest No. (e.g. A-101)", type: "text" },
        { name: "participantName", label: "Candidate / Winner Name", type: "text" },
        { name: "teamId", label: "House (ALPHA / BETA)", type: "ref", ref: "teams" },
        { name: "score", label: "Score / Marks (e.g. 95/100)", type: "text" },
        {
          name: "grade",
          label: "Grade",
          type: "select",
          options: [
            { v: "", l: "— None —" },
            { v: "A+", l: "A+" },
            { v: "A", l: "A" },
            { v: "B", l: "B" },
            { v: "C", l: "C" },
          ],
        },
        { name: "points", label: "Points Awarded to House", type: "number" },
        { name: "note", label: "Judge / Result Note", type: "text" },
        {
          name: "isPublished",
          label: "Publish Live (updates Leaderboard & Program page)",
          type: "check",
        },
      ];
    case "pointlogs":
      return [
        { name: "teamId", label: "House (ALPHA / BETA)", type: "ref", ref: "teams" },
        { name: "title", label: "Reason / Award Title (e.g. Overall Discipline)", type: "text" },
        { name: "points", label: "Points (+/-)", type: "number" },
        { name: "note", label: "Details / Note", type: "text" },
        { name: "isPublished", label: "Publish to Live Leaderboard", type: "check" },
      ];
    case "participants":
      return [
        { name: "chestNumber", label: "Chest Number (e.g. A-101)", type: "text" },
        { name: "name", label: "Candidate / Group Name", type: "text" },
        { name: "teamId", label: "House (ALPHA / BETA)", type: "ref", ref: "teams" },
        { name: "eventId", label: "Assigned Program", type: "ref", ref: "events" },
      ];
    case "committee":
      return [
        { name: "name", label: "Full Name", type: "text" },
        { name: "position", label: "Role / Position", type: "text" },
        {
          name: "category",
          label: "Committee Wing",
          type: "select",
          options: [
            { v: "leadership", l: "Fest Coordinator" },
            { v: "event", l: "Team Leaders" },
            { v: "organizing", l: "Team Members" },
          ],
        },
        { name: "bio", label: "Short Bio / Responsibility", type: "textarea", rows: 2 },
        { name: "photoUrl", label: "Photo URL", type: "image" },
        { name: "email", label: "Email", type: "text" },
        { name: "phone", label: "Phone", type: "text" },
        { name: "displayOrder", label: "Display Order", type: "number" },
        { name: "isPlaceholder", label: "Mark as TBA Placeholder", type: "check" },
      ];
    case "portalphotos":
      return [
        {
          name: "portal",
          label: "Portal page",
          type: "select",
          options: [
            { v: "home", l: "Home" },
            { v: "about", l: "About AURA" },
            { v: "events", l: "Events & Programs" },
            { v: "teams", l: "Teams & Candidates" },
            { v: "schedule", l: "Auto Schedule" },
            { v: "results", l: "Scores & Leaderboard" },
            { v: "gallery", l: "Gallery" },
            { v: "announcements", l: "Announcements" },
            { v: "committee", l: "Committee" },
            { v: "contact", l: "Contact" },
          ],
        },
        { name: "title", label: "Photo title", type: "text" },
        { name: "caption", label: "Caption / description", type: "textarea", rows: 2 },
        { name: "imageUrl", label: "Photo (paste a URL or upload a file)", type: "image" },
        { name: "alt", label: "Alt text (accessibility)", type: "text" },
        { name: "displayOrder", label: "Display order", type: "number" },
        { name: "isActive", label: "Show on the portal page", type: "check" },
      ];
    case "categories":
      return [
        { name: "name", label: "Name", type: "text" },
        { name: "description", label: "Description", type: "textarea", rows: 2 },
        {
          name: "icon",
          label: "Icon key",
          type: "select",
          options: [
            "book",
            "palette",
            "music",
            "drama",
            "trophy",
            "brain",
            "sparkles",
            "star",
          ].map((v) => ({ v, l: v })),
        },
        { name: "color", label: "Color", type: "text" },
        { name: "displayOrder", label: "Display order", type: "number" },
      ];
    case "teams":
      return [
        { name: "name", label: "House Name", type: "text" },
        { name: "tagline", label: "Tagline", type: "text" },
        { name: "description", label: "Description", type: "textarea", rows: 3 },
        { name: "motto", label: "Motto", type: "text" },
        { name: "emblem", label: "Emblem (letter/symbol)", type: "text" },
        { name: "colorPrimary", label: "Primary Color", type: "text" },
        { name: "colorSecondary", label: "Secondary Color", type: "text" },
        { name: "captainName", label: "Captain Name", type: "text" },
        { name: "viceCaptainName", label: "Vice-Captain Name", type: "text" },
        { name: "logoUrl", label: "Logo URL", type: "image" },
      ];
    case "members":
      return [
        { name: "teamId", label: "House", type: "ref", ref: "teams" },
        { name: "name", label: "Member Name", type: "text" },
        { name: "role", label: "Role", type: "text" },
        { name: "note", label: "Note", type: "text" },
        { name: "positionOrder", label: "Order", type: "number" },
        { name: "isPlaceholder", label: "Placeholder (TBA)", type: "check" },
      ];
    case "announcements":
      return [
        { name: "title", label: "Title", type: "text" },
        { name: "description", label: "Description", type: "textarea", rows: 3 },
        {
          name: "category",
          label: "Category",
          type: "select",
          options: [
            "General",
            "Event",
            "Schedule",
            "Registration",
            "News",
            "Instruction",
          ].map((v) => ({ v, l: v })),
        },
        {
          name: "priority",
          label: "Priority",
          type: "select",
          options: [
            { v: "info", l: "Info" },
            { v: "important", l: "Important" },
            { v: "urgent", l: "Urgent (pinned)" },
          ],
        },
        { name: "publishDate", label: "Publish Date", type: "date" },
        { name: "isPublished", label: "Published", type: "check" },
      ];
    case "gallery":
      return [
        { name: "title", label: "Title", type: "text" },
        { name: "description", label: "Description", type: "textarea", rows: 2 },
        { name: "imageUrl", label: "Image URL", type: "image" },
        {
          name: "category",
          label: "Category",
          type: "select",
          options: [
            { v: "festival", l: "Festival" },
            { v: "competition", l: "Competitions" },
            { v: "teams", l: "Teams" },
            { v: "stage", l: "Stage" },
            { v: "moments", l: "Moments" },
          ],
        },
        { name: "isVideo", label: "Is Video", type: "check" },
        { name: "videoUrl", label: "Video URL", type: "text" },
        { name: "displayOrder", label: "Display Order", type: "number" },
      ];
    default:
      return [];
  }
}

const SETTING_GROUPS: {
  title: string;
  keys: {
    k: string;
    label: string;
    type: "text" | "textarea" | "select";
    options?: string[];
  }[];
}[] = [
  {
    title: "Official Logo & Branding",
    keys: [
      { k: "brand_wordmark", label: "Brand wordmark (e.g. AURA)", type: "text" },
      { k: "brand_subtext", label: "Brand sub-text", type: "text" },
      { k: "hero_badge", label: "Hero badge line", type: "text" },
    ],
  },
  {
    title: "Festival Identity & Motto",
    keys: [
      { k: "festival_name", label: "Festival Name", type: "text" },
      { k: "festival_tagline", label: "Tagline", type: "text" },
      {
        k: "festival_motto",
        label: "Hero Motto (2 creative sentences)",
        type: "textarea",
      },
      { k: "organizer_name", label: "Organiser Name", type: "text" },
    ],
  },
  {
    title: "About Content",
    keys: [
      { k: "about_aura", label: "About AURA", type: "textarea" },
      { k: "about_organizer", label: "About Organiser", type: "textarea" },
      { k: "vision", label: "Vision", type: "textarea" },
      { k: "mission", label: "Mission", type: "textarea" },
    ],
  },
  {
    title: "Venue & Visibility (optional)",
    keys: [
      { k: "venue", label: "Venue (leave blank to hide)", type: "text" },
      { k: "venue_address", label: "Venue Address", type: "text" },
      { k: "festival_hours", label: "Festival hours (contact portal)", type: "text" },
      {
        k: "registration_open",
        label: "Registrations Open",
        type: "select",
        options: ["true", "false"],
      },
      { k: "registration_note", label: "Registration Note", type: "textarea" },
      {
        k: "results_visible",
        label: "Results Visible",
        type: "select",
        options: ["true", "false"],
      },
    ],
  },
  {
    title: "Contact & Social Links",
    keys: [
      { k: "contact_email", label: "Contact Email", type: "text" },
      { k: "contact_phone", label: "Contact Phone", type: "text" },
      { k: "instagram_url", label: "Instagram URL", type: "text" },
      { k: "youtube_url", label: "YouTube URL", type: "text" },
      { k: "twitter_url", label: "X / Twitter URL", type: "text" },
      { k: "facebook_url", label: "Facebook URL", type: "text" },
    ],
  },
];

/* ── Build ISO timestamp from local date + HH:MM ───────── */
function buildLocalIso(dateStr?: string | null, timeStr?: string | null): string | null {
  if (!dateStr || !timeStr) return null;
  const hhmm = toTimeInputValue(timeStr);
  if (!hhmm) return null;
  const dt = new Date(`${dateStr}T${hhmm}:00`);
  if (Number.isNaN(dt.getTime())) return null;
  return dt.toISOString();
}

/* ── Main Admin Dashboard ──────────────────────────────── */
export default function AdminDashboard() {
  const [admin, setAdmin] = useState<{ name: string; username: string } | null>(null);
  const [checking, setChecking] = useState(true);
  const [login, setLogin] = useState({ username: "admin", password: "" });
  const [loginError, setLoginError] = useState("");
  const [loggingIn, setLoggingIn] = useState(false);
  const [showPw, setShowPw] = useState(false);

  const [tab, setTab] = useState<Tab>("controls");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [rows, setRows] = useState<any[]>([]);
  const [refs, setRefs] = useState<{
    categories: any[];
    teams: any[];
    events: any[];
    participants: any[];
  }>({
    categories: [],
    teams: [],
    events: [],
    participants: [],
  });
  const [refsLoading, setRefsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [overview, setOverview] = useState<any>(null);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsMsg, setSettingsMsg] = useState("");

  const [modal, setModal] = useState<{
    resource: Tab;
    mode: "add" | "edit";
    data: any;
  } | null>(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [deleting, setDeleting] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const checkSession = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/auth");
      const data = await res.json();
      if (res.ok && data.admin) setAdmin(data.admin);
    } catch {
      /* not logged in */
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  const loadRefs = useCallback(async () => {
    setRefsLoading(true);
    const getJson = async (url: string) => {
      try {
        const res = await fetch(url, { cache: "no-store" });
        if (!res.ok) return null;
        return await res.json();
      } catch {
        return null;
      }
    };

    try {
      const [cats, parts, publicRefs] = await Promise.all([
        getJson("/api/admin/crud?resource=categories"),
        getJson("/api/admin/crud?resource=participants"),
        getJson("/api/refs"),
      ]);

      // Houses and Programs always come from the live database so the admin can
      // pick ALPHA / BETA and every program created in the Programs portal.
      const houses = Array.isArray(publicRefs?.houses) ? publicRefs.houses : [];
      const programs = Array.isArray(publicRefs?.programs)
        ? publicRefs.programs
        : [];

      let categories = Array.isArray(cats?.data) ? cats.data : [];

      // If the public endpoint is unreachable (e.g. offline), fall back to the
      // privileged endpoints so the fields are still populated.
      if (houses.length === 0 || programs.length === 0) {
        const [t, e] = await Promise.all([
          getJson("/api/admin/crud?resource=teams"),
          getJson("/api/admin/crud?resource=events"),
        ]);
        if (Array.isArray(t?.data) && t.data.length > 0) {
          houses.push(...t.data.map((x: any) => ({
            id: x.id,
            name: x.name,
            slug: x.slug,
            colorPrimary: x.colorPrimary,
            colorSecondary: x.colorSecondary,
            emblem: x.emblem,
          })));
        }
        if (Array.isArray(e?.data) && e.data.length > 0) {
          programs.push(...e.data.map((x: any) => ({
            id: x.id,
            title: x.title,
            slug: x.slug,
            eventDate: x.eventDate,
          })));
        }
      }
      if (categories.length === 0) {
        const c = await getJson("/api/admin/crud?resource=categories");
        categories = Array.isArray(c?.data) ? c.data : [];
      }

      setRefs({
        categories,
        teams: houses,
        events: programs,
        participants: Array.isArray(parts?.data) ? parts.data : [],
      });
    } finally {
      setRefsLoading(false);
    }
  }, []);

  const loadTab = useCallback(async (t: Tab) => {
    if (t === "controls") {
      setRows([]);
      return;
    }
    if (t === "overview") {
      setLoading(true);
      try {
        const res = await fetch("/api/admin/overview");
        setOverview(await res.json());
      } catch {
        setOverview(null);
      } finally {
        setLoading(false);
      }
      return;
    }
    if (t === "settings") {
      setLoading(true);
      try {
        const res = await fetch("/api/admin/crud?resource=settings");
        const data = await res.json();
        const map: Record<string, string> = {};
        for (const g of PORTAL_CONTENT_GROUPS) {
          for (const f of g.fields) map[f.key] = f.default;
        }
        for (const r of data.data ?? []) map[r.key] = r.value;
        setSettings(map);
      } catch {
        /* ignore */
      } finally {
        setLoading(false);
      }
      return;
    }
    const resource = t === "schedule" ? "events" : t;
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/crud?resource=${resource}`);
      const data = await res.json();
      setRows(data.data ?? []);
    } catch {
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (admin) {
      loadRefs();
      loadTab(tab);
    }
  }, [admin, tab, loadRefs, loadTab]);

  const doLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoggingIn(true);
    setLoginError("");
    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(login),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      setAdmin(data.admin);
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoggingIn(false);
    }
  };

  const doLogout = async () => {
    await fetch("/api/admin/auth", { method: "DELETE" });
    setAdmin(null);
    setTab("controls");
  };

  const saveRow = async () => {
    if (!modal) return;
    setSaving(true);
    setFormError("");
    const targetResource = modal.resource === "schedule" ? "events" : modal.resource;
    try {
      const payload: Record<string, unknown> = { ...modal.data };
      delete payload.__candidatePick;
      delete payload.__view;
      if (payload.categorySlug === undefined) delete payload.categorySlug;

      for (const f of fieldsFor(targetResource)) {
        if (f.type === "number" && payload[f.name] !== "" && payload[f.name] !== undefined) {
          payload[f.name] = Number(payload[f.name]);
        }
        if (f.name === "position" && payload.position !== undefined) {
          payload.position = Number(payload.position);
        }
        if (f.type === "ref" && f.name !== "__candidatePick" && payload[f.name] === "") {
          payload[f.name] = null;
        }
      }

      if (targetResource === "events") {
        const sTime = payload.startTime ? String(payload.startTime) : "";
        const eTime = payload.endTime ? String(payload.endTime) : "";
        const eDate = payload.eventDate ? String(payload.eventDate) : "";
        payload.startTime = sTime ? formatDisplayTime(sTime) : "";
        payload.endTime = eTime ? formatDisplayTime(eTime) : "";
        payload.startAt = buildLocalIso(eDate, sTime);
        payload.endAt = buildLocalIso(eDate, eTime);
      }

      let res: Response;
      if (modal.mode === "add") {
        res = await fetch(`/api/admin/crud?resource=${targetResource}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch(
          `/api/admin/crud?resource=${targetResource}&id=${modal.data.id}`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          }
        );
      }
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Save failed");
      setModal(null);
      loadTab(tab);
      loadRefs();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const deleteRow = async (id: string, customResource?: string) => {
    if (!confirm("Delete this record? This cannot be undone.")) return;
    setDeleting(id);
    const resName = customResource ?? (tab === "schedule" ? "events" : tab);
    try {
      await fetch(`/api/admin/crud?resource=${resName}&id=${id}`, {
        method: "DELETE",
      });
      setRows((r) => r.filter((x) => x.id !== id));
      loadRefs();
    } finally {
      setDeleting(null);
    }
  };

  const saveSettings = async () => {
    setSavingSettings(true);
    setSettingsMsg("");
    try {
      const res = await fetch("/api/admin/crud?resource=settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          Object.entries(settings).map(([key, value]) => ({ key, value }))
        ),
      });
      if (!res.ok) throw new Error("Save failed");
      setSettingsMsg("Settings saved.");
      setTimeout(() => setSettingsMsg(""), 3000);
    } catch {
      setSettingsMsg("Failed to save settings.");
    } finally {
      setSavingSettings(false);
    }
  };

  const filteredRows = useMemo(() => {
    const needle = search.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter((r) =>
      Object.values(r).some((v) => String(v ?? "").toLowerCase().includes(needle))
    );
  }, [rows, search]);

  const refLabel = (
    ref: "categories" | "teams" | "events" | "participants",
    id: string | null
  ) => {
    if (!id) return "—";
    const found = refs[ref].find((x) => x.id === id);
    return found ? found.title ?? found.name ?? "—" : "—";
  };

  /* ── Handle modal field updates (with smart auto-fill for Scores & Points) ── */
  const updateModalField = (name: string, val: unknown) => {
    if (!modal) return;
    const next = { ...modal.data, [name]: val };

    // Auto-fill candidate details when selecting a registered candidate in Results
    if (modal.resource === "results" && name === "__candidatePick" && val) {
      const cand = refs.participants.find((p) => p.id === val);
      if (cand) {
        next.participantName = cand.name;
        next.chestNumber = cand.chestNumber || "";
        next.teamId = cand.teamId || null;
        if (cand.eventId && !next.eventId) next.eventId = cand.eventId;
      }
    }

    // Auto-fill default points when Program or Position changes in Results
    if (
      modal.resource === "results" &&
      (name === "eventId" || name === "position")
    ) {
      const evId = name === "eventId" ? val : next.eventId;
      const pos = Number(name === "position" ? val : next.position);
      const ev = refs.events.find((e) => e.id === evId);
      if (ev) {
        if (pos === 1) next.points = ev.pointsFirst ?? 10;
        else if (pos === 2) next.points = ev.pointsSecond ?? 7;
        else if (pos === 3) next.points = ev.pointsThird ?? 5;
      }
    }

    setModal({ ...modal, data: next });
  };

  /* ── Login Screen ─────────────────────────────────── */
  if (checking) {
    return (
      <div className="grid min-h-[80vh] place-items-center bg-midnight pt-24">
        <Loader2 className="animate-spin text-sky" size={32} />
      </div>
    );
  }

  if (!admin) {
    return (
      <div className="relative flex min-h-[90vh] items-center justify-center overflow-hidden bg-midnight px-4 pb-16 pt-28">
        <div className="bg-hero-grid absolute inset-0" />
        <div
          className="pointer-events-none absolute left-1/2 top-16 h-72 w-[560px] -translate-x-1/2 rounded-full opacity-30 blur-[120px]"
          style={{ background: "linear-gradient(90deg,#1769E8,#75C3FF)" }}
        />
        <div className="relative w-full max-w-md rounded-[28px] border border-white/15 bg-white/[0.06] p-8 backdrop-blur-2xl sm:p-10">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-royal to-electric text-white shadow-xl">
            <ShieldCheck size={26} />
          </div>
          <h1 className="font-display mt-4 text-center text-2xl font-black tracking-tight text-white">
            AURA Admin Console
          </h1>
          <p className="mt-1.5 text-center text-[11px] font-extrabold tracking-[0.28em] text-sky">
            COMMITTEE · CANDIDATES · SCORES · SCHEDULE
          </p>
          <form onSubmit={doLogin} className="mt-8 space-y-4">
            <div>
              <label
                htmlFor="au"
                className="mb-1.5 block text-[11px] font-extrabold tracking-widest text-slate-300"
              >
                ADMIN ID
              </label>
              <input
                id="au"
                value={login.username}
                onChange={(e) => setLogin({ ...login, username: e.target.value })}
                className="w-full rounded-2xl border border-white/15 bg-white/10 px-4 py-3.5 text-sm font-bold text-white outline-none placeholder:text-slate-400 focus:border-sky"
                placeholder="admin"
                autoComplete="username"
                required
              />
            </div>
            <div>
              <label
                htmlFor="ap"
                className="mb-1.5 block text-[11px] font-extrabold tracking-widest text-slate-300"
              >
                PASSWORD
              </label>
              <div className="relative">
                <input
                  id="ap"
                  type={showPw ? "text" : "password"}
                  value={login.password}
                  onChange={(e) => setLogin({ ...login, password: e.target.value })}
                  className="w-full rounded-2xl border border-white/15 bg-white/10 px-4 py-3.5 pr-12 text-sm font-bold text-white outline-none placeholder:text-slate-400 focus:border-sky"
                  placeholder="Enter admin password"
                  autoComplete="current-password"
                  autoFocus
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  aria-label={showPw ? "Hide password" : "Show password"}
                >
                  {showPw ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </div>
            {loginError && (
              <p
                role="alert"
                className="rounded-2xl bg-red-500/15 px-4 py-3 text-sm font-bold text-red-300"
              >
                {loginError}
              </p>
            )}
            <button
              type="submit"
              disabled={loggingIn}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-royal to-electric px-4 py-4 text-sm font-extrabold tracking-widest text-white shadow-xl transition hover:brightness-110 disabled:opacity-60"
            >
              {loggingIn && <Loader2 size={16} className="animate-spin" />}
              UNLOCK ADMIN CONSOLE
            </button>
          </form>
        </div>
      </div>
    );
  }

  /* ── Authenticated Admin Shell ────────────────────── */
  const activeResource = tab === "schedule" ? "events" : tab;

  return (
    <div className="min-h-[88vh] bg-mist/70 pt-24 sm:pt-28">
      {/* mobile topbar */}
      <div className="mx-4 mb-4 flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm lg:hidden">
        <button
          onClick={() => setSidebarOpen((v) => !v)}
          className="inline-flex items-center gap-2 rounded-xl bg-midnight px-4 py-2.5 text-[13px] font-extrabold text-white"
        >
          <Menu size={15} /> {TABS.find((t) => t.key === tab)?.label}
        </button>
        <button
          onClick={doLogout}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 py-2.5 text-[12px] font-extrabold text-slate-600"
          aria-label="Log out"
        >
          <LogOut size={14} />
        </button>
      </div>

      <div className="mx-auto flex max-w-[1440px] gap-6 px-4 pb-14 sm:px-6">
        {/* sidebar */}
        <aside
          className={`fixed inset-y-0 left-0 z-50 w-68 shrink-0 -translate-x-full bg-midnight p-4 transition-transform lg:static lg:z-auto lg:w-64 lg:translate-x-0 lg:rounded-[24px] ${
            sidebarOpen ? "translate-x-0" : ""
          }`}
        >
          <div className="flex items-center justify-between px-2 pb-4 pt-2">
            <div>
              <p className="font-display text-lg font-black tracking-[0.16em] text-white">
                AURA
              </p>
              <p className="text-[9px] font-bold tracking-[0.28em] text-sky">
                CONTROL CENTER
              </p>
            </div>
            <button
              onClick={() => setSidebarOpen(false)}
              className="text-slate-400 lg:hidden"
              aria-label="Close menu"
            >
              <X size={18} />
            </button>
          </div>
          <nav
            className="max-h-[68vh] space-y-1 overflow-y-auto pr-1"
            aria-label="Admin sections"
          >
            {TABS.map((t) => (
              <button
                key={t.key}
                onClick={() => {
                  setTab(t.key);
                  setSearch("");
                  setSidebarOpen(false);
                }}
                className={`flex w-full items-center gap-3 rounded-2xl px-4 py-2.5 text-[13px] font-bold transition ${
                  tab === t.key
                    ? "bg-gradient-to-r from-royal to-electric text-white shadow-lg"
                    : "text-slate-300 hover:bg-white/10 hover:text-white"
                }`}
              >
                <t.icon size={16} />
                {t.label}
              </button>
            ))}
          </nav>
          <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-4">
            <p className="truncate text-sm font-extrabold text-white">{admin.name}</p>
            <p className="text-xs font-semibold text-slate-400">@{admin.username}</p>
            <button
              onClick={doLogout}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-white/10 px-3 py-2.5 text-[12px] font-extrabold tracking-widest text-white transition hover:bg-red-500/80"
            >
              <LogOut size={14} /> LOG OUT
            </button>
          </div>
        </aside>
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-40 bg-midnight/60 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Workspace */}
        <div className="min-w-0 flex-1">
          {tab === "overview" ? (
            <OverviewPanel
              overview={overview}
              loading={loading}
              go={(t) => setTab(t)}
            />
          ) : tab === "controls" ? (
            <AllControlsPanel go={(t) => setTab(t)} />
          ) : tab === "schedule" ? (
            <ScheduleManagerPanel
              events={rows}
              loading={loading}
              onRefresh={() => {
                loadTab("schedule");
                loadRefs();
              }}
              onAddProgram={() =>
                setModal({
                  resource: "events",
                  mode: "add",
                  data: defaultFor("events"),
                })
              }
            />
          ) : tab === "portaldetails" ? (
            <div className="rounded-[24px] border border-slate-200 bg-white p-5 sm:p-7">
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-royal/10 px-3 py-1 text-[10.5px] font-extrabold tracking-widest text-royal">
                    <FileText size={13} /> EVERY PORTAL IN YOUR CONTROL
                  </span>
                  <h2 className="mt-2 text-xl font-extrabold text-midnight">
                    Portal Details & Wording
                  </h2>
                  <p className="mt-1 max-w-2xl text-xs font-semibold leading-relaxed text-greytext">
                    Write the wording that appears on every portal page — hero
                    labels, titles, subtitles, the home about block and the footer.
                    Blank fields fall back to the built-in scaffold text.
                  </p>
                </div>
                <button
                  onClick={saveSettings}
                  disabled={savingSettings}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-royal to-electric px-5 py-3 text-[13px] font-extrabold tracking-widest text-white shadow-lg disabled:opacity-60"
                >
                  {savingSettings ? (
                    <Loader2 size={15} className="animate-spin" />
                  ) : (
                    <Save size={15} />
                  )}
                  SAVE ALL PORTAL DETAILS
                </button>
              </div>

              {loading ? (
                <div className="grid place-items-center py-16">
                  <Loader2 className="animate-spin text-royal" size={26} />
                </div>
              ) : (
                <div className="mt-5 space-y-6">
                  {PORTAL_CONTENT_GROUPS.map((group) => (
                    <section
                      key={group.portal}
                      className="rounded-2xl border border-slate-200/80 bg-mist/40 p-4 sm:p-5"
                    >
                      <h3 className="text-[12px] font-extrabold tracking-[0.2em] text-royal">
                        {group.title.toUpperCase()}
                      </h3>
                      <p className="mt-0.5 text-[11.5px] font-semibold text-greytext">
                        {group.description}
                      </p>
                      <div className="mt-3 grid gap-3 md:grid-cols-2">
                        {group.fields.map((f) => (
                          <div
                            key={f.key}
                            className={f.type === "textarea" ? "md:col-span-2" : ""}
                          >
                            <label className="mb-1 block text-[12px] font-extrabold text-slate-600">
                              {f.label}
                            </label>
                            {f.type === "image" ? (
                              <div className="space-y-2">
                                <input
                                  value={settings[f.key] ?? ""}
                                  onChange={(e) =>
                                    setSettings({ ...settings, [f.key]: e.target.value })
                                  }
                                  placeholder="https://… or upload your poster"
                                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                                />
                                <div className="flex flex-wrap items-center gap-2">
                                  <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-royal/25 bg-royal/5 px-4 py-2.5 text-[12px] font-extrabold tracking-wide text-royal transition hover:bg-royal/10">
                                    <Camera size={14} /> UPLOAD POSTER
                                    <input
                                      type="file"
                                      accept="image/*"
                                      className="hidden"
                                      onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (!file) return;
                                        if (file.size > 1200 * 1024) {
                                          setSettingsMsg(
                                            "Poster is too large — use an image under 1.2 MB or paste a URL."
                                          );
                                          return;
                                        }
                                        const reader = new FileReader();
                                        reader.onload = () =>
                                          setSettings({
                                            ...settings,
                                            [f.key]: String(reader.result ?? ""),
                                          });
                                        reader.readAsDataURL(file);
                                        e.target.value = "";
                                      }}
                                    />
                                  </label>
                                  {settings[f.key] && (
                                    <img
                                      src={settings[f.key]}
                                      alt="Poster preview"
                                      className="h-16 w-auto rounded-lg border border-slate-200 object-cover"
                                    />
                                  )}
                                  {settings[f.key] && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setSettings({ ...settings, [f.key]: "" })
                                      }
                                      className="rounded-xl border border-slate-200 px-3 py-2 text-[12px] font-extrabold text-slate-500 hover:border-red-300 hover:text-red-500"
                                    >
                                      USE BUILT-IN
                                    </button>
                                  )}
                                </div>
                              </div>
                            ) : f.type === "textarea" ? (
                              <textarea
                                rows={2}
                                value={settings[f.key] ?? f.default}
                                onChange={(e) =>
                                  setSettings({ ...settings, [f.key]: e.target.value })
                                }
                                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                              />
                            ) : (
                              <input
                                value={settings[f.key] ?? f.default}
                                onChange={(e) =>
                                  setSettings({ ...settings, [f.key]: e.target.value })
                                }
                                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </section>
                  ))}
                  {settingsMsg && (
                    <p className="text-sm font-bold text-emerald-600">{settingsMsg}</p>
                  )}
                </div>
              )}
            </div>
          ) : tab === "settings" ? (
            <div className="rounded-[24px] border border-slate-200 bg-white p-6 sm:p-8">
              <h2 className="text-xl font-extrabold text-midnight">
                General Settings
              </h2>
              <p className="mt-1 text-sm font-semibold text-greytext">
                Manage the festival motto, tagline, about story, optional venue and
                contact links.
              </p>
              {loading ? (
                <Loader2 className="mt-8 animate-spin text-royal" size={26} />
              ) : (
                <div className="mt-6 space-y-8">
                  {SETTING_GROUPS.map((g) => (
                    <div key={g.title}>
                      <h3 className="text-[12px] font-extrabold tracking-[0.24em] text-royal">
                        {g.title.toUpperCase()}
                      </h3>
                      <div className="mt-3 grid gap-4 md:grid-cols-2">
                        {g.keys.map((f) => (
                          <div
                            key={f.k}
                            className={f.type === "textarea" ? "md:col-span-2" : ""}
                          >
                            <label className="mb-1.5 block text-[12px] font-extrabold text-slate-600">
                              {f.label}
                            </label>
                            {f.type === "textarea" ? (
                              <textarea
                                rows={3}
                                value={settings[f.k] ?? ""}
                                onChange={(e) =>
                                  setSettings({ ...settings, [f.k]: e.target.value })
                                }
                                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                              />
                            ) : f.type === "select" ? (
                              <select
                                value={settings[f.k] ?? "true"}
                                onChange={(e) =>
                                  setSettings({ ...settings, [f.k]: e.target.value })
                                }
                                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-royal"
                              >
                                {f.options!.map((o) => (
                                  <option key={o} value={o}>
                                    {o}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <input
                                value={settings[f.k] ?? ""}
                                onChange={(e) =>
                                  setSettings({ ...settings, [f.k]: e.target.value })
                                }
                                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={saveSettings}
                      disabled={savingSettings}
                      className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-royal to-electric px-8 py-3.5 text-sm font-extrabold tracking-widest text-white shadow-lg transition hover:brightness-110 disabled:opacity-60"
                    >
                      {savingSettings && (
                        <Loader2 size={15} className="animate-spin" />
                      )}
                      SAVE ALL SETTINGS
                    </button>
                    {settingsMsg && (
                      <p className="text-sm font-bold text-emerald-600">
                        {settingsMsg}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-[24px] border border-slate-200 bg-white p-5 sm:p-7">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-extrabold text-midnight">
                    {TABS.find((t) => t.key === tab)?.label}
                  </h2>
                  <p className="text-[13px] font-semibold text-greytext">
                    {filteredRows.length} record
                    {filteredRows.length !== 1 ? "s" : ""}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search
                      size={15}
                      className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                    />
                    <input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search…"
                      className="rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-[13px] font-bold outline-none focus:border-royal"
                      aria-label="Search records"
                    />
                  </div>
                  {tab !== "messages" && (
                    <button
                      onClick={() => {
                        void loadRefs();
                        setModal({
                          resource: tab,
                          mode: "add",
                          data: defaultFor(tab),
                        });
                      }}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-midnight px-4 py-2.5 text-[13px] font-extrabold text-white transition hover:bg-deepnavy"
                    >
                      <Plus size={15} /> ADD NEW
                    </button>
                  )}
                </div>
              </div>

              {loading ? (
                <div className="grid place-items-center py-16">
                  <Loader2 className="animate-spin text-royal" size={28} />
                </div>
              ) : filteredRows.length === 0 ? (
                <p className="mt-6 rounded-2xl bg-mist p-8 text-center text-sm font-bold text-greytext">
                  No records yet.{" "}
                  {tab !== "messages" && "Click “Add New” to create one."}
                </p>
              ) : (
                <div className="mt-5 space-y-2.5">
                  {filteredRows.map((r) => (
                    <div
                      key={r.id}
                      className="flex items-center gap-3 rounded-2xl border bg-white px-4 py-3 shadow-[0_1px_2px_rgba(16,41,75,0.06)] transition hover:border-royal/30"
                      style={{ borderColor: "#e8eef8" }}
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-extrabold text-midnight">
                          {rowTitle(tab, r, refLabel)}
                        </p>
                        <p className="truncate text-xs font-semibold text-greytext">
                          {rowSubtitle(tab, r, refLabel)}
                        </p>
                      </div>
                      {rowBadge(tab, r)}
                      {tab === "messages" ? (
                        <>
                          {!r.isRead && (
                            <button
                              onClick={async () => {
                                await fetch(
                                  `/api/admin/crud?resource=messages&id=${r.id}`,
                                  {
                                    method: "PUT",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ isRead: true }),
                                  }
                                );
                                loadTab(tab);
                              }}
                              className="rounded-lg bg-emerald-50 px-3 py-2 text-[11px] font-extrabold text-emerald-700 hover:bg-emerald-100"
                            >
                              MARK READ
                            </button>
                          )}
                          <button
                            onClick={() =>
                              setModal({
                                resource: tab,
                                mode: "edit",
                                data: { ...r, __view: true },
                              })
                            }
                            className="grid h-9 w-9 place-items-center rounded-xl bg-mist text-royal hover:bg-royal hover:text-white"
                            aria-label="View message"
                          >
                            <Eye size={15} />
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() =>
                            setModal({
                              resource: tab,
                              mode: "edit",
                              data: prepareEditData(tab, r),
                            })
                          }
                          className="grid h-9 w-9 place-items-center rounded-xl bg-mist text-royal transition hover:bg-royal hover:text-white"
                          aria-label="Edit"
                        >
                          <Pencil size={15} />
                        </button>
                      )}
                      <button
                        onClick={() => deleteRow(r.id)}
                        disabled={deleting === r.id}
                        className="grid h-9 w-9 place-items-center rounded-xl bg-red-50 text-red-500 transition hover:bg-red-500 hover:text-white disabled:opacity-50"
                        aria-label="Delete"
                      >
                        {deleting === r.id ? (
                          <Loader2 size={15} className="animate-spin" />
                        ) : (
                          <Trash2 size={15} />
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Modal */}
      {modal && (
        <div
          className="fixed inset-0 z-[75] flex items-end justify-center bg-midnight/65 p-0 backdrop-blur-sm sm:items-center sm:p-6"
          onClick={() => !saving && setModal(null)}
        >
          <div
            className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-[28px] bg-white p-6 sm:rounded-[28px] sm:p-8"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-midnight">
                {modal.data.__view
                  ? "Message Details"
                  : modal.mode === "add"
                  ? `Add ${
                      TABS.find((t) => t.key === modal.resource)?.label ?? "Record"
                    }`
                  : `Edit ${
                      TABS.find((t) => t.key === modal.resource)?.label ?? "Record"
                    }`}
              </h3>
              <button
                onClick={() => setModal(null)}
                className="grid h-9 w-9 place-items-center rounded-xl bg-mist text-slate-500"
                aria-label="Close"
              >
                <X size={17} />
              </button>
            </div>

            {modal.data.__view ? (
              <div className="mt-5 space-y-3 text-sm">
                <p>
                  <span className="font-extrabold text-slate-500">From:</span>{" "}
                  <span className="font-bold">
                    {modal.data.name} · {modal.data.email}
                  </span>
                </p>
                {modal.data.phone && (
                  <p>
                    <span className="font-extrabold text-slate-500">Phone:</span>{" "}
                    <span className="font-bold">{modal.data.phone}</span>
                  </p>
                )}
                {modal.data.subject && (
                  <p>
                    <span className="font-extrabold text-slate-500">Subject:</span>{" "}
                    <span className="font-bold">{modal.data.subject}</span>
                  </p>
                )}
                <div className="rounded-2xl bg-mist p-4 font-semibold leading-relaxed text-slate-700">
                  {modal.data.message}
                </div>
              </div>
            ) : (
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                {fieldsFor(
                  modal.resource === "schedule" ? "events" : modal.resource
                ).map((f) => (
                  <div
                    key={f.name}
                    className={
                      f.type === "textarea" || f.type === "check"
                        ? "sm:col-span-2"
                        : ""
                    }
                  >
                    {f.type === "check" ? (
                      <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-slate-200 px-4 py-3">
                        <input
                          type="checkbox"
                          checked={!!modal.data[f.name]}
                          onChange={(e) =>
                            updateModalField(f.name, e.target.checked)
                          }
                          className="h-5 w-5 accent-[#1769E8]"
                        />
                        <span className="text-sm font-extrabold text-midnight">
                          {f.label}
                        </span>
                      </label>
                    ) : (
                      <>
                        <label className="mb-1.5 block text-[12px] font-extrabold text-slate-600">
                          {f.label}
                        </label>
                        {f.type === "textarea" ? (
                          <textarea
                            rows={f.rows ?? 3}
                            value={modal.data[f.name] ?? ""}
                            onChange={(e) =>
                              updateModalField(f.name, e.target.value)
                            }
                            className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                          />
                        ) : f.type === "select" ? (
                          <select
                            value={String(
                              modal.data[f.name] ?? f.options[0]?.v ?? ""
                            )}
                            onChange={(e) =>
                              updateModalField(f.name, e.target.value)
                            }
                            className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold outline-none focus:border-royal"
                          >
                            {f.options.map((o) => (
                              <option key={o.v} value={o.v}>
                                {o.l}
                              </option>
                            ))}
                          </select>
                        ) : f.type === "category" ? (
                          <ComboField
                            loading={refsLoading}
                            onRetry={loadRefs}
                            value={
                              modal.data.categorySlug ??
                              refs.categories.find(
                                (c: any) => c.id === modal.data.categoryId
                              )?.slug ??
                              null
                            }
                            placeholder="— Select category —"
                            createLabel="Add category"
                            options={[
                              ...OFFICIAL_CATEGORIES.map((c) => ({
                                value: c.slug,
                                label: c.name,
                              })),
                              ...refs.categories
                                .filter(
                                  (c: any) =>
                                    !OFFICIAL_CATEGORIES.some(
                                      (o) => o.slug === c.slug
                                    )
                                )
                                .map((c: any) => ({
                                  value: c.slug,
                                  label: c.name,
                                })),
                            ]}
                            onChange={(slug) => {
                              const match = refs.categories.find(
                                (c: any) => c.slug === slug
                              );
                              setModal({
                                ...modal,
                                data: {
                                  ...modal.data,
                                  categorySlug: slug,
                                  categoryId: match?.id ?? null,
                                },
                              });
                            }}
                            onCreate={async (label) => {
                              const res = await fetch(
                                "/api/admin/crud?resource=categories",
                                {
                                  method: "POST",
                                  headers: { "Content-Type": "application/json" },
                                  body: JSON.stringify({ name: label }),
                                }
                              );
                              const json = await res.json();
                              if (!res.ok) return null;
                              await loadRefs();
                              const slug = json?.data?.slug ?? null;
                              const id = json?.data?.id ?? null;
                              if (slug) {
                                setModal((cur) =>
                                  cur
                                    ? {
                                        ...cur,
                                        data: {
                                          ...cur.data,
                                          categorySlug: slug,
                                          categoryId: id,
                                        },
                                      }
                                    : cur
                                );
                              }
                              return slug
                                ? { value: slug, label: json.data.name }
                                : null;
                            }}
                          />
                        ) : f.type === "ref" ? (
                          <ComboField
                            value={modal.data[f.name] ?? null}
                            loading={refsLoading}
                            onRetry={loadRefs}
                            emptyActionLabel={
                              f.ref === "events"
                                ? "Manage programs"
                                : f.ref === "teams"
                                ? "Manage houses"
                                : undefined
                            }
                            onEmptyAction={
                              f.ref === "events"
                                ? () => {
                                    setModal(null);
                                    setTab("events");
                                  }
                                : f.ref === "teams"
                                ? () => {
                                    setModal(null);
                                    setTab("teams");
                                  }
                                : undefined
                            }
                            placeholder={
                              f.name === "__candidatePick"
                                ? "— Pick a registered candidate —"
                                : f.ref === "teams"
                                ? "ALPHA or BETA — type to search"
                                : f.ref === "events"
                                ? "— Select or add a program —"
                                : "— Select —"
                            }
                            createLabel={
                              f.ref === "teams"
                                ? "Add house"
                                : f.ref === "events"
                                ? "Create program"
                                : "Add"
                            }
                            options={refs[f.ref]
                              .filter((x: any) =>
                                f.name === "__candidatePick" && modal.data.eventId
                                  ? x.eventId === modal.data.eventId
                                  : true
                              )
                              .map((x: any) => ({
                                value: x.id,
                                label:
                                  f.ref === "participants"
                                    ? `${x.chestNumber ? `#${x.chestNumber} · ` : ""}${x.name}`
                                    : f.ref === "events" && x.category
                                    ? `${x.title}${x.eventDate ? ` · ${x.eventDate}` : ""}`
                                    : x.title ?? x.name,
                              }))}
                            onChange={(id) => updateModalField(f.name, id)}
                            onCreate={
                              f.ref === "teams"
                                ? async (label) => {
                                    const res = await fetch(
                                      "/api/admin/crud?resource=teams",
                                      {
                                        method: "POST",
                                        headers: { "Content-Type": "application/json" },
                                        body: JSON.stringify({
                                          name: label,
                                          slug:
                                            label
                                              .toLowerCase()
                                              .replace(/[^a-z0-9]+/g, "-")
                                              .replace(/^-|-$/g, "") +
                                            "-" +
                                            Date.now().toString(36),
                                          emblem: label.charAt(0).toUpperCase(),
                                        }),
                                      }
                                    );
                                    const json = await res.json();
                                    if (!res.ok) return null;
                                    await loadRefs();
                                    updateModalField(f.name, json.data.id);
                                    return { value: json.data.id, label: json.data.name };
                                  }
                                : f.ref === "events"
                                ? async (label) => {
                                    const res = await fetch(
                                      "/api/admin/crud?resource=events",
                                      {
                                        method: "POST",
                                        headers: { "Content-Type": "application/json" },
                                        body: JSON.stringify({
                                          title: label,
                                          categorySlug: "general",
                                          eventType: "individual",
                                          participatingTeams: "both",
                                          status: "upcoming",
                                          autoSchedule: true,
                                        }),
                                      }
                                    );
                                    const json = await res.json();
                                    if (!res.ok) return null;
                                    await loadRefs();
                                    updateModalField(f.name, json.data.id);
                                    return { value: json.data.id, label: json.data.title };
                                  }
                                : undefined
                            }
                          />
                        ) : f.type === "image" ? (
                          <div className="space-y-2">
                            <div className="flex gap-2">
                              <input
                                value={modal.data[f.name] ?? ""}
                                onChange={(e) =>
                                  updateModalField(f.name, e.target.value)
                                }
                                placeholder="https://… or upload below"
                                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-royal"
                              />
                              {modal.data[f.name] && (
                                <img
                                  src={modal.data[f.name]}
                                  alt=""
                                  className="h-12 w-12 shrink-0 rounded-xl object-cover"
                                />
                              )}
                            </div>
                            <div className="flex flex-wrap items-center gap-2">
                              <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-royal/25 bg-royal/5 px-4 py-2.5 text-[12px] font-extrabold tracking-wide text-royal transition hover:bg-royal/10">
                                <Camera size={14} />
                                UPLOAD PHOTO
                                <input
                                  type="file"
                                  accept="image/*"
                                  className="hidden"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (!file) return;
                                    if (file.size > 1200 * 1024) {
                                      setFormError(
                                        "Photo is too large. Choose an image under 1.2 MB or paste an image URL."
                                      );
                                      return;
                                    }
                                    setFormError("");
                                    const reader = new FileReader();
                                    reader.onload = () => {
                                      updateModalField(
                                        f.name,
                                        String(reader.result ?? "")
                                      );
                                      if (!modal.data.title) {
                                        updateModalField(
                                          "title",
                                          file.name.replace(/\.[a-z0-9]+$/i, "")
                                        );
                                      }
                                    };
                                    reader.readAsDataURL(file);
                                    e.target.value = "";
                                  }}
                                />
                              </label>
                              {modal.data[f.name] && (
                                <button
                                  type="button"
                                  onClick={() => updateModalField(f.name, "")}
                                  className="rounded-xl border border-slate-200 px-3 py-2.5 text-[12px] font-extrabold text-slate-500 transition hover:border-red-300 hover:text-red-500"
                                >
                                  REMOVE
                                </button>
                              )}
                              <span className="text-[11px] font-semibold text-slate-400">
                                JPG · PNG · WEBP · SVG · max 1.2 MB
                              </span>
                            </div>
                          </div>
                        ) : f.type === "time" ? (
                          <input
                            type="time"
                            value={toTimeInputValue(modal.data[f.name] ?? "")}
                            onChange={(e) =>
                              updateModalField(f.name, e.target.value)
                            }
                            className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                          />
                        ) : (
                          <div className="flex gap-2">
                            <input
                              type={
                                f.type === "number"
                                  ? "number"
                                  : f.type === "date"
                                  ? "date"
                                  : "text"
                              }
                              value={modal.data[f.name] ?? ""}
                              onChange={(e) =>
                                updateModalField(f.name, e.target.value)
                              }
                              className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-royal focus:ring-4 focus:ring-royal/10"
                            />
                            {f.name.toLowerCase().includes("color") && (
                              <input
                                type="color"
                                value={
                                  /^#[0-9a-f]{6}$/i.test(modal.data[f.name] ?? "")
                                    ? modal.data[f.name]
                                    : "#1769E8"
                                }
                                onChange={(e) =>
                                  updateModalField(f.name, e.target.value)
                                }
                                className="h-12 w-12 shrink-0 cursor-pointer rounded-xl border border-slate-200"
                                aria-label="Pick color"
                              />
                            )}
                          </div>
                        )}
                        {f.name.toLowerCase().includes("color") &&
                          f.type === "text" && (
                            <div className="mt-2 flex gap-1.5">
                              {TEAM_COLORS.map((c) => (
                                <button
                                  key={c}
                                  type="button"
                                  onClick={() => updateModalField(f.name, c)}
                                  className="h-7 w-7 rounded-lg border-2 border-white shadow"
                                  style={{ background: c }}
                                  aria-label={`Use ${c}`}
                                />
                              ))}
                            </div>
                          )}
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}

            {formError && (
              <p
                role="alert"
                className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-600"
              >
                {formError}
              </p>
            )}

            {!modal.data.__view && (
              <div className="mt-6 flex gap-3">
                <button
                  onClick={() => setModal(null)}
                  className="flex-1 rounded-2xl border border-slate-200 px-4 py-3.5 text-sm font-extrabold text-slate-600"
                >
                  CANCEL
                </button>
                <button
                  onClick={saveRow}
                  disabled={saving}
                  className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-royal to-electric px-4 py-3.5 text-sm font-extrabold tracking-widest text-white shadow-lg disabled:opacity-60"
                >
                  {saving && <Loader2 size={15} className="animate-spin" />}
                  {modal.mode === "add" ? "CREATE" : "SAVE CHANGES"}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Master "All Controls" Panel ───────────────────────── */
const CONTROL_GROUPS: {
  heading: string;
  items: { tab: Tab; title: string; desc: string }[];
}[] = [
  {
    heading: "Programs & Schedule",
    items: [
      { tab: "schedule", title: "Auto Schedule", desc: "Set date, start/end times and auto-mark programs as over." },
      { tab: "events", title: "Programs", desc: "Create, edit and delete every festival program." },
      { tab: "categories", title: "Categories", desc: "Stage · Stage Group · Non Stage · General · Sports." },
    ],
  },
  {
    heading: "Scores & Points",
    items: [
      { tab: "results", title: "Scores & Points", desc: "1st / 2nd / 3rd prize, scores, grades and points." },
      { tab: "pointlogs", title: "House Bonus Points", desc: "Award or deduct direct ALPHA / BETA points." },
      { tab: "participants", title: "Candidates", desc: "Chest numbers, houses and assigned programs." },
    ],
  },
  {
    heading: "People & Houses",
    items: [
      { tab: "committee", title: "Committee", desc: "Fest Coordinator, Team Leaders, Team Members." },
      { tab: "teams", title: "Houses", desc: "ALPHA & BETA identity, captains and colours." },
      { tab: "members", title: "House Squads", desc: "House member rosters and roles." },
    ],
  },
  {
    heading: "Publishing & Branding",
    items: [
      { tab: "announcements", title: "Announcements", desc: "Official notices, priorities and drafts." },
      { tab: "gallery", title: "Gallery", desc: "Festival photographs and highlights." },
      { tab: "portalphotos", title: "Portal Photos", desc: "Add photos to every portal page — upload or paste a URL." },
      { tab: "portaldetails", title: "Portal Details", desc: "Write the wording shown on every portal page and the footer." },
      { tab: "messages", title: "Messages", desc: "Enquiries submitted through the contact form." },
      { tab: "settings", title: "Logo & Branding", desc: "Official logo, wordmark, hero badge and brand text." },
      { tab: "settings", title: "Site Content & Settings", desc: "Motto, about content, contact and social links." },
    ],
  },
];

function AllControlsPanel({ go }: { go: (t: Tab) => void }) {
  return (
    <div className="space-y-5">
      <div className="rounded-[24px] bg-midnight p-6 text-white sm:p-8">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-[10.5px] font-extrabold tracking-widest text-sky">
          <LayoutGrid size={13} /> MASTER CONTROL
        </span>
        <h2 className="font-display mt-3 text-2xl font-black tracking-tight">
          All Controls in one place
        </h2>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-300">
          Manage every part of AURA from this console — programs and automated
          scheduling, categories, candidates, committee, scores, points, houses,
          announcements, gallery and site settings.
        </p>
      </div>

      {CONTROL_GROUPS.map((g) => (
        <div key={g.heading}>
          <h3 className="text-[11.5px] font-extrabold tracking-[0.24em] text-royal">
            {g.heading.toUpperCase()}
          </h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {g.items.map((item) => (
              <button
                key={item.tab + item.title}
                onClick={() => go(item.tab)}
                className="group rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-royal/40 hover:shadow-lg"
              >
                <p className="flex items-center justify-between text-sm font-extrabold text-midnight">
                  {item.title}
                  <span className="text-royal opacity-0 transition group-hover:opacity-100">
                    →
                  </span>
                </p>
                <p className="mt-1 text-xs font-semibold leading-relaxed text-greytext">
                  {item.desc}
                </p>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ── Dedicated Automated Schedule Manager Panel ────────── */
function ScheduleManagerPanel({
  events,
  loading,
  onRefresh,
  onAddProgram,
}: {
  events: any[];
  loading: boolean;
  onRefresh: () => void;
  onAddProgram: () => void;
}) {
  const [drafts, setDrafts] = useState<
    Record<
      string,
      {
        eventDate: string;
        startTime: string;
        endTime: string;
        venue: string;
        mode: "auto" | "completed" | "ongoing" | "postponed";
      }
    >
  >({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 5000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const init: typeof drafts = {};
    for (const ev of events) {
      let mode: "auto" | "completed" | "ongoing" | "postponed" = "auto";
      if (ev.status === "postponed") mode = "postponed";
      else if (ev.status === "completed") mode = "completed";
      else if (ev.autoSchedule === false && ev.status === "ongoing") mode = "ongoing";

      init[ev.id] = {
        eventDate: ev.eventDate ?? "",
        startTime: toTimeInputValue(ev.startTime),
        endTime: toTimeInputValue(ev.endTime),
        venue: ev.venue ?? "",
        mode,
      };
    }
    setDrafts(init);
  }, [events]);

  const saveSchedule = async (ev: any) => {
    const d = drafts[ev.id];
    if (!d) return;
    setSavingId(ev.id);
    try {
      const autoSchedule = d.mode === "auto";
      const status =
        d.mode === "auto"
          ? "upcoming"
          : d.mode === "completed"
          ? "completed"
          : d.mode === "ongoing"
          ? "ongoing"
          : "postponed";

      const payload = {
        eventDate: d.eventDate || null,
        startTime: d.startTime ? formatDisplayTime(d.startTime) : "",
        endTime: d.endTime ? formatDisplayTime(d.endTime) : "",
        startAt: buildLocalIso(d.eventDate, d.startTime),
        endAt: buildLocalIso(d.eventDate, d.endTime),
        venue: d.venue,
        autoSchedule,
        status,
      };

      const res = await fetch(`/api/admin/crud?resource=events&id=${ev.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        setSavedId(ev.id);
        setTimeout(() => setSavedId((cur) => (cur === ev.id ? null : cur)), 2000);
        onRefresh();
      }
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="rounded-[24px] border border-slate-200 bg-white p-5 sm:p-7">
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-royal/10 px-3 py-1 text-[10.5px] font-extrabold tracking-widest text-royal">
            <CalendarClock size={13} /> AUTOMATED PROGRAM SCHEDULER
          </span>
          <h2 className="mt-2 text-xl font-extrabold text-midnight">
            Schedule Programs & Auto-Completion
          </h2>
          <p className="mt-1 max-w-2xl text-xs font-semibold leading-relaxed text-greytext">
            Set each program&apos;s Date, Start Time and End Time. In{" "}
            <strong className="text-midnight">Auto by Clock</strong> mode, the
            website automatically shows <strong>Live Now</strong> during the window
            and switches to <strong>Program is Over</strong> as soon as the end time
            passes.
          </p>
        </div>
        <button
          onClick={onAddProgram}
          className="inline-flex items-center gap-1.5 rounded-xl bg-midnight px-4 py-2.5 text-[13px] font-extrabold text-white transition hover:bg-deepnavy"
        >
          <Plus size={15} /> NEW PROGRAM
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-16">
          <Loader2 className="animate-spin text-royal" size={28} />
        </div>
      ) : (
        <div className="mt-5 space-y-3">
          {events.map((ev) => {
            const d = drafts[ev.id] ?? {
              eventDate: ev.eventDate ?? "",
              startTime: toTimeInputValue(ev.startTime),
              endTime: toTimeInputValue(ev.endTime),
              venue: ev.venue ?? "",
              mode: "auto" as const,
            };

            const liveResolved = resolveProgramStatus(
              {
                eventDate: d.eventDate || ev.eventDate,
                startTime: d.startTime || ev.startTime,
                endTime: d.endTime || ev.endTime,
                startAt: buildLocalIso(d.eventDate, d.startTime) ?? ev.startAt,
                endAt: buildLocalIso(d.eventDate, d.endTime) ?? ev.endAt,
                autoSchedule: d.mode === "auto",
                status:
                  d.mode === "auto"
                    ? "upcoming"
                    : d.mode === "completed"
                    ? "completed"
                    : d.mode === "ongoing"
                    ? "ongoing"
                    : "postponed",
              },
              nowMs
            );

            return (
              <div
                key={ev.id}
                className="rounded-2xl border border-slate-200/80 bg-mist/40 p-4 transition hover:border-royal/30"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-[15px] font-extrabold text-midnight">
                      {ev.title}
                    </p>
                    <p className="text-xs font-semibold text-greytext">
                      {ev.eventType === "group" ? "Group" : "Individual"} ·{" "}
                      {d.venue || "Venue TBA"}
                    </p>
                  </div>
                  <StatusBadge
                    status={liveResolved.code}
                    label={liveResolved.label}
                  />
                </div>

                <div className="mt-3 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-[150px_130px_130px_1fr_185px_auto]">
                  <div>
                    <label className="mb-1 block text-[10px] font-extrabold tracking-wider text-slate-500">
                      DATE
                    </label>
                    <input
                      type="date"
                      value={d.eventDate}
                      onChange={(e) =>
                        setDrafts({
                          ...drafts,
                          [ev.id]: { ...d, eventDate: e.target.value },
                        })
                      }
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-midnight outline-none focus:border-royal"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-extrabold tracking-wider text-slate-500">
                      START TIME
                    </label>
                    <input
                      type="time"
                      value={d.startTime}
                      onChange={(e) =>
                        setDrafts({
                          ...drafts,
                          [ev.id]: { ...d, startTime: e.target.value },
                        })
                      }
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-midnight outline-none focus:border-royal"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-extrabold tracking-wider text-slate-500">
                      END TIME
                    </label>
                    <input
                      type="time"
                      value={d.endTime}
                      onChange={(e) =>
                        setDrafts({
                          ...drafts,
                          [ev.id]: { ...d, endTime: e.target.value },
                        })
                      }
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-midnight outline-none focus:border-royal"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-extrabold tracking-wider text-slate-500">
                      VENUE / STAGE
                    </label>
                    <input
                      type="text"
                      value={d.venue}
                      placeholder="Stage / Hall"
                      onChange={(e) =>
                        setDrafts({
                          ...drafts,
                          [ev.id]: { ...d, venue: e.target.value },
                        })
                      }
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-midnight outline-none focus:border-royal"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-extrabold tracking-wider text-slate-500">
                      MODE
                    </label>
                    <select
                      value={d.mode}
                      onChange={(e) =>
                        setDrafts({
                          ...drafts,
                          [ev.id]: {
                            ...d,
                            mode: e.target.value as typeof d.mode,
                          },
                        })
                      }
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-midnight outline-none focus:border-royal"
                    >
                      <option value="auto">Auto by Clock</option>
                      <option value="ongoing">Force Live Now</option>
                      <option value="completed">Mark Program is Over</option>
                      <option value="postponed">Postponed</option>
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button
                      type="button"
                      onClick={() => saveSchedule(ev)}
                      disabled={savingId === ev.id}
                      className={`inline-flex h-[36px] w-full items-center justify-center gap-1.5 rounded-xl px-4 text-xs font-extrabold tracking-wider text-white transition lg:w-auto ${
                        savedId === ev.id
                          ? "bg-emerald-600"
                          : "bg-royal hover:bg-deepnavy"
                      }`}
                    >
                      {savingId === ev.id ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : savedId === ev.id ? (
                        <>
                          <CheckCircle2 size={14} /> SAVED
                        </>
                      ) : (
                        <>
                          <Save size={14} /> SAVE
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ── Helpers ───────────────────────────────────────────── */
function prepareEditData(tab: Tab, row: any) {
  if (tab === "events") {
    return {
      ...row,
      startTime: toTimeInputValue(row.startTime),
      endTime: toTimeInputValue(row.endTime),
    };
  }
  return { ...row };
}

function defaultFor(tab: Tab): any {
  switch (tab) {
    case "events":
      return {
        categorySlug: "",
        eventType: "individual",
        participatingTeams: "both",
        status: "upcoming",
        autoSchedule: true,
        isFeatured: false,
        pointsFirst: 10,
        pointsSecond: 7,
        pointsThird: 5,
      };
    case "results":
      return { position: "1", points: 10, grade: "", isPublished: true };
    case "pointlogs":
      return { points: 10, isPublished: true };
    case "participants":
      return {};
    case "announcements":
      return { category: "General", priority: "info", isPublished: true };
    case "gallery":
      return { category: "festival", isVideo: false, displayOrder: 0 };
    case "portalphotos":
      return { portal: "home", displayOrder: 0, isActive: true };
    case "committee":
      return { category: "organizing", displayOrder: 0, isPlaceholder: false };
    case "members":
      return { role: "Member", positionOrder: 0, isPlaceholder: false };
    case "categories":
      return { color: "#1769E8", icon: "sparkles", displayOrder: 0 };
    default:
      return {};
  }
}

function rowTitle(
  tab: Tab,
  r: any,
  refLabel: (ref: any, id: string | null) => string
): string {
  switch (tab) {
    case "events":
      return r.title;
    case "results":
      return `${refLabel("events", r.eventId)} — ${
        r.position >= 1 ? `P${r.position}` : "Score"
      } · ${r.participantName}${r.chestNumber ? ` (#${r.chestNumber})` : ""}`;
    case "pointlogs":
      return `${refLabel("teams", r.teamId)} — ${r.title} (${
        r.points >= 0 ? `+${r.points}` : r.points
      } pts)`;
    case "participants":
      return `${r.chestNumber ? `#${r.chestNumber} · ` : ""}${r.name}`;
    case "members":
      return `${r.name} (${r.role})`;
    case "announcements":
      return r.title;
    case "portalphotos":
      return r.caption || (r.isActive ? "Visible on portal" : "Hidden");
    case "messages":
      return `${r.name} — ${r.subject || "No subject"}`;
    default:
      return r.title ?? r.name ?? "Record";
  }
}

function rowSubtitle(
  tab: Tab,
  r: any,
  refLabel: (ref: any, id: string | null) => string
): string {
  switch (tab) {
    case "events":
      return `${r.eventDate || "Date TBA"} · ${r.startTime || "TBA"}${
        r.endTime ? `–${r.endTime}` : ""
      } · ${r.venue || "Venue TBA"}`;
    case "results":
      return `${refLabel("teams", r.teamId)}${
        r.score ? ` · Score: ${r.score}` : ""
      }${r.grade ? ` · Grade ${r.grade}` : ""} · ${r.points} pts`;
    case "pointlogs":
      return r.note || "Direct house points";
    case "participants":
      return `${refLabel("teams", r.teamId)} · ${refLabel("events", r.eventId)}`;
    case "members":
      return refLabel("teams", r.teamId);
    case "announcements":
      return `${r.category} · ${r.priority}`;
    case "gallery":
      return r.category;
    case "portalphotos":
      return `${r.portal} · ${r.title || "Untitled photo"}`;
    case "committee":
      return `${r.position} · ${r.category}`;
    case "categories":
      return r.slug ?? "";
    case "teams":
      return `Captain: ${r.captainName} · ${r.tagline ?? ""}`;
    case "messages":
      return `${r.email} · ${new Date(r.createdAt).toLocaleDateString()}`;
    default:
      return "";
  }
}

function rowBadge(tab: Tab, r: any) {
  if (tab === "events") {
    const resolved = resolveProgramStatus(r);
    return (
      <span className="hidden shrink-0 sm:inline-flex">
        <StatusBadge status={resolved.code} label={resolved.label} />
      </span>
    );
  }
  if (
    (tab === "results" || tab === "announcements" || tab === "pointlogs") &&
    r.isPublished !== undefined
  ) {
    return (
      <span
        className={`hidden shrink-0 rounded-full px-3 py-1 text-[10px] font-extrabold uppercase sm:inline ${
          r.isPublished
            ? "bg-emerald-100 text-emerald-700"
            : "bg-slate-200 text-slate-500"
        }`}
      >
        {r.isPublished ? "Live" : "Draft"}
      </span>
    );
  }
  if (tab === "portalphotos") {
    return (
      <span
        className={`hidden shrink-0 rounded-full px-3 py-1 text-[10px] font-extrabold uppercase sm:inline ${
          r.isActive ? "bg-emerald-100 text-emerald-700" : "bg-slate-200 text-slate-500"
        }`}
      >
        {r.isActive ? "Live" : "Hidden"}
      </span>
    );
  }
  if (tab === "messages") {
    return (
      <span
        className={`hidden shrink-0 rounded-full px-3 py-1 text-[10px] font-extrabold uppercase sm:inline ${
          r.isRead ? "bg-slate-200 text-slate-500" : "bg-royal/10 text-royal"
        }`}
      >
        {r.isRead ? "Read" : "New"}
      </span>
    );
  }
  return null;
}

function OverviewPanel({
  overview,
  loading,
  go,
}: {
  overview: any;
  loading: boolean;
  go: (t: Tab) => void;
}) {
  if (loading) {
    return (
      <div className="grid place-items-center rounded-[24px] border border-slate-200 bg-white py-24">
        <Loader2 className="animate-spin text-royal" size={28} />
      </div>
    );
  }
  if (!overview) {
    return (
      <div className="rounded-[24px] border border-slate-200 bg-white p-8 text-center text-sm font-bold text-greytext">
        Failed to load overview.
      </div>
    );
  }
  const stats = [
    { label: "Programs", value: overview.totals.events, tab: "events" as Tab },
    {
      label: "Candidates",
      value: overview.totals.participants,
      tab: "participants" as Tab,
    },
    {
      label: "Committee",
      value: overview.totals.committee ?? 0,
      tab: "committee" as Tab,
    },
    {
      label: "Scores Declared",
      value: overview.totals.publishedResults,
      tab: "results" as Tab,
    },
    {
      label: "Programs Over",
      value: overview.totals.over ?? 0,
      tab: "schedule" as Tab,
    },
  ];
  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {stats.map((s) => (
          <button
            key={s.label}
            onClick={() => go(s.tab)}
            className="rounded-[20px] border border-slate-200 bg-white p-5 text-left transition hover:border-royal/40 hover:shadow-lg"
          >
            <p className="text-3xl font-extrabold text-midnight">{s.value}</p>
            <p className="mt-1 text-[11px] font-extrabold tracking-[0.18em] text-greytext">
              {s.label.toUpperCase()}
            </p>
          </button>
        ))}
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="rounded-[24px] border border-slate-200 bg-white p-6">
          <h3 className="text-[12px] font-extrabold tracking-[0.24em] text-royal">
            HOUSE STANDINGS (ALPHA VS BETA)
          </h3>
          <div className="mt-4 space-y-3">
            {(overview.standings ?? []).map((t: any) => (
              <div
                key={t.id}
                className="flex items-center justify-between rounded-2xl bg-mist px-5 py-3.5"
              >
                <span className="font-display text-sm font-black tracking-widest text-midnight">
                  {t.name}
                </span>
                <span className="text-xl font-extrabold text-royal">
                  {t.points} pts
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-4">
            <button
              onClick={() => go("results")}
              className="text-[12px] font-extrabold tracking-widest text-royal hover:underline"
            >
              ADD PROGRAM SCORES →
            </button>
            <button
              onClick={() => go("pointlogs")}
              className="text-[12px] font-extrabold tracking-widest text-royal hover:underline"
            >
              HOUSE BONUS POINTS →
            </button>
          </div>
        </div>
        <div className="rounded-[24px] border border-slate-200 bg-white p-6">
          <h3 className="text-[12px] font-extrabold tracking-[0.24em] text-royal">
            AUTOMATED SCHEDULE SUMMARY
          </h3>
          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            <div className="rounded-2xl bg-emerald-50 p-4">
              <p className="text-2xl font-extrabold text-emerald-700">
                {overview.totals.ongoing ?? 0}
              </p>
              <p className="mt-1 text-[10px] font-extrabold tracking-widest text-emerald-700">
                LIVE NOW
              </p>
            </div>
            <div className="rounded-2xl bg-mist p-4">
              <p className="text-2xl font-extrabold text-royal">
                {overview.totals.upcoming ?? 0}
              </p>
              <p className="mt-1 text-[10px] font-extrabold tracking-widest text-royal">
                UPCOMING
              </p>
            </div>
            <div className="rounded-2xl bg-slate-100 p-4">
              <p className="text-2xl font-extrabold text-midnight">
                {overview.totals.over ?? 0}
              </p>
              <p className="mt-1 text-[10px] font-extrabold tracking-widest text-slate-600">
                PROGRAM OVER
              </p>
            </div>
          </div>
          <button
            onClick={() => go("schedule")}
            className="mt-4 text-[12px] font-extrabold tracking-widest text-royal hover:underline"
          >
            OPEN AUTO SCHEDULE MANAGER →
          </button>
        </div>
      </div>
      <div className="rounded-[24px] bg-midnight p-6 text-white">
        <h3 className="text-[12px] font-extrabold tracking-[0.24em] text-sky">
          QUICK CONTROLS
        </h3>
        <div className="mt-4 flex flex-wrap gap-2.5">
          {(
            [
              ["schedule", "⏱ Schedule Programs"],
              ["results", "🏆 Enter Program Scores & Points"],
              ["participants", "🎯 Manage Candidates"],
              ["committee", "👥 Manage Committee"],
              ["pointlogs", "✦ Award House Points"],
              ["announcements", "📣 Post Announcement"],
            ] as [Tab, string][]
          ).map(([t, label]) => (
            <button
              key={t}
              onClick={() => go(t)}
              className="rounded-xl border border-white/15 bg-white/10 px-4 py-2.5 text-[13px] font-extrabold transition hover:bg-white/20"
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
