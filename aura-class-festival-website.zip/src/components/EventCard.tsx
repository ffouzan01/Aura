"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { CalendarDays, MapPin, Users, ArrowUpRight } from "lucide-react";
import { ProgramStatusBadge } from "./ui";
import { formatEventDate, teamLabel } from "@/lib/format";
import { formatDisplayTime } from "@/lib/schedule";

export { formatEventDate, teamLabel };

export type EventCardData = {
  slug: string;
  title: string;
  description: string;
  venue: string;
  eventDate: string | null;
  startTime: string;
  endTime?: string;
  startAtIso?: string | null;
  endAtIso?: string | null;
  autoSchedule?: boolean;
  eventType: string;
  participatingTeams: string;
  status: string;
  isFeatured: boolean;
  imageUrl: string;
  category: { name: string; color: string } | null;
};

export default function EventCard({
  event,
  index = 0,
}: {
  event: EventCardData;
  index?: number;
}) {
  const startFormatted = formatDisplayTime(event.startTime);
  const endFormatted = formatDisplayTime(event.endTime);

  return (
    <motion.article
      initial={{ opacity: 0, y: 26 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.55, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="card-hover group relative flex flex-col overflow-hidden rounded-3xl border border-slate-200/80 bg-white"
    >
      {/* image */}
      <div className="relative h-44 overflow-hidden bg-gradient-to-br from-deepnavy to-royal">
        {event.imageUrl ? (
          <img
            src={event.imageUrl}
            alt={event.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="bg-dot-grid h-full w-full opacity-40" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-midnight/75 via-transparent to-transparent" />
        <div className="absolute left-3 top-3 flex gap-2">
          {event.isFeatured && (
            <span className="rounded-full bg-gradient-to-r from-amber-400 to-orange-400 px-3 py-1 text-[10px] font-extrabold tracking-widest text-midnight shadow">
              ★ FEATURED
            </span>
          )}
        </div>
        <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-2">
          <span
            className="rounded-full px-3 py-1 text-[10px] font-extrabold tracking-widest text-white"
            style={{ background: event.category?.color ?? "#1769E8" }}
          >
            {(event.category?.name ?? "PROGRAM").toUpperCase()}
          </span>
          <ProgramStatusBadge
            program={{
              eventDate: event.eventDate,
              startTime: event.startTime,
              endTime: event.endTime,
              startAt: event.startAtIso,
              endAt: event.endAtIso,
              autoSchedule: event.autoSchedule,
              status: event.status,
            }}
          />
        </div>
      </div>

      {/* body */}
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-[17px] font-extrabold leading-snug text-midnight transition group-hover:text-royal">
          <Link href={`/events/${event.slug}`} className="after:absolute after:inset-0">
            {event.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-2 text-[13.5px] leading-relaxed text-greytext">
          {event.description || "Details to be announced."}
        </p>

        <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 text-[12.5px] font-semibold text-slate-600">
          <p className="flex items-center gap-2">
            <CalendarDays size={14} className="shrink-0 text-royal" />
            <span>
              {formatEventDate(event.eventDate)}
              {startFormatted
                ? ` · ${startFormatted}${endFormatted ? ` – ${endFormatted}` : ""}`
                : ""}
            </span>
          </p>
          <p className="flex items-center gap-2">
            <MapPin size={14} className="shrink-0 text-royal" />
            <span className="truncate">{event.venue || "Venue TBA"}</span>
          </p>
          <p className="flex items-center gap-2">
            <Users size={14} className="shrink-0 text-royal" />
            {event.eventType === "group" ? "Group program" : "Individual program"} ·{" "}
            {teamLabel(event.participatingTeams)}
          </p>
        </div>

        <span className="mt-4 inline-flex items-center gap-1.5 text-[12px] font-extrabold tracking-widest text-royal">
          VIEW PROGRAM
          <ArrowUpRight
            size={14}
            className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
          />
        </span>
      </div>
    </motion.article>
  );
}
