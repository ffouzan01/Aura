"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Swords, Trophy, Medal, Users, Star, UserCheck, Search } from "lucide-react";
import { AnimatedNumber } from "./ui";

export type CandidateSummary = {
  id: string;
  chestNumber: string;
  name: string;
  category: string;
  score: string;
  grade: string;
  points: number;
  eventTitle: string;
  eventSlug: string;
};

export type TeamFull = {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  colorPrimary: string;
  colorSecondary: string;
  emblem: string;
  motto: string;
  captainName: string;
  viceCaptainName: string;
  members: { id: string; name: string; role: string; isPlaceholder: boolean }[];
  candidates?: CandidateSummary[];
  points: number;
  first: number;
  second: number;
  third: number;
  wins: number;
};

function TeamCard({ team }: { team: TeamFull }) {
  return (
    <div className="relative overflow-hidden rounded-[28px] border border-slate-200/80 bg-white p-6 sm:p-8">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-1.5"
        style={{
          background: `linear-gradient(90deg, ${team.colorPrimary}, ${team.colorSecondary})`,
        }}
      />
      <div className="flex items-center gap-4">
        <span
          className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-3xl font-extrabold text-white shadow-[0_14px_30px_-10px_rgba(23,105,232,0.6)]"
          style={{
            background: `linear-gradient(135deg, ${team.colorPrimary}, ${team.colorSecondary})`,
          }}
        >
          {team.emblem}
        </span>
        <div>
          <p className="font-display text-2xl font-black tracking-[0.08em] text-midnight sm:text-3xl">
            {team.name}
          </p>
          <p className="text-xs font-bold text-greytext">{team.tagline}</p>
        </div>
      </div>

      <p className="mt-5 text-sm leading-relaxed text-slate-600">{team.description}</p>
      <p
        className="mt-4 rounded-2xl p-4 text-sm font-extrabold italic"
        style={{ background: `${team.colorPrimary}0d`, color: team.colorPrimary }}
      >
        “{team.motto}”
      </p>

      <div className="mt-5 grid grid-cols-3 gap-2.5">
        {[
          { label: "FIRST PRIZE", value: team.first, icon: "🥇" },
          { label: "SECOND PRIZE", value: team.second, icon: "🥈" },
          { label: "THIRD PRIZE", value: team.third, icon: "🥉" },
        ].map((m) => (
          <div key={m.label} className="rounded-2xl bg-mist p-3 text-center">
            <p className="text-lg">{m.icon}</p>
            <p className="mt-1 text-xl font-extrabold text-midnight">
              <AnimatedNumber value={m.value} />
            </p>
            <p className="text-[9px] font-extrabold leading-tight tracking-widest text-greytext">
              {m.label}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-2xl bg-midnight p-5 text-white">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-extrabold tracking-[0.24em] text-sky">
            TOTAL POINTS
          </p>
          <Trophy size={15} className="text-amber-300" />
        </div>
        <p className="mt-1 text-4xl font-extrabold">
          <AnimatedNumber value={team.points} />
        </p>
      </div>

      <div className="mt-5 space-y-2.5">
        <p className="flex items-center gap-2 text-[12px] font-extrabold tracking-widest text-slate-500">
          <Star size={13} className="text-royal" /> LEADERSHIP
        </p>
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white px-4 py-2.5 text-sm">
          <span className="font-bold text-slate-500">Captain</span>
          <span className="font-extrabold text-midnight">{team.captainName}</span>
        </div>
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white px-4 py-2.5 text-sm">
          <span className="font-bold text-slate-500">Vice-captain</span>
          <span className="font-extrabold text-midnight">{team.viceCaptainName}</span>
        </div>
      </div>

      <div className="mt-5">
        <p className="flex items-center gap-2 text-[12px] font-extrabold tracking-widest text-slate-500">
          <Users size={13} className="text-royal" /> HOUSE SQUAD ({team.members.length})
        </p>
        <ul className="mt-2.5 grid gap-1.5 sm:grid-cols-2">
          {team.members.slice(0, 8).map((m) => (
            <li
              key={m.id}
              className="truncate rounded-xl bg-mist px-3.5 py-2 text-[13px] font-bold text-slate-600"
            >
              {m.name}
              {m.isPlaceholder && (
                <span className="ml-1.5 text-[10px] text-slate-400">· TBA</span>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default function TeamCompare({ teams }: { teams: TeamFull[] }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [houseFilter, setHouseFilter] = useState<string>("all");
  const [candSearch, setCandSearch] = useState("");

  const alpha = teams.find((t) => t.slug === "alpha") ?? teams[0];
  const beta = teams.find((t) => t.slug === "beta") ?? teams[1];

  const allCandidates = useMemo(() => {
    const list: (CandidateSummary & { teamName: string; teamSlug: string; teamColor: string })[] = [];
    for (const t of teams) {
      for (const c of t.candidates ?? []) {
        list.push({
          ...c,
          teamName: t.name,
          teamSlug: t.slug,
          teamColor: t.colorPrimary,
        });
      }
    }
    const needle = candSearch.trim().toLowerCase();
    return list.filter((c) => {
      if (houseFilter !== "all" && c.teamSlug !== houseFilter) return false;
      if (
        needle &&
        !`${c.chestNumber} ${c.name} ${c.eventTitle} ${c.category}`
          .toLowerCase()
          .includes(needle)
      )
        return false;
      return true;
    });
  }, [teams, houseFilter, candSearch]);

  if (!alpha || !beta) return null;

  const total = alpha.points + beta.points;
  const alphaPct = total > 0 ? Math.round((alpha.points / total) * 100) : 50;

  const rows = [
    { label: "Total points", a: alpha.points, b: beta.points },
    { label: "First prize", a: alpha.first, b: beta.first },
    { label: "Second prize", a: alpha.second, b: beta.second },
    { label: "Third prize", a: alpha.third, b: beta.third },
    {
      label: "Program entries",
      a: alpha.candidates?.length ?? 0,
      b: beta.candidates?.length ?? 0,
    },
  ];

  return (
    <div>
      {/* VS banner */}
      <div className="relative overflow-hidden rounded-[28px] bg-midnight p-6 sm:p-10">
        <div className="bg-hero-grid absolute inset-0" />
        <div
          className="pointer-events-none absolute -top-24 left-1/4 h-64 w-64 rounded-full opacity-30 blur-[100px]"
          style={{ background: alpha.colorPrimary }}
        />
        <div
          className="pointer-events-none absolute -bottom-24 right-1/4 h-64 w-64 rounded-full opacity-30 blur-[100px]"
          style={{ background: beta.colorPrimary }}
        />
        <div className="relative">
          <p className="flex items-center justify-center gap-2 text-center text-[11px] font-extrabold tracking-[0.3em] text-sky">
            <Swords size={14} /> HEAD TO HEAD
          </p>
          <div className="mt-6 grid grid-cols-[1fr_auto_1fr] items-center gap-3 sm:gap-6">
            <button
              onClick={() => setSelected(selected === alpha.id ? null : alpha.id)}
              className={`rounded-3xl border p-4 text-center transition sm:p-6 ${
                selected === alpha.id
                  ? "border-sky bg-white/15"
                  : "border-white/10 bg-white/[0.05] hover:border-white/25"
              }`}
            >
              <span
                className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-2xl font-extrabold text-white sm:h-16 sm:w-16 sm:text-3xl"
                style={{
                  background: `linear-gradient(135deg, ${alpha.colorPrimary}, ${alpha.colorSecondary})`,
                }}
              >
                {alpha.emblem}
              </span>
              <p className="font-display mt-3 text-lg font-black tracking-[0.1em] text-white sm:text-2xl">
                {alpha.name}
              </p>
              <p className="mt-1 text-3xl font-extrabold text-white sm:text-5xl">
                <AnimatedNumber value={alpha.points} />
              </p>
              <p className="text-[10px] font-extrabold tracking-[0.24em] text-slate-400">
                POINTS
              </p>
            </button>
            <div className="grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-royal to-electric text-lg font-extrabold text-white shadow-[0_0_50px_rgba(49,139,255,0.6)] sm:h-20 sm:w-20 sm:text-2xl">
              VS
            </div>
            <button
              onClick={() => setSelected(selected === beta.id ? null : beta.id)}
              className={`rounded-3xl border p-4 text-center transition sm:p-6 ${
                selected === beta.id
                  ? "border-sky bg-white/15"
                  : "border-white/10 bg-white/[0.05] hover:border-white/25"
              }`}
            >
              <span
                className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-2xl font-extrabold text-white sm:h-16 sm:w-16 sm:text-3xl"
                style={{
                  background: `linear-gradient(135deg, ${beta.colorPrimary}, ${beta.colorSecondary})`,
                }}
              >
                {beta.emblem}
              </span>
              <p className="font-display mt-3 text-lg font-black tracking-[0.1em] text-white sm:text-2xl">
                {beta.name}
              </p>
              <p className="mt-1 text-3xl font-extrabold text-white sm:text-5xl">
                <AnimatedNumber value={beta.points} />
              </p>
              <p className="text-[10px] font-extrabold tracking-[0.24em] text-slate-400">
                POINTS
              </p>
            </button>
          </div>

          <div className="mt-8">
            <div className="flex h-4 overflow-hidden rounded-full bg-white/10">
              <motion.div
                initial={{ width: "50%" }}
                whileInView={{ width: `${alphaPct}%` }}
                viewport={{ once: true }}
                transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
                className="h-full"
                style={{
                  background: `linear-gradient(90deg, ${alpha.colorSecondary}, ${alpha.colorPrimary})`,
                }}
              />
              <div
                className="h-full flex-1"
                style={{
                  background: `linear-gradient(90deg, ${beta.colorPrimary}, ${beta.colorSecondary})`,
                }}
              />
            </div>
            <div className="mt-2 flex justify-between text-[11px] font-extrabold tracking-widest text-slate-400">
              <span>ALPHA {alphaPct}%</span>
              <span>BETA {100 - alphaPct}%</span>
            </div>
          </div>

          <div className="mx-auto mt-6 max-w-2xl overflow-hidden rounded-2xl border border-white/10">
            {rows.map((r, i) => (
              <div
                key={r.label}
                className={`grid grid-cols-[1fr_1.4fr_1fr] items-center px-4 py-3 text-sm sm:px-6 ${
                  i % 2 === 0 ? "bg-white/[0.04]" : "bg-transparent"
                }`}
              >
                <p
                  className={`text-left font-extrabold ${
                    r.a >= r.b ? "text-amber-300" : "text-slate-300"
                  }`}
                >
                  {r.a}
                </p>
                <p className="flex items-center justify-center gap-1.5 text-center text-[11px] font-extrabold tracking-widest text-slate-400">
                  {r.label === "Total points" && <Medal size={12} />}
                  {r.label.toUpperCase()}
                </p>
                <p
                  className={`text-right font-extrabold ${
                    r.b >= r.a ? "text-amber-300" : "text-slate-300"
                  }`}
                >
                  {r.b}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* detailed house cards */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <motion.div
          animate={
            selected && selected !== alpha.id
              ? { opacity: 0.55, scale: 0.99 }
              : { opacity: 1, scale: 1 }
          }
          transition={{ duration: 0.3 }}
        >
          <TeamCard team={alpha} />
        </motion.div>
        <motion.div
          animate={
            selected && selected !== beta.id
              ? { opacity: 0.55, scale: 0.99 }
              : { opacity: 1, scale: 1 }
          }
          transition={{ duration: 0.3 }}
        >
          <TeamCard team={beta} />
        </motion.div>
      </div>

      {/* Festival Candidates Directory */}
      <section className="mt-12 rounded-[28px] border border-slate-200/80 bg-white p-6 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="inline-flex items-center gap-1.5 text-[11px] font-extrabold tracking-[0.22em] text-royal">
              <UserCheck size={14} /> CANDIDATES DIRECTORY
            </p>
            <h2 className="font-display mt-1 text-2xl font-black text-midnight sm:text-3xl">
              Program Candidates
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {(
              [
                { v: "all", l: "All Houses" },
                { v: "alpha", l: "ALPHA" },
                { v: "beta", l: "BETA" },
              ] as const
            ).map((opt) => (
              <button
                key={opt.v}
                type="button"
                onClick={() => setHouseFilter(opt.v)}
                className={`rounded-xl px-4 py-2 text-xs font-extrabold tracking-wider transition ${
                  houseFilter === opt.v
                    ? "bg-midnight text-white shadow"
                    : "bg-mist text-slate-600 hover:text-royal"
                }`}
              >
                {opt.l}
              </button>
            ))}
          </div>
        </div>

        <div className="relative mt-4">
          <Search
            size={16}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            value={candSearch}
            onChange={(e) => setCandSearch(e.target.value)}
            placeholder="Search by chest number, candidate name or program…"
            className="w-full rounded-2xl border border-slate-200 bg-mist/60 py-3 pl-11 pr-4 text-sm font-semibold text-midnight outline-none focus:border-royal focus:bg-white"
            aria-label="Search candidates"
          />
        </div>

        {allCandidates.length > 0 ? (
          <div className="mt-5 overflow-hidden rounded-2xl border border-slate-100">
            <div className="hidden grid-cols-[100px_1.4fr_1.4fr_120px] gap-3 bg-mist px-5 py-3 text-[11px] font-extrabold tracking-widest text-slate-500 md:grid">
              <span>CHEST NO</span>
              <span>CANDIDATE</span>
              <span>PROGRAM</span>
              <span>HOUSE</span>
            </div>
            <div className="divide-y divide-slate-100">
              {allCandidates.map((c) => (
                <div
                  key={c.id}
                  className="grid gap-1.5 px-5 py-3.5 text-sm md:grid-cols-[100px_1.4fr_1.4fr_120px] md:items-center md:gap-3"
                >
                  <span className="font-extrabold text-royal">
                    {c.chestNumber ? `#${c.chestNumber}` : "—"}
                  </span>
                  <span className="font-extrabold text-midnight">{c.name}</span>
                  <span>
                    {c.eventSlug ? (
                      <Link
                        href={`/events/${c.eventSlug}`}
                        className="font-bold text-slate-700 hover:text-royal"
                      >
                        {c.eventTitle}
                      </Link>
                    ) : (
                      <span className="font-bold text-slate-700">{c.eventTitle}</span>
                    )}
                  </span>
                  <span>
                    <span
                      className="inline-block rounded-full px-3 py-0.5 text-[10px] font-extrabold tracking-widest text-white"
                      style={{ background: c.teamColor }}
                    >
                      {c.teamName}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p className="mt-5 rounded-2xl bg-mist p-6 text-center text-sm font-semibold text-greytext">
            No candidate entries match yet. Candidates added from the Admin Control Panel appear here automatically.
          </p>
        )}
      </section>
    </div>
  );
}
