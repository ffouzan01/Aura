"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  motion,
  useInView,
  useReducedMotion,
  animate,
} from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import {
  resolveProgramStatus,
  type SchedulableProgram,
} from "@/lib/schedule";

/* ── Scroll reveal wrapper ─────────────────────────────── */
export function Reveal({
  children,
  delay = 0,
  y = 28,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? false : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/* ── Editorial section heading ─────────────────────────── */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  dark = false,
}: {
  eyebrow: string;
  title: ReactNode;
  subtitle?: string;
  align?: "center" | "left";
  dark?: boolean;
}) {
  return (
    <Reveal
      className={
        align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"
      }
    >
      <p
        className={`inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-[11px] font-extrabold tracking-[0.22em] ${
          dark
            ? "border-white/20 bg-white/10 text-sky"
            : "border-royal/15 bg-royal/5 text-royal"
        }`}
      >
        <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-electric to-sky" />
        {eyebrow}
      </p>
      <h2
        className={`mt-4 text-3xl font-extrabold leading-[1.08] tracking-tight sm:text-4xl lg:text-[44px] ${
          dark ? "text-white" : "text-midnight"
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p
          className={`mt-4 text-[15px] leading-relaxed sm:text-base ${
            dark ? "text-slate-300" : "text-greytext"
          }`}
        >
          {subtitle}
        </p>
      )}
    </Reveal>
  );
}

/* ── Animated number counter ───────────────────────────── */
export function AnimatedNumber({
  value,
  duration = 1.4,
  className,
}: {
  value: number;
  duration?: number;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const reduce = useReducedMotion();
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    if (reduce) {
      setDisplay(value);
      return;
    }
    const controls = animate(0, value, {
      duration,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setDisplay(Math.round(v)),
    });
    return () => controls.stop();
  }, [inView, value, duration, reduce]);

  return (
    <span ref={ref} className={className}>
      {display.toLocaleString()}
    </span>
  );
}

/* ── Status badge (static or automated) ────────────────── */
const STATUS_STYLES: Record<string, string> = {
  upcoming: "bg-royal/15 text-royal border-royal/25",
  ongoing: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  live: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  over: "bg-slate-900/90 text-white border-slate-700",
  completed: "bg-slate-900/90 text-white border-slate-700",
  postponed: "bg-amber-500/15 text-amber-700 border-amber-500/30",
};

export function StatusBadge({
  status,
  label,
}: {
  status: string;
  label?: string;
}) {
  const key = status.toLowerCase();
  const displayLabel =
    label ??
    (key === "completed" || key === "over"
      ? "Program is Over"
      : key === "ongoing" || key === "live"
      ? "Live Now"
      : status);

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[10.5px] font-extrabold tracking-wider uppercase ${
        STATUS_STYLES[key] ?? STATUS_STYLES.upcoming
      }`}
    >
      {(key === "ongoing" || key === "live") && (
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
        </span>
      )}
      {(key === "completed" || key === "over") && (
        <CheckCircle2 size={12} className="text-sky" />
      )}
      {displayLabel}
    </span>
  );
}

/**
 * Live automated status badge that re-evaluates every 10 seconds against the
 * current clock and automatically switches to "Program is Over" once end time passes.
 */
export function ProgramStatusBadge({
  program,
}: {
  program: SchedulableProgram;
}) {
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  useEffect(() => {
    setNowMs(Date.now());
    const id = setInterval(() => setNowMs(Date.now()), 10000);
    return () => clearInterval(id);
  }, []);

  const resolved = resolveProgramStatus(program, nowMs);
  return <StatusBadge status={resolved.code} label={resolved.label} />;
}

/* ── Empty state ───────────────────────────────────────── */
export function EmptyState({
  title,
  message,
  action,
}: {
  title: string;
  message: string;
  action?: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-md rounded-3xl border border-dashed border-royal/25 bg-mist px-8 py-12 text-center">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-royal to-electric text-2xl text-white shadow-lg">
        ✦
      </div>
      <h3 className="mt-5 text-lg font-extrabold text-midnight">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-greytext">{message}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/* ── Hero title with gradient accent ──────────────────── */
export function PortalHeroTitle({ text }: { text: string }) {
  const words = (text ?? "").trim().split(/\s+/);
  if (words.length === 0 || !words[0]) return null;
  const accent = words.slice(-1).join(" ");
  const lead = words.slice(0, -1).join(" ");
  return (
    <>
      {lead ? `${lead} ` : ""}
      <span className="font-script text-cyan">{accent}</span>
    </>
  );
}

/* ── Page hero (inner pages) ───────────────────────────── */
export function PageHero({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: ReactNode;
  subtitle?: string;
}) {
  return (
    <section className="relative overflow-hidden bg-deepnavy">
      <div className="poster-paper poster-grain poster-crease absolute inset-0 opacity-90" />
      <div
        className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full opacity-30 blur-[110px]"
        style={{ background: "#1769E8" }}
      />
      <div
        className="pointer-events-none absolute -bottom-40 -right-24 h-96 w-96 rounded-full opacity-25 blur-[110px]"
        style={{ background: "#318BFF" }}
      />
      <div className="relative mx-auto max-w-7xl px-4 pb-14 pt-28 sm:px-6 sm:pb-18 sm:pt-32">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto max-w-3xl text-center"
        >
          <p className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-1.5 text-[11px] font-extrabold tracking-[0.24em] text-sky">
            <span className="h-1.5 w-1.5 rounded-full bg-sky" />
            {eyebrow}
          </p>
          <h1 className="font-display mt-5 text-4xl font-extrabold leading-[1.04] tracking-tight text-cream sm:text-5xl lg:text-6xl">
            {title}
          </h1>
          {subtitle && (
            <p className="mx-auto mt-4 max-w-2xl text-[15px] leading-relaxed text-slate-300 sm:text-base">
              {subtitle}
            </p>
          )}
        </motion.div>
      </div>
      <div className="relative h-[3px] w-full bg-gradient-to-r from-royal via-electric to-sky" />
    </section>
  );
}
