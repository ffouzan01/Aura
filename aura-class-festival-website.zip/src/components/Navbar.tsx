"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { Menu, X, LayoutGrid, ShieldCheck } from "lucide-react";

const PRIMARY_LINKS = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
];

export function AuraMark({ size = 38 }: { size?: number }) {
  return (
    <span
      className="relative grid shrink-0 place-items-center overflow-hidden rounded-[11px] shadow-[0_6px_16px_-4px_rgba(6,24,44,0.75)]"
      style={{
        width: size,
        height: size,
        background: "linear-gradient(160deg, #4fb6f5 0%, #1f7fd4 52%, #0f4b8f 100%)",
      }}
      aria-hidden
    >
      <span
        className="pointer-events-none absolute inset-0 rounded-[11px]"
        style={{
          background:
            "radial-gradient(circle at 30% 18%, rgba(255,255,255,0.55) 0%, transparent 58%)",
        }}
      />
      <span
        className="relative font-extrabold leading-none text-white"
        style={{ fontSize: size * 0.52 }}
      >
        A
      </span>
    </span>
  );
}

export default function Navbar() {
  const pathname = usePathname();
  const reduce = useReducedMotion();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [openingVeil, setOpeningVeil] = useState(pathname === "/");
  const [brandName, setBrandName] = useState("AURA");
  const [brandSub, setBrandSub] = useState("WIDAD FRIENDS");

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => {
        const st = d?.settings ?? {};
        if (st.brand_wordmark) setBrandName(st.brand_wordmark);
        if (st.brand_subtext) setBrandSub(st.brand_subtext);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Trigger brief opening curtain & glassy bar sheen when loading the home page
  useEffect(() => {
    if (pathname === "/") {
      setOpeningVeil(true);
      const timer = setTimeout(() => setOpeningVeil(false), 680);
      return () => clearTimeout(timer);
    } else {
      setOpeningVeil(false);
    }
  }, [pathname]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  const openHub = () => {
    setOpen(false);
    window.dispatchEvent(new CustomEvent("open-festival-hub"));
  };

  return (
    <>
      {/* Cinematic opening veil while loading the home page */}
      <AnimatePresence>
        {openingVeil && !reduce && (
          <motion.div
            key="aura-opening-veil"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="pointer-events-none fixed inset-0 z-[90] flex items-center justify-center bg-[#050E1D]"
            aria-hidden
          >
            <motion.div
              initial={{ scale: 0.86, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.08, opacity: 0 }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col items-center"
            >
              <span className="aura-wordmark text-5xl leading-none sm:text-6xl">
                {brandName}
              </span>
              <motion.span
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="mt-3 h-[2px] w-28 origin-center rounded-full bg-gradient-to-r from-transparent via-cream/80 to-transparent"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Glassy Top Bar */}
      <motion.header
        key={pathname === "/" ? "home-glass-nav" : "inner-glass-nav"}
        initial={
          reduce
            ? false
            : {
                opacity: 0,
                y: -48,
                scale: 0.96,
                filter: "blur(10px)",
              }
        }
        animate={{
          opacity: 1,
          y: 0,
          scale: 1,
          filter: "blur(0px)",
        }}
        transition={{
          duration: 0.9,
          delay: pathname === "/" ? 0.22 : 0,
          ease: [0.16, 1, 0.3, 1],
        }}
        className="pointer-events-none fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-6 sm:pt-4"
      >
        <nav
          aria-label="Primary navigation"
          className={`pointer-events-auto relative mx-auto flex h-[64px] max-w-6xl items-center justify-between gap-4 overflow-hidden rounded-2xl border border-white/20 px-4 transition-all duration-300 sm:px-6 ${
            scrolled ? "glass-topbar-scrolled" : "glass-topbar"
          }`}
        >
          {/* Animated specular glass sheen sweep on load */}
          {!reduce && (
            <span
              aria-hidden
              className="glass-sheen pointer-events-none absolute inset-y-0 left-0 w-36 bg-gradient-to-r from-transparent via-white/25 to-transparent"
            />
          )}

          {/* Brand */}
          <Link href="/" className="group relative flex items-center gap-3">
            <AuraMark size={38} />
            <span className="leading-none">
              <span className="aura-brand-wordmark block text-[21px] transition group-hover:text-cyan sm:text-[23px]">
                {brandName}
              </span>
              <span className="mt-1 block text-[8px] font-bold uppercase leading-none tracking-[0.3em] text-cream/45 sm:text-[8.5px]">
                {brandSub}
              </span>
            </span>
          </Link>

          {/* Center Primary Links (Home & About only — everything else sorted in Hub buttons) */}
          <ul className="hidden items-center gap-1.5 md:flex">
            {PRIMARY_LINKS.map((l, idx) => {
              const active = isActive(l.href);
              return (
                <motion.li
                  key={l.href}
                  initial={reduce ? false : { opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.38 + idx * 0.08, duration: 0.45 }}
                >
                  <Link
                    href={l.href}
                    aria-current={active ? "page" : undefined}
                    className={`relative rounded-xl px-4 py-2 text-[13.5px] font-bold tracking-wide transition ${
                      active
                        ? "bg-white/15 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.28)]"
                        : "text-slate-200 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    {l.label}
                  </Link>
                </motion.li>
              );
            })}
          </ul>

          {/* Right controls */}
          <div className="hidden items-center gap-2.5 md:flex">
            <Link
              href="/admin"
              className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-extrabold tracking-wider transition ${
                pathname.startsWith("/admin")
                  ? "border-sky/60 bg-royal/40 text-white"
                  : "border-white/15 bg-white/[0.06] text-slate-200 hover:border-sky/40 hover:bg-white/12 hover:text-white"
              }`}
            >
              <ShieldCheck size={14} className="text-sky" />
              ADMIN
            </Link>
            <button
              type="button"
              onClick={openHub}
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-royal to-electric px-4 py-2 text-xs font-extrabold tracking-widest text-white shadow-[0_10px_24px_-6px_rgba(49,139,255,0.75)] transition hover:brightness-110"
            >
              <LayoutGrid size={14} />
              PORTALS
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            className="grid h-10 w-10 place-items-center rounded-xl border border-white/20 bg-white/10 text-white md:hidden"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </nav>
      </motion.header>

      {/* Mobile Glassy Drawer */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-40 bg-midnight/70 backdrop-blur-md md:hidden"
          >
            <motion.div
              initial={{ y: -24, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="mx-3 mt-20 rounded-3xl border border-white/20 bg-[#08172E]/95 p-5 text-white shadow-2xl backdrop-blur-2xl"
            >
              <div className="space-y-1.5">
                {PRIMARY_LINKS.map((l) => (
                  <Link
                    key={l.href}
                    href={l.href}
                    className={`flex items-center justify-between rounded-2xl px-4 py-3 text-sm font-extrabold transition ${
                      isActive(l.href)
                        ? "bg-gradient-to-r from-royal to-electric text-white"
                        : "text-slate-200 hover:bg-white/10"
                    }`}
                  >
                    {l.label}
                    <span className="text-xs text-sky">→</span>
                  </Link>
                ))}
                <Link
                  href="/admin"
                  className="flex items-center justify-between rounded-2xl px-4 py-3 text-sm font-extrabold text-slate-200 transition hover:bg-white/10"
                >
                  <span className="inline-flex items-center gap-2">
                    <ShieldCheck size={15} className="text-sky" /> Admin Console
                  </span>
                  <span className="text-xs text-sky">→</span>
                </Link>
              </div>
              <button
                type="button"
                onClick={openHub}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-royal to-electric px-4 py-3.5 text-xs font-extrabold tracking-widest text-white shadow-lg"
              >
                <LayoutGrid size={15} />
                OPEN EVENTS & FESTIVAL PORTALS
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
