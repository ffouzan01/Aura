"use client";

import { useState } from "react";
import { Send, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";

export default function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [status, setStatus] = useState<"idle" | "sending" | "ok" | "error">("idle");
  const [error, setError] = useState("");

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("sending");
    setError("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Send failed");
      setStatus("ok");
      setForm({ name: "", email: "", phone: "", subject: "", message: "" });
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Something went wrong.");
    }
  };

  const inputCls =
    "w-full rounded-2xl border border-slate-200 bg-white px-4 py-3.5 text-sm font-semibold text-midnight outline-none transition placeholder:font-medium placeholder:text-slate-400 focus:border-royal focus:ring-4 focus:ring-royal/10";

  if (status === "ok") {
    return (
      <div className="rounded-3xl border border-emerald-200 bg-emerald-50 p-10 text-center">
        <CheckCircle2 size={44} className="mx-auto text-emerald-500" />
        <h3 className="mt-4 text-xl font-extrabold text-midnight">Message sent!</h3>
        <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-slate-600">
          Thank you for reaching out. The WIDAD FRIENDS UNION team will get back
          to you shortly.
        </p>
        <button
          onClick={() => setStatus("idle")}
          className="mt-6 rounded-xl bg-midnight px-6 py-2.5 text-sm font-extrabold text-white"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="cf-name" className="mb-1.5 block text-[12px] font-extrabold tracking-widest text-slate-500">
            FULL NAME *
          </label>
          <input id="cf-name" className={inputCls} placeholder="Your name" value={form.name} onChange={set("name")} required minLength={2} />
        </div>
        <div>
          <label htmlFor="cf-email" className="mb-1.5 block text-[12px] font-extrabold tracking-widest text-slate-500">
            EMAIL *
          </label>
          <input id="cf-email" type="email" className={inputCls} placeholder="you@example.com" value={form.email} onChange={set("email")} required />
        </div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="cf-phone" className="mb-1.5 block text-[12px] font-extrabold tracking-widest text-slate-500">
            PHONE
          </label>
          <input id="cf-phone" type="tel" className={inputCls} placeholder="+91 …" value={form.phone} onChange={set("phone")} />
        </div>
        <div>
          <label htmlFor="cf-subject" className="mb-1.5 block text-[12px] font-extrabold tracking-widest text-slate-500">
            SUBJECT
          </label>
          <select id="cf-subject" className={inputCls} value={form.subject} onChange={set("subject")}>
            <option value="">General enquiry</option>
            <option value="Registration">Registration help</option>
            <option value="Events">Events & rules</option>
            <option value="Sponsorship">Sponsorship</option>
            <option value="Media">Media & press</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>
      <div>
        <label htmlFor="cf-message" className="mb-1.5 block text-[12px] font-extrabold tracking-widest text-slate-500">
          MESSAGE *
        </label>
        <textarea
          id="cf-message"
          rows={5}
          className={`${inputCls} resize-none`}
          placeholder="How can we help?"
          value={form.message}
          onChange={set("message")}
          required
          minLength={10}
        />
      </div>
      {status === "error" && (
        <p role="alert" className="flex items-center gap-2 rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-600">
          <AlertCircle size={16} /> {error}
        </p>
      )}
      <button
        type="submit"
        disabled={status === "sending"}
        className="group inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-royal to-electric px-8 py-4 text-sm font-extrabold tracking-widest text-white shadow-[0_14px_30px_-10px_rgba(23,105,232,0.7)] transition hover:brightness-110 disabled:opacity-60 sm:w-auto"
      >
        {status === "sending" ? (
          <>
            <Loader2 size={16} className="animate-spin" /> SENDING…
          </>
        ) : (
          <>
            SEND MESSAGE
            <Send size={15} className="transition-transform group-hover:translate-x-0.5" />
          </>
        )}
      </button>
    </form>
  );
}
