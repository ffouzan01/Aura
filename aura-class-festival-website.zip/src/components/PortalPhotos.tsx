import { getPortalPhotos } from "@/lib/data";
import PortalPhotosGallery from "./PortalPhotosGallery";

/**
 * Renders the admin-managed photo set for a portal page.
 * Returns nothing when the administrator has not added photos yet.
 */
export default async function PortalPhotos({
  portal,
  title = "Moments from this portal",
  eyebrow = "PHOTO STORY",
  limit = 8,
}: {
  portal: string;
  title?: string;
  eyebrow?: string;
  limit?: number;
}) {
  const photos = await getPortalPhotos(portal, limit);
  if (photos.length === 0) return null;

  return (
    <PortalPhotosGallery
      portal={portal}
      eyebrow={eyebrow}
      title={title}
      photos={photos.map((p) => ({
        id: p.id,
        title: p.title,
        caption: p.caption,
        imageUrl: p.imageUrl,
        alt: p.alt,
      }))}
    />
  );
}
