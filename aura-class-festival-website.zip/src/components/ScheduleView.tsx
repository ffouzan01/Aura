"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { List, Rows3, MapPin, Clock, Users, CheckCircle2, Radio } from "lucide-react";
import { StatusBadge, EmptyState } from "./ui";
import { teamLabel } from "@/lib/format";
import {
  formatDisplayTime,
  resolveProgramStatus,
  timeSortMinutes,
} from "@/lib/schedule";

export type ScheduleEvent = {
  id: string;
  slug: string;
  title: string;
  venue: string;
  eventDate: string | null;
  startTime: string;
  endTime: string;
  startAtIso?: string | null;
  endAtIso?: string | null;
  autoSchedule?: boolean;
  eventType: string;
  participatingTeams: string;
  status: string;
  categoryName: string;
  categoryColor: string;
};

export function dayLabel(d: string | null) {
  if (!d) return "Dates to be announced";
  try {
    return new Date(d + "T00:00:00").toLocaleDateString("en-IN", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch {
    return "Dates to be announced";
  }
}

export default function ScheduleView({ events }: { events: ScheduleEvent[] }) {
  const [view, setView] = useState<"timeline" | "list">("timeline");
  const [day, setDay] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  useEffect(() => {
    setNowMs(Date.now());
    const id = setInterval(() => setNowMs(Date.now()), 5000);
    return () => clearInterval(id);
  }, []);

  const enriched = useMemo(
    () =>
      events.map((e) => ({
        ...e,
        resolved: resolveProgramStatus(
          {
            eventDate: e.eventDate,
            startTime: e.startTime,
            endTime: e.endTime,
            startAt: e.startAtIso,
            endAt: e.endAtIso,
            autoSchedule: e.autoSchedule,
            status: e.status,
          },
          nowMs
        ),
      })),
    [events, nowMs]
  );

  const counts = useMemo(
    () => ({
      live: enriched.filter((e) => e.resolved.code === "ongoing").length,
      upcoming: enriched.filter((e) => e.resolved.code === "upcoming").length,
      over: enriched.filter((e) => e.resolved.code === "over").length,
    }),
    [enriched]
  );

  const days = useMemo(() => {
    const set = new Map<string, string>();
    for (const e of enriched) {
      const key = e.eventDate ?? "tba";
      if (!set.has(key)) set.set(key, dayLabel(e.eventDate));
    }
    return [...set.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [enriched]);

  const filtered = useMemo(
    () =>
      enriched.filter(
        (e) =>
          (day === "all" || (e.eventDate ?? "tba") === day) &&
          (statusFilter === "all" || e.resolved.code === statusFilter)
      ),
    [enriched, day, statusFilter]
  );

  const grouped = useMemo(() => {
    const map = new Map<string, typeof filtered>();
    for (const e of filtered) {
      const key = e.eventDate ?? "tba";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(e);
    }
    return [...map.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(
        ([k, list]) =>
          [
            k,
            [...list].sort(
              (a, b) => timeSortMinutes(a.startTime) - timeSortMinutes(b.startTime)
            ),
          ] as const
      );
  }, [filtered]);

  return (
    <div>
      {/* Automated schedule live status summary */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-royal/15 bg-white p-4 shadow-sm sm:px-6">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-royal to-electric text-white shadow-md">
            <Radio size={18} />
          </span>
          <div>
            <p className="text-xs font-extrabold tracking-[0.2em] text-royal">
              AUTOMATED TIME SCHEDULE
            </p>
            <p className="text-xs font-semibold text-greytext">
              Programs automatically switch to &ldquo;Program is Over&rdquo; once their scheduled end time finishes.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-xs font-extrabold">
          <button
            type="button"
            onClick={() =>
              setStatusFilter(statusFilter === "ongoing" ? "all" : "ongoing")
            }
            className={`rounded-full border px-3.5 py-1.5 transition ${
              statusFilter === "ongoing"
                ? "border-emerald-600 bg-emerald-600 text-white"
                : "border-emerald-500/30 bg-emerald-500/10 text-emerald-700"
            }`}
          >
            Live Now: {counts.live}
          </button>
          <button
            type="button"
            onClick={() =>
              setStatusFilter(statusFilter === "upcoming" ? "all" : "upcoming")
            }
            className={`rounded-full border px-3.5 py-1.5 transition ${
              statusFilter === "upcoming"
                ? "border-royal bg-royal text-white"
                : "border-royal/25 bg-royal/10 text-royal"
            }`}
          >
            Upcoming: {counts.upcoming}
          </button>
          <button
            type="button"
            onClick={() =>
              setStatusFilter(statusFilter === "over" ? "all" : "over")
            }
            className={`rounded-full border px-3.5 py-1.5 transition ${
              statusFilter === "over"
                ? "border-midnight bg-midnight text-white"
                : "border-slate-300 bg-slate-100 text-slate-800"
            }`}
          >
            Program is Over: {counts.over}
          </button>
        </div>
      </div>

      {/* controls */}
      <div className="flex flex-wrap items-center gap-2.5">
        <div className="inline-flex rounded-2xl border border-slate-200 bg-white p-1">
          {(
            [
              { v: "timeline", icon: Rows3, label: "Timeline" },
              { v: "list", icon: List, label: "List" },
            ] as const
          ).map((t) => (
            <button
              key={t.v}
              onClick={() => setView(t.v)}
              aria-pressed={view === t.v}
              className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-[13px] font-extrabold transition ${
                view === t.v
                  ? "bg-midnight text-white shadow"
                  : "text-slate-500 hover:text-midnight"
              }`}
            >
              <t.icon size={15} /> {t.label}
            </button>
          ))}
        </div>
        <select
          value={day}
          onChange={(e) => setDay(e.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] font-bold text-slate-700 outline-none focus:border-royal"
          aria-label="Day filter"
        >
          <option value="all">All days</option>
          {days.map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] font-bold text-slate-700 outline-none focus:border-royal"
          aria-label="Status filter"
        >
          <option value="all">All statuses</option>
          <option value="upcoming">Upcoming</option>
          <option value="ongoing">Live Now</option>
          <option value="over">Program is Over</option>
          <option value="postponed">Postponed</option>
        </select>
      </div>

      {filtered.length === 0 && (
        <div className="mt-8">
          <EmptyState
            title="Nothing scheduled here"
            message="No programs match these filters. Try another day or status."
          />
        </div>
      )}

      <AnimatePresence mode="wait">
        <motion.div
          key={view + day + statusFilter}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
          className="mt-8 space-y-10"
        >
          {grouped.map(([dateKey, list]) => (
            <div key={dateKey}>
              <div className="flex items-center gap-4">
                <h2 className="rounded-2xl bg-midnight px-5 py-2.5 text-sm font-extrabold tracking-wide text-white sm:text-base">
                  {dayLabel(dateKey === "tba" ? null : dateKey)}
                </h2>
                <span className="text-[12px] font-extrabold tracking-widest text-slate-400">
                  {list.length} PROGRAM{list.length !== 1 ? "S" : ""}
                </span>
                <div className="h-px flex-1 bg-gradient-to-r from-royal/25 to-transparent" />
              </div>

              {view === "timeline" ? (
                <div className="relative mt-6 space-y-4 before:absolute before:bottom-4 before:left-[27px] before:top-4 before:w-[2px] before:bg-gradient-to-b before:from-royal before:via-electric before:to-sky/30 sm:before:left-[31px]">
                  {list.map((e, i) => {
                    const startDisp = formatDisplayTime(e.startTime);
                    const endDisp = formatDisplayTime(e.endTime);
                    const isOver = e.resolved.isOver;

                    return (
                      <motion.div
                        key={e.id}
                        initial={{ opacity: 0, x: -14 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-40px" }}
                        transition={{ duration: 0.4, delay: Math.min(i * 0.05, 0.3) }}
                        className="relative pl-14 sm:pl-16"
                      >
                        <span
                          className="absolute left-[18px] top-6 grid h-[22px] w-[22px] place-items-center rounded-full border-4 border-white shadow-md sm:left-[22px]"
                          style={{
                            background: isOver
                              ? "#071426"
                              : e.resolved.isLive
                              ? "#10B981"
                              : e.categoryColor,
                          }}
                        >
                          {isOver && <CheckCircle2 size={11} className="text-sky" />}
                        </span>
                        <Link
                          href={`/events/${e.slug}`}
                          className={`card-hover block rounded-3xl border p-5 ${
                            isOver
                              ? "border-slate-200 bg-slate-50/90"
                              : "border-slate-200/80 bg-white"
                          }`}
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <p className="inline-flex items-center gap-1.5 text-[12px] font-extrabold tracking-widest text-royal">
                              <Clock size={13} />
                              {startDisp || "Time TBA"}
                              {endDisp ? ` – ${endDisp}` : ""}
                            </p>
                            <StatusBadge
                              status={e.resolved.code}
                              label={e.resolved.label}
                            />
                          </div>
                          <h3
                            className={`mt-2 text-lg font-extrabold ${
                              isOver ? "text-slate-700" : "text-midnight"
                            }`}
                          >
                            {e.title}
                          </h3>
                          <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1.5 text-[12.5px] font-semibold text-greytext">
                            <span className="inline-flex items-center gap-1.5">
                              <MapPin size={13} className="text-royal" /> {e.venue}
                            </span>
                            <span className="inline-flex items-center gap-1.5">
                              <Users size={13} className="text-royal" />
                              {e.eventType === "group" ? "Group" : "Individual"} ·{" "}
                              {teamLabel(e.participatingTeams)}
                            </span>
                            <span
                              className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-extrabold text-white"
                              style={{ background: e.categoryColor }}
                            >
                              {e.categoryName}
                            </span>
                          </div>
                        </Link>
                      </motion.div>
                    );
                  })}
                </div>
              ) : (
                <div className="mt-5 overflow-hidden rounded-3xl border border-slate-200/80 bg-white">
                  <div className="hidden grid-cols-[150px_1fr_160px_140px_160px] gap-3 border-b border-slate-100 bg-mist px-6 py-3 text-[11px] font-extrabold tracking-widest text-slate-500 md:grid">
                    <span>TIME</span>
                    <span>PROGRAM</span>
                    <span>VENUE</span>
                    <span>HOUSES</span>
                    <span className="text-right">STATUS</span>
                  </div>
                  {list.map((e) => {
                    const startDisp = formatDisplayTime(e.startTime);
                    const endDisp = formatDisplayTime(e.endTime);
                    return (
                      <Link
                        key={e.id}
                        href={`/events/${e.slug}`}
                        className={`grid gap-1.5 border-b border-slate-100 px-6 py-4 transition last:border-0 hover:bg-mist/70 md:grid-cols-[150px_1fr_160px_140px_160px] md:items-center md:gap-3 ${
                          e.resolved.isOver ? "bg-slate-50/75" : ""
                        }`}
                      >
                        <span className="text-[12.5px] font-extrabold text-royal">
                          {startDisp || "TBA"}
                          {endDisp ? ` – ${endDisp}` : ""}
                        </span>
                        <span>
                          <span className="block text-[15px] font-extrabold text-midnight">
                            {e.title}
                          </span>
                          <span className="text-xs font-semibold text-greytext">
                            {e.categoryName} · {e.eventType}
                          </span>
                        </span>
                        <span className="text-[13px] font-bold text-slate-600">
                          {e.venue}
                        </span>
                        <span className="text-[13px] font-bold text-slate-600">
                          {teamLabel(e.participatingTeams)}
                        </span>
                        <span className="md:text-right">
                          <StatusBadge
                            status={e.resolved.code}
                            label={e.resolved.label}
                          />
                        </span>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
