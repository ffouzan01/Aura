"use client";

import { useEffect, useMemo, useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import EventCard, { type EventCardData } from "./EventCard";
import { EmptyState } from "./ui";
import { resolveProgramStatus } from "@/lib/schedule";

export type ExplorerEvent = EventCardData & { id: string };

export default function EventsExplorer({
  events,
  categories,
}: {
  events: ExplorerEvent[];
  categories: { id: string; slug: string; name: string }[];
}) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [team, setTeam] = useState("all");
  const [type, setType] = useState("all");
  const [status, setStatus] = useState("all");
  const [showFeatured, setShowFeatured] = useState(false);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  useEffect(() => {
    setNowMs(Date.now());
    const id = setInterval(() => setNowMs(Date.now()), 10000);
    return () => clearInterval(id);
  }, []);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return events.filter((e) => {
      if (cat !== "all" && e.category?.name !== categories.find((c) => c.slug === cat)?.name)
        return false;
      if (team !== "all" && e.participatingTeams !== team && e.participatingTeams !== "both")
        return false;
      if (type !== "all" && e.eventType !== type) return false;
      if (status !== "all") {
        const resolved = resolveProgramStatus(
          {
            eventDate: e.eventDate,
            startTime: e.startTime,
            endTime: e.endTime,
            startAt: e.startAtIso,
            endAt: e.endAtIso,
            autoSchedule: e.autoSchedule,
            status: e.status,
          },
          nowMs
        );
        if (resolved.code !== status) return false;
      }
      if (showFeatured && !e.isFeatured) return false;
      if (
        needle &&
        !`${e.title} ${e.description} ${e.venue}`.toLowerCase().includes(needle)
      )
        return false;
      return true;
    });
  }, [events, q, cat, team, type, status, showFeatured, categories, nowMs]);

  const selectCls =
    "rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] font-bold text-slate-700 outline-none transition focus:border-royal focus:ring-2 focus:ring-royal/15";

  return (
    <div>
      {/* search */}
      <div className="relative">
        <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search programs by name, venue or keyword…"
          className="w-full rounded-2xl border border-slate-200 bg-white py-4 pl-12 pr-4 text-[15px] font-semibold text-midnight shadow-sm outline-none transition placeholder:font-medium placeholder:text-slate-400 focus:border-royal focus:ring-4 focus:ring-royal/10"
          aria-label="Search programs"
        />
      </div>

      {/* filters */}
      <div className="mt-4 flex flex-wrap items-center gap-2.5">
        <span className="inline-flex items-center gap-1.5 text-[12px] font-extrabold tracking-widest text-slate-500">
          <SlidersHorizontal size={14} /> FILTERS
        </span>
        <select value={cat} onChange={(e) => setCat(e.target.value)} className={selectCls} aria-label="Category filter">
          <option value="all">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name}
            </option>
          ))}
        </select>
        <select value={team} onChange={(e) => setTeam(e.target.value)} className={selectCls} aria-label="Team filter">
          <option value="all">Both houses</option>
          <option value="alpha">ALPHA</option>
          <option value="beta">BETA</option>
        </select>
        <select value={type} onChange={(e) => setType(e.target.value)} className={selectCls} aria-label="Type filter">
          <option value="all">Individual + Group</option>
          <option value="individual">Individual</option>
          <option value="group">Group</option>
        </select>
        <select value={status} onChange={(e) => setStatus(e.target.value)} className={selectCls} aria-label="Status filter">
          <option value="all">All statuses</option>
          <option value="upcoming">Upcoming</option>
          <option value="ongoing">Live Now</option>
          <option value="over">Program is Over</option>
          <option value="postponed">Postponed</option>
        </select>
        <button
          onClick={() => setShowFeatured((v) => !v)}
          aria-pressed={showFeatured}
          className={`rounded-xl px-3.5 py-2.5 text-[13px] font-extrabold transition ${
            showFeatured
              ? "bg-gradient-to-r from-amber-400 to-orange-400 text-midnight shadow"
              : "border border-slate-200 bg-white text-slate-600 hover:border-amber-300"
          }`}
        >
          ★ Featured only
        </button>
        {(q || cat !== "all" || team !== "all" || type !== "all" || status !== "all" || showFeatured) && (
          <button
            onClick={() => {
              setQ("");
              setCat("all");
              setTeam("all");
              setType("all");
              setStatus("all");
              setShowFeatured(false);
            }}
            className="rounded-xl px-3 py-2.5 text-[13px] font-extrabold text-royal hover:bg-royal/5"
          >
            Clear all
          </button>
        )}
      </div>

      <p className="mt-5 text-[13px] font-bold text-slate-500" role="status">
        Showing <span className="text-royal">{filtered.length}</span> of {events.length} programs
      </p>

      {filtered.length > 0 ? (
        <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((e, i) => (
            <EventCard key={e.id} event={e} index={i} />
          ))}
        </div>
      ) : (
        <div className="mt-8">
          <EmptyState
            title="No programs found"
            message="Try a different keyword or clear the filters to browse the full directory."
            action={
              <button
                onClick={() => {
                  setQ("");
                  setCat("all");
                  setTeam("all");
                  setType("all");
                  setStatus("all");
                  setShowFeatured(false);
                }}
                className="rounded-xl bg-royal px-6 py-2.5 text-sm font-extrabold text-white"
              >
                Clear filters
              </button>
            }
          />
        </div>
      )}
    </div>
  );
}
